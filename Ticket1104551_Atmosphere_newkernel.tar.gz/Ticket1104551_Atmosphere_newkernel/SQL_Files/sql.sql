alter table tblgroup add gatewayname varchar;
alter table tblgroup add gatewayipaddress varchar;

INSERT INTO tblclientservices (servicekey,servicevalue) VALUES ('gatewayipfrompackage','true');

INSERT INTO tblregistration (tableid,productname,producttype,serialid,password,elitekey,users,status,expiredate,displayproductname,checkkey,displayaddonmodule) VALUES (62,'gatewayipfrompackage','gatewayipfrompackage','a','a','a',50005,102,null,'gatewayipfrompackage','N','N');