package e24online.corporate.modes;

import java.io.IOException;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.elitecore.hibernate.base.DAOFactory;
import com.elitecore.hmsintegration.utilities.HMSUtilities;
import com.elitecore.hmsintegration.utilities.HotelEntityRelationHelper;
import com.elitecore.hmsintegration.utilities.HotelUtilities;
import com.elitecore.jdbchelper.SqlMaker;
import com.elitecore.jdbchelper.SqlReader;

import e24online.corporate.cas.CASGroupAddonsHelper;
import e24online.corporate.cas.helper.GroupCASRelDetailHelper;
import e24online.corporate.cas.helper.GroupCASRelHelper;
import e24online.corporate.paymenttracking.helper.GraceDaysHelper;
import e24online.corporate.policy.dao.base.IGroupDAO;
import e24online.corporate.policy.dao.base.IGroupGatewayServiceDAO;
import e24online.corporate.policy.dao.base.IPackagePoolBindingDAO;
import e24online.corporate.policy.dao.base.IRateBasedGroupRelationDAO;
import e24online.corporate.policy.dao.base.IRenewalRuleDAO;
import e24online.corporate.policy.dao.ibase.IDataTransferPolicy;
import e24online.corporate.policy.dao.ibase.IGroupPolicyRelDAO;
import e24online.corporate.policy.dao.ibase.IPolicy;
import e24online.corporate.policy.entity.Tbldatatransferpolicy;
import e24online.corporate.policy.entity.Tblgroup;
import e24online.corporate.policy.entity.Tblgroupgatewayservice;
import e24online.corporate.policy.entity.Tblgrouppolicyrel;
import e24online.corporate.policy.entity.Tblpolicy;
import e24online.corporate.policy.entity.Tblratebasedgrouprel;
import e24online.corporate.policy.entity.Tblrenewalrule;
import e24online.corporate.systemmgt.dao.ibase.IClientServices;
import e24online.corporate.systemmgt.dao.ibase.IGatewayDAO;
import e24online.corporate.systemmgt.entity.Tblclientservices;
import e24online.corporate.systemmgt.entity.Tblgateway;
import e24online.corporate.user.dao.ibase.IAncillaryServiceRelDAO;
import e24online.corporate.user.dao.ibase.ITaxInfoRelDAO;
import e24online.corporate.user.dao.ibase.ITaxOnTaxableAmountDAO;
import e24online.corporate.user.dao.ibase.IZoneDao;
import e24online.corporate.user.dao.impl.TaxOnTaxableAmountDAO;
import e24online.corporate.user.dao.impl.TaxableAncServiceDAO;
import e24online.corporate.user.entity.Tbltaxontaxableamt;
import e24online.corporate.utilities.CASConstants;
import e24online.corporate.utilities.E24onlineConstants;
import e24online.corporate.utilities.PropertyReader;
import e24online.corporate.voip.entity.TblVoIPGroupRel;
import e24online.corporate.voip.helper.GroupTypeRelationHelper;
import e24online.corporate.voip.helper.VoIPGroupHelper;
import e24online.corporate.voip.utility.VoIPConstants;
import e24online.general.ModuleController;
import e24online.integration.entity.Tblcyberoamgroup;
import e24online.log.E24onlineLogger;
import e24online.utilities.AuditObject;
import e24online.utilities.E24onlineUtilities;

public class CreateGroup {

	public static boolean isPOPEnabled = ModuleController.isModuleVisible(E24onlineConstants.POPMANAGEMENT);
	private static boolean isZoneEnabled = ModuleController.isModuleVisible(E24onlineConstants.ZONEMANAGEMENT);

	private static final boolean isDataMode = VoIPConstants.ISDATAMODE ;
	private static final boolean isVoIPMode = VoIPConstants.IS_VOIP_VISIBLE ;
	private static final boolean isVoIPOnly = (isVoIPMode && (!isDataMode));
	private static final boolean isCASMode = CASConstants.IS_CAS_VISIBLE;
	private static final boolean isCASOnly = (isCASMode && (!isDataMode));

	private static final boolean isMultipleServicesInvoiceVisible = ModuleController.isModuleVisible(E24onlineConstants.MULTIPLESERVICESINVOICE);
	
	private static final boolean isCacheQosVisible=ModuleController.isModuleVisible(E24onlineConstants.CACHEQOS);
	private static final boolean isGraceDaysVisible = GraceDaysHelper.isGraceDaysVisible();
	private static final boolean isGraceDaysEnable = GraceDaysHelper.isGraceDaysEnable();

	private static final String MODULE = "[CreateGroup]";
	
	//VoIP Mode
	private static int iPackageType = E24onlineConstants.DATAPACKAGETYPE ;

	private static DAOFactory factory = null;

	static {
		factory = DAOFactory.instance(DAOFactory.HIBERNATE);
	}
	
	public static void process(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		int sessionstatus = E24onlineUtilities.checkSession(req);
		if (sessionstatus == E24onlineUtilities.NOTAUTHENTICATED) {
			res.sendRedirect(req.getContextPath()
					+ "/webpages/sessionexpired.jsp");
			return;
		}else if (sessionstatus == E24onlineUtilities.NOTREGISTERED){ 
			res.sendRedirect(req.getContextPath()+"/webpages/help/onlineregistration.jsp");
			return;
		}
		
		String strMode = req.getParameter("mode");
		int mode = 0;
		String pkgtype = req.getParameter("pkgtype");
		E24onlineLogger.appLog.debug(MODULE + "Package Type - " + pkgtype);
		
		if(strMode != null){
			try{
				mode = Integer.parseInt(strMode);
			}catch(Exception e){
				E24onlineLogger.errorLog.error(MODULE + " Exception while parsing mode :"+e,e);
			}
		}
		
		if( mode == Modes.CREATEGROUP ){
			createGroup(req,res);
		}else if( mode == Modes.CREATEGROUP_DASHBOARD ){
			createGroupFromDashboard(req,res);
		}else{
			E24onlineLogger.appLog.debug(MODULE + " Invalid Mode value :"+mode);
		}
	}
	
	/*public static void createGroup(HttpServletRequest req, HttpServletResponse res)
	throws ServletException, IOException {
		HttpSession httpSession = req.getSession(false);
		String loggedInUserName = (String)httpSession.getAttribute("user");	
		int securityLevel = ((Integer)httpSession.getAttribute("securitylevel")).intValue();
		DecimalFormat dformat = new DecimalFormat("0.00");
		try {
			String groupName = req.getParameter("groupname");
			E24onlineLogger.appLog.debug("Value of group name inside creategroup : "+groupName);

			String netSecEnabled = req.getParameter("netSecEnabled");
			E24onlineLogger.appLog.debug("NetSecEnabled:"+ netSecEnabled);
			
			String onlinePurchase = req.getParameter("onlinePurchase");
			E24onlineLogger.appLog.debug("Online Purchase:"+ onlinePurchase);			
			
			String pkgDescription = req.getParameter("description");
			if(pkgDescription != null ){
				pkgDescription = pkgDescription.trim();
			}
			E24onlineLogger.appLog.debug("Package Description in CreateGroup:"+ pkgDescription);
			
			int surfingPolicyId = 0;
			String policyId = req.getParameter("policyid");
			E24onlineLogger.appLog.debug("POLICY:"+policyId); 
			if(policyId != null){
				surfingPolicyId = Integer.parseInt(policyId);
			}
		
			int accessPolId = 0;
			String accessPolicyId = req.getParameter("accesspolicyid");
			E24onlineLogger.appLog.debug("ACCESS POLICY ID:"+accessPolicyId); 
			if(accessPolicyId != null){
				accessPolId = Integer.parseInt(accessPolicyId);
			}
			E24onlineLogger.appLog.debug("ACCESS POLICY ID:"+accessPolId); 
			
			if (isVoIPMode){
				try{
					surfingPolicyId = Integer.parseInt(policyId);
					if (surfingPolicyId == 0){
						surfingPolicyId = 1;
					}	
				}catch(Exception e){ 
					surfingPolicyId = 1;
				}
			}
			String billCycleAmtBasedOn = req.getParameter("billcycleamtbasedon");
			int iBillCycleAmtBasedOn = E24onlineConstants.FULLAMTBASEDONBILLCYCLE;
			
			if(billCycleAmtBasedOn != null && !("").equalsIgnoreCase(billCycleAmtBasedOn)){
				iBillCycleAmtBasedOn = Integer.parseInt(billCycleAmtBasedOn);
			}
			
			String cycleType = null ;
			String cycleMultiplier = null ;
			String billDate = null ;
			
			GroupBean groupBean = new GroupBean();
			RenewalRuleBean renewRuleBean = new RenewalRuleBean();
			
			groupBean.setGroupName(groupName);
			groupBean.setNetSecEnabled(netSecEnabled);
			groupBean.setOnlinePurchase(onlinePurchase);
			groupBean.setConnectionType(connectionId);// Set the connection type (Leased or normal);
			E24onlineLogger.appLog.debug("POLICY ID:"+surfingPolicyId); 
			//groupBean.setPolicyID(E24onlineUtilities.OPENPOLICY);
			groupBean.setPolicyID(surfingPolicyId);
			E24onlineLogger.appLog.debug("ACCESS POLICY ID:"+accessPolId); 
			groupBean.setAccessPolicyID(accessPolId);
			groupBean.setDescription(pkgDescription);
			
			int poolId = 0;
			String strPoolId = req.getParameter("poolid");
			try{
				if(strPoolId != null && strPoolId.length() > 0){
					poolId = Integer.parseInt(strPoolId);
				}
			}catch(Exception e){
				poolId = 0;
			}
			E24onlineLogger.appLog.debug("Pool ID:"+poolId);
			groupBean.setPoolID(poolId);
			
		  // Change By Tejas Shah for adding idle time out time and idle time out value 
			String strIdleTimeoutType = req.getParameter("idletimeouttype");
			String strIdleTimeoutValue = req.getParameter("idletimeout");
			String strIsdefaultIdleTimeOut = req.getParameter("chk_default");
			int idleTimeoutType = E24onlineConstants.LIVE_REQUEST_BASED; 
			int idleTimeoutValue = E24onlineConstants.DEFAULTIDLETIMEOUT;
			
			if(connectionId == E24onlineConstants.LEASEDLINE){
				// for lease line user
				idleTimeoutType = E24onlineConstants.NO_IDLE_TIMEOUT;
				idleTimeoutValue = E24onlineConstants.NO_IDLE_TIMEOUT_VALUE;
			}else{
				// for normal user
				
				try{
					idleTimeoutType = Integer.parseInt(strIdleTimeoutType);
				}catch (Exception e) {
					E24onlineLogger.errorLog.error(MODULE+"Exception in parsing idleTimeoutType"+e,e);
					idleTimeoutType = E24onlineConstants.NO_IDLE_TIMEOUT;
					idleTimeoutValue = E24onlineConstants.NO_IDLE_TIMEOUT_VALUE;
				}
				
				
				if( strIsdefaultIdleTimeOut != null){
					// Check box is check i.e use default value for idle time out
					try{
						
						E24onlineLogger.appLog.debug(MODULE + "[Testing] :value of check box :"+strIsdefaultIdleTimeOut);
						
						if(strIsdefaultIdleTimeOut.equals("on") ){ // this is for default value
							if(idleTimeoutType ==  E24onlineConstants.NO_IDLE_TIMEOUT){
								// in case of selecting  No Idle Timeout 
								idleTimeoutValue = E24onlineConstants.NO_IDLE_TIMEOUT_VALUE;
							}else{
								// in case of  Live Request Based  & Internet Data Transfer Based  idle time out 
								idleTimeoutValue = E24onlineConstants.DEFAULTIDLETIMEOUT;
							}
							
						}
						
					}catch(Exception e){
							E24onlineLogger.errorLog.error(MODULE + "Exception while parsing Default Idle Timeout:"+e,e);
					}
				}else {
					
					// in case of  Live Request Based  & Internet Data Transfer Based  idle time out with user defined values 
						try{
							
							if(idleTimeoutType ==  E24onlineConstants.NO_IDLE_TIMEOUT){
								// in case of selecting  No Idle Timeout 
								idleTimeoutValue = E24onlineConstants.NO_IDLE_TIMEOUT_VALUE;
							}else{
								// in case of  Live Request Based  & Internet Data Transfer Based  idle time out 
								idleTimeoutValue = Integer.parseInt(strIdleTimeoutValue);
							}
						
						}catch (Exception e) {
							idleTimeoutValue = E24onlineConstants.DEFAULTIDLETIMEOUT;
							E24onlineLogger.errorLog.error(MODULE + "Exception while parsing idle timeout value :"+e,e);
						}
							
				}
			}
			E24onlineLogger.appLog.debug(MODULE + "idle timeout value :"+idleTimeoutValue);
			E24onlineLogger.appLog.debug(MODULE + "idle timeout Type :"+idleTimeoutType);
			groupBean.setIdleTimeout(idleTimeoutValue);
			groupBean.setIdleTimeoutType(idleTimeoutType);
			
			int bwpolicyid = 0;
			try{
				bwpolicyid = Integer.parseInt(bwPolicyIdStr);
				if (bwpolicyid == 0){
					groupBean.setBWpolicyID(E24onlineConstants.NOBANDWIDTHRESTRICTION);
				}else{ 
					groupBean.setBWpolicyID(bwpolicyid);
				}	
			}catch(Exception e){ 
				groupBean.setBWpolicyID(E24onlineConstants.NOBANDWIDTHRESTRICTION);
			}	
			
			E24onlineLogger.appLog.debug("Value of bandwidthpolicy : "+bwPolicyIdStr+" : "+bwpolicyid);
			
			int dtpolicyId = 0;
			try{
				dtpolicyId = Integer.parseInt(dtPolicyIdStr);
				if (dtpolicyId == 0){
					groupBean.setDatatransferID(E24onlineConstants.UNLIMITEDDATATRANSFERPOLICY);
				}else{ 
					groupBean.setDatatransferID(dtpolicyId);
				}	
				
			}catch(Exception e){ 
				groupBean.setDatatransferID(E24onlineConstants.UNLIMITEDDATATRANSFERPOLICY);
			}
			E24onlineLogger.appLog.debug("Value of datatransferpolicyid : "+dtPolicyIdStr+" : "+dtpolicyId);
			
			// Check for if Surfing policy is Limited (Walking pkg) then Datatransfer can't Cyclic
			DataTransferPolicyBean dtPolicyBean = (DataTransferPolicyBean)DataTransferPolicyBean.getRecordByPrimaryKey(dtpolicyId);			
			PolicyBean policyBean = (PolicyBean)PolicyBean.getRecordByPrimaryKey(surfingPolicyId);
			if (dtPolicyBean != null && policyBean != null && policyBean.getExpireDays() == E24onlineUtilities.LIMITEDTIMESURFING && dtPolicyBean.getDatatransferCycleType() != E24onlineConstants.NONCYCLIC){
				E24onlineLogger.appLog.info("Cyclic Datatransfer Policy Not Possible With Limited Surfing Time Policy: " + E24onlineUtilities.CYCLICDTLIMITEDSURFING);
				res.sendRedirect(req.getContextPath()+"/webpages/grpmgt/addupdategroup.jsp?insertstatus="+E24onlineUtilities.CYCLICDTLIMITEDSURFING);
				return ;
			}
			//End for check for Limited Surfing Time With cyclic policy
			
			groupBean.setPackageType(billscheme);
			
			int definationType=0;
			String checkBoxReg = req.getParameter("chk_registration");
			String checkBoxRenewal = req.getParameter("chk_renewal");
			
			E24onlineLogger.appLog.debug("Reg CheckBox:" +checkBoxReg);
			E24onlineLogger.appLog.debug("Renew CheckBox:" +checkBoxRenewal);
			
			if (checkBoxReg != null && checkBoxRenewal != null ){
				definationType = E24onlineConstants.REGISTRATIONANDRENEWAL;
			}
			else {
				if (checkBoxReg != null){
					definationType = E24onlineConstants.REGISTRATION; 
				}
				if (checkBoxRenewal != null){
					definationType = E24onlineConstants.RENEWAL;
				}
			}
			groupBean.setDefination(definationType);
			E24onlineLogger.appLog.debug("Package Type selected : " + definationType);
			
			boolean isRatebasePrepaidGroup = false;
			if (billscheme == E24onlineConstants.POSTPAIDSCHEME){ 
				*//**
				 * This should be set to some unlimited policy but temporarily it is set to 1.
				 * Change it afterwards.
				 *//*
				E24onlineLogger.appLog.debug("**In postpaidscheme");
				//groupBean.setPolicyID(1);
				
				cycleType = req.getParameter("cycletype");
				E24onlineLogger.appLog.debug("**CycleType: "+cycleType);
				cycleMultiplier = req.getParameter("cyclemultiplier");
				E24onlineLogger.appLog.debug("**cycleMultiplier: "+cycleMultiplier);
				E24onlineLogger.appLog.debug("CT:CM:BD : "+cycleType+":"+cycleMultiplier+":"+billDate);
				if ("W".equals(cycleType)){
					billDate = req.getParameter("billdatew");
				}else{ 
					billDate = req.getParameter("billdatem");
				}	
				E24onlineLogger.appLog.debug("CT:CM:BD : "+cycleType+":"+cycleMultiplier+":"+billDate);
				groupBean.setCycleType(cycleType);
				groupBean.setCycleMultiplier(Integer.parseInt(cycleMultiplier));
				groupBean.setBillingDate(Integer.parseInt(billDate));
			}else{
				// This is Prepaid package
				DataTransferPolicyBean dtPolBean = null;
				if (dtpolicyId!=0){
					dtPolBean = (DataTransferPolicyBean) DataTransferPolicyBean.getRecordByPrimaryKey(dtpolicyId);
				}
				if (dtPolBean!=null && dtPolBean.getScheme()==E24onlineConstants.POSTPAIDSCHEME){
					// this is ratebased user
					isRatebasePrepaidGroup = true;
				}
			}
			E24onlineLogger.appLog.debug("Price in crate group : "+price);
			String priceStr = dformat.format((Double.valueOf(price)).doubleValue());
			E24onlineLogger.appLog.debug("PriceStr in crate group : "+priceStr);
			groupBean.setPrice( (Double.valueOf(priceStr)).doubleValue());
			groupBean.setStatus(req.getParameter("status"));
			groupBean.setCountAmtBasedOn(E24onlineConstants.AMT_BASE_NOT_APPLICABLE);
			// START OF SETTING BOD ACCOUNTABLE VALUE
			String bodaccountablevalue = req.getParameter("bodaccountablevalue");
			int iBodAcctValue = E24onlineConstants.AMT_BASE_HOURS;
			if(bodaccountablevalue != null && !"".equals(bodaccountablevalue)){
				iBodAcctValue = (Integer.parseInt(bodaccountablevalue));
			}
			groupBean.setBodAccountableValue(iBodAcctValue);
			// END OF SETTING BOD ACCOUNTABLE VALUE
			groupBean.setBillingCycleAmountBasedOn(iBillCycleAmtBasedOn);
			String proportionType = req.getParameter("proportiontype");
			E24onlineLogger.appLog.debug("CREATE GROUP : proportionType:"+proportionType);
			groupBean.setProportionType(proportionType);
			
			// SETTING PROFIT VALUE
			String profitValue = req.getParameter("profitvalue");
			double dProfitValue = 0;
			if(profitValue != null && !"".equals(profitValue)){
				try{
					dProfitValue = (Double.parseDouble(profitValue));
				}catch(Exception e){
					dProfitValue = 0;
					E24onlineLogger.errorLog.error("CREATE GROUP : Exception while parsing Profit Value : "+e,e);
				}
			}
			groupBean.setProfitValue(dProfitValue);
			
			// SETTING FAPID
			String fapId = req.getParameter("fapid");
			int iFapId = 0;
			if(fapId != null && !"".equals(fapId)){
				try{
					iFapId = (Integer.parseInt(fapId));
				}catch(Exception e){
					iFapId = E24onlineConstants.NOFAPID;
					E24onlineLogger.errorLog.error("CREATE GROUP : Exception while parsing FAP Id : "+e,e);
				}
			}
			groupBean.setFapid(iFapId);
			
			*//**** Processing for cyberoam group starts ****//*
			
			String cyberoamGroupId = req.getParameter("cyberoamgroupid");
			int iCyberoamGroupId = Tblcyberoamgroup.DEFAULT_GROUP_ID;
			
			if(cyberoamGroupId != null && !"".equals(cyberoamGroupId)){
				try{
					iCyberoamGroupId = (Integer.parseInt(cyberoamGroupId));
				}catch(Exception e){
					iCyberoamGroupId = Tblcyberoamgroup.DEFAULT_GROUP_ID;
					E24onlineLogger.errorLog.error(MODULE+"Exception while parsing Cyberoam Group Id : "+e,e);
				}
				E24onlineLogger.appLog.debug(MODULE+"Cyberoam Group Id : "+iCyberoamGroupId);
			}
			groupBean.setCyberoamGroupId(iCyberoamGroupId);
			
			*//**** Processing for cyberoam group ends ****//*
			
			E24onlineLogger.appLog.debug("GroupBean: " + groupBean);
			int insertStatus = groupBean.insertRecord();
			
			if(insertStatus >0){
				E24onlineLogger.audit.info(new AuditObject(AuditObject.PACKAGE,groupBean.getGroupName(),AuditObject.CREATEPACKAGE,null,groupBean.toString(),loggedInUserName,(String)httpSession.getAttribute("ipaddress"),groupBean.getGroupID()));
				
				GroupGatewayServiceBean groupGatewayServiceBean = null;
				int serviceProportionStatus = -1;
				if(proportionType.equals(E24onlineConstants.MANUALSERVICEPROPORTION)){
					String gatewayServiceId[] = req.getParameterValues("gatewayserviceid");
					String gatewayPorportion[] = req.getParameterValues("gatewayserviceproportion");
					String gatewayDiscount[] = req.getParameterValues("gatewayservicediscount");
					
					int iGatewayServiceId = 0;
					double dGatewayProportion = 0;
					double dGatewayDiscount = 0;
					
					for(int i=0; i<gatewayServiceId.length; i++){
						
						iGatewayServiceId = 0;
						dGatewayProportion = 0;
						dGatewayDiscount = 0;
						
						if(gatewayServiceId[i] != null){
							try{
								iGatewayServiceId = Integer.parseInt(gatewayServiceId[i]);
							}catch(Exception e){
								E24onlineLogger.errorLog.error("CREATE GROUP,Exception while parsing Gateway Service Id :"+e,e);
							}
						}
						if(gatewayPorportion[i] != null){
							try{
								dGatewayProportion = Double.parseDouble(gatewayPorportion[i]);
							}catch(Exception e){
								E24onlineLogger.errorLog.error("CREATE GROUP,Exception while parsing Gateway Service Proportion :"+e,e);
							}
						}
						if(gatewayDiscount != null && gatewayDiscount[i] != null){
							try{
								dGatewayDiscount = Double.parseDouble(gatewayDiscount[i]);
							}catch(Exception e){
								E24onlineLogger.errorLog.error("CREATE GROUP,Exception while parsing Gateway Service Discount :"+e,e);
							}
						}
						groupGatewayServiceBean = new GroupGatewayServiceBean();
						
						groupGatewayServiceBean.setGroupId(groupBean.getPrimaryKey());
						groupGatewayServiceBean.setGatewayServiceId(iGatewayServiceId);
						groupGatewayServiceBean.setProportion(dGatewayProportion);
						groupGatewayServiceBean.setDiscount(dGatewayDiscount);
						
						serviceProportionStatus = groupGatewayServiceBean.insertRecord();
						
					}
					E24onlineLogger.appLog.debug("CREATE GROUP : serviceProportionStatus:" + serviceProportionStatus);
				}
				
				if (isRatebasePrepaidGroup){
					int cycleDays = -1;
					double cyclePrice = -1;
					String bbca = "Y";
					try {
						cycleDays = Integer.parseInt(req.getParameter("cycledays").trim());
					}catch(Exception e){
						E24onlineLogger.errorLog.error("CreateGroup: Exception in Parsing CycleDays :" + e);
					}
					try {
						cyclePrice = Double.parseDouble(req.getParameter("cycleprice").trim());
					}catch(Exception e){
						E24onlineLogger.errorLog.error("CreateGroup: Exception in Parsing Cycle Price :" + e);
					}
					try {
						bbca = req.getParameter("underbalaceallowed").trim();
					}catch(Exception e){
						E24onlineLogger.errorLog.error("CreateGroup: Exception in Parsing UnderBalanceAllowed:" + e);
					}
					
					RatebasedGroupRelBean ratebasedGroupRelBean = new RatebasedGroupRelBean();
					ratebasedGroupRelBean.setGroupId(groupBean.getGroupID());
					ratebasedGroupRelBean.setCycleDays(cycleDays);
					ratebasedGroupRelBean.setCyclePrice(cyclePrice);
					ratebasedGroupRelBean.setBalanceBelowCutoffAllowed(bbca);
					int rateRelInsertStatus = ratebasedGroupRelBean.insertRecord();
					E24onlineLogger.appLog.debug("CreateGroup: RatebasedGroupRel Insert Status:" + rateRelInsertStatus + " for group id:" + ratebasedGroupRelBean.getGroupId()); 
				}
				
				// set default all package rule for packages of renewal type
				if(groupBean.getDefination() == E24onlineConstants.REGISTRATIONANDRENEWAL ||
				   groupBean.getDefination() == E24onlineConstants.RENEWAL ){	
					E24onlineLogger.appLog.debug("Adding ALL PACKAGE Rule");
					renewRuleBean.setNewPackageId(insertStatus);
					renewRuleBean.setOldPackageId(E24onlineUtilities.ALLPACKAGES);
					
					renewRuleBean.setShiftToNew(E24onlineConstants.ALLOWED);
					
					renewRuleBean.setCarryForwadHours(E24onlineConstants.NOTALLOWED);
					renewRuleBean.setCarryForwadDuration(E24onlineConstants.NOTALLOWED);
					renewRuleBean.setCarryForwadDataTransfer(E24onlineConstants.NOTALLOWED);
					renewRuleBean.setRenewalRuleAmtFlag(E24onlineConstants.NOTALLOWED);
					renewRuleBean.setAddValueBasedOn(E24onlineConstants.AMT_BASE_NOT_APPLICABLE);
					renewRuleBean.insertRecord();
				}
				
				
			}
			
			// Insert Default Ancillary Serivce Values and Tax Values
			if( insertStatus >0 ){
				CreateGroup.insertDefaultAncAndTaxValues(E24onlineConstants.GROUPANCILLARYSERVICEREL,insertStatus);								
			}
			
			if( insertStatus >0 ){
				int groupId = insertStatus;
				// Insert in Entity Zone Relation only when POP Mgmt. customization is enabled
				if(isPOPEnabled){
					ArrayList zoneIdListForPop = null;
					int iPopId = E24onlineConstants.NOPOPSELECTED;
					String popId = req.getParameter("popid");
					if(popId != null && !("").equals(popId)){
						try{
							iPopId = Integer.parseInt(popId);
						}catch(Exception e){
							E24onlineLogger.errorLog.error("Create Package, Exception while parsing Pop Id :"+e,e);
						}
					}
					if(iPopId > 0){
						zoneIdListForPop = ZoneBean.getZoneIdListByPOPId(iPopId);
						if(zoneIdListForPop != null && zoneIdListForPop.size() > 0){
							EntityZoneRelation.createEntityZoneRelation(E24onlineConstants.PACKAGE,groupId,zoneIdListForPop,securityLevel);
						}
					}									
				}
			}
			
			if( insertStatus >0 ){
				E24onlineLogger.appLog.info("Insert Status: " + insertStatus);
				req.setAttribute("groupname",groupName);
				req.setAttribute("insertStatus",Integer.toString(insertStatus));
				if (groupBean.getDefination() == E24onlineConstants.REGISTRATION ){
					req.getRequestDispatcher("/webpages/grpmgt/managegroups.jsp?groupid=" + groupBean.getGroupID()).forward(req,res);
				}else{
					req.getRequestDispatcher("/webpages/grpmgt/addupdategroup.jsp?groupid=" + groupBean.getGroupID()).forward(req,res);
				}
				//res.sendRedirect(req.getContextPath()+"/webpages/grpmgt/addupdategroup.jsp?groupid=" + groupBean.getGroupID() + "&groupname" + groupName +"&insertStatus" +Integer.toString(insertStatus));
			}else{
				E24onlineLogger.appLog.info("Insert Status: " + insertStatus);
				res.sendRedirect(req.getContextPath()+"/webpages/grpmgt/addupdategroup.jsp?insertstatus="+insertStatus);
			}
		}catch(Exception e){
			E24onlineLogger.errorLog.error("Exception in creategroup:"+e,e);
			res.sendRedirect("/corporate/webpages/error.jsp?errormessage=" + URLEncoder.encode("Error in creating group.") + "&exception="+ URLEncoder.encode(e.toString()));
		}
	}*/
	
	
	public static void createGroup(HttpServletRequest req, HttpServletResponse res)
	throws ServletException, IOException {
		HttpSession httpSession = req.getSession(false);
		String loggedInUserName = (String)httpSession.getAttribute("user");
		String sourceIPAddress = (String)httpSession.getAttribute("ipaddress");
		int securityLevel = ((Integer)httpSession.getAttribute("securitylevel")).intValue();
		String[] hotelIds = req.getParameterValues("hotelId[]");
		DecimalFormat dformat = new DecimalFormat("0.00");
		try {
			String groupName = req.getParameter("groupname");
			E24onlineLogger.appLog.debug("Value of group name inside creategroup : "+groupName);

			String netSecEnabled = req.getParameter("netSecEnabled");
			E24onlineLogger.appLog.debug("NetSecEnabled:"+ netSecEnabled);
			
			String onlinePurchase = req.getParameter("onlinePurchase");
			E24onlineLogger.appLog.debug("Online Purchase:"+ onlinePurchase);			
			
			String pkgDescription = req.getParameter("description");
			if(pkgDescription != null ){
				pkgDescription = pkgDescription.trim();
			}
			E24onlineLogger.appLog.debug("Package Description in CreateGroup:"+ pkgDescription);
			String packageType = req.getParameter("pkgtype");
			
			String strDiscount ;
			strDiscount = req.getParameter("packagediscount");
			E24onlineLogger.appLog.debug(MODULE + " Discount = " + strDiscount  );
			
			//percentage discount change
			String strPercentageCheck;
			strPercentageCheck = req.getParameter("percentage");
			E24onlineLogger.appLog.debug(MODULE + " Percentage isChecked =" + strPercentageCheck);
		
			int profileId = 0;
			String strProfileId = req.getParameter("profileid");
			E24onlineLogger.appLog.debug("PROFILE ID:"+strProfileId); 
			if(strProfileId != null){
				profileId = Integer.parseInt(strProfileId);
			}
			int iGroupid=0;
			String groupid="";
			if(isCASMode){
				groupid=req.getParameter("groupid");
			}
			E24onlineLogger.appLog.debug(MODULE + " groupid = " + groupid  );
			E24onlineLogger.appLog.debug("PROFILE ID:"+profileId);

			
			
			
		if (isVoIPMode){
				try{
					iPackageType = Integer.parseInt(packageType.trim());
					E24onlineLogger.appLog.debug(MODULE + "Package Type -> " + iPackageType);
				}catch(Exception e){
					if (isVoIPOnly){
						iPackageType = E24onlineConstants.VOIPPACKAGETYPE;
					}else if (isDataMode){
						iPackageType = E24onlineConstants.DATAPACKAGETYPE ;
					}
					E24onlineLogger.appLog.debug(MODULE + "Package Type Parameter not Found : Default -> " + iPackageType);
				}
			}
			/*
			 * int surfingPolicyId = 0; String policyId =
			 * req.getParameter("policyid");
			 * E24onlineLogger.appLog.debug("POLICY:"+policyId); if(policyId !=
			 * null){ surfingPolicyId = Integer.parseInt(policyId); }
			 */
			int radiusPolId = 0;
			String radiusPolicyId = req.getParameter("radiuspolicyid");
			E24onlineLogger.appLog.debug("RADIUS POLICY ID:"+radiusPolicyId); 
			if(radiusPolicyId != null){
				radiusPolId = Integer.parseInt(radiusPolicyId);
			}
			E24onlineLogger.appLog.debug("RADIUS POLICY ID:"+radiusPolicyId);
		
			int accessPolId = 0;
			String accessPolicyId = req.getParameter("accesspolicyid");
			if (accessPolicyId != null && isDataMode) {
				accessPolId = Integer.parseInt(accessPolicyId);
			} else if (isVoIPOnly) {
				accessPolId = VoIPConstants.DEFAULTACCESSPOLICY;
			} else if (isCASOnly) {
				accessPolId = CASConstants.DEFAULTACCESSPOLICY;
			}
			E24onlineLogger.appLog.debug("ACCESS POLICY ID:"+accessPolId); 
			
			// Add the connection type 
			int connectionId = 0;
			String connectionType = req.getParameter("connectiontype");
			E24onlineLogger.appLog.debug("CONNECTION TYPE:"+connectionType); 
			if(connectionType != null){
				connectionId = Integer.parseInt(connectionType);
			}
			
						
			String price = req.getParameter("price");
						
			String bwPolicyIdStr = req.getParameter("bwpolicyid");
			String dtPolicyIdStr = req.getParameter("dtpolicyid");
			String billSchemeStr = req.getParameter("billscheme");
			E24onlineLogger.appLog.debug("Value of billschemestr : "+billSchemeStr);
			int billscheme = Integer.parseInt(billSchemeStr) ;
			
			int surfingPolicyId = 0;
			String policyId = null;

			String voipPolicyId = null;
			int intVoIPPolicyId = 0;
			double creditLimit = 0D;

			if (billscheme == E24onlineConstants.PREPAIDSCHEME) {
				if (connectionId == E24onlineConstants.LEASEDLINE) {
					policyId = req.getParameter("policyidleased");
				}else{
					policyId = req.getParameter("policyid");
				}
				E24onlineLogger.appLog.debug("POLICY:"+policyId); 
				if(policyId != null && !"null".equals(policyId)){
					surfingPolicyId = Integer.parseInt(policyId);
				}

				if (VoIPConstants.IS_VOIP_VISIBLE) {
					// VoIP Policy for Group - Bhavik Ambani

					voipPolicyId = req.getParameter("voippolicynames");
					E24onlineLogger.appLog.debug(MODULE
							+ "Value of VoIP policy = " + voipPolicyId);
					intVoIPPolicyId = Integer.parseInt(voipPolicyId.trim());
				}

			} else {
				// Processing credit limit for the postpaid users
				String creditLimitStr = req.getParameter("creditlimit");
				if (!E24onlineUtilities.isEmptyString(creditLimitStr)){
					creditLimit = Double.parseDouble(creditLimitStr);
				}
				
				if (connectionId == E24onlineConstants.LEASEDLINE) {
					policyId = req.getParameter("postpaidpolicyidleased");
				}else{
					policyId = req.getParameter("postpaidpolicyid");
				}
				E24onlineLogger.appLog.debug("POLICY:"+policyId); 
				try{
					if(policyId!=null){
					surfingPolicyId = Integer.parseInt(policyId);
					}
					if (surfingPolicyId == 0){
						surfingPolicyId = 1;
					}	
				}catch(Exception e){ 
					surfingPolicyId = 1;
				}
				if (isVoIPOnly) {
					surfingPolicyId = VoIPConstants.DEFAULTSURFPOLICY;
				}
				if(isCASOnly){
					surfingPolicyId = CASConstants.DEFAULTSURFPOLICY;
				}
				
				// VoIP Group - Bhavik Ambani
				if (VoIPConstants.IS_VOIP_VISIBLE) {
					voipPolicyId = req.getParameter("voippolicynames").trim();
					intVoIPPolicyId = Integer.parseInt(voipPolicyId);
				}
			}
			try{
				iGroupid=Integer.parseInt(groupid);
			}catch (Exception e) {
				E24onlineLogger.appLog.debug(MODULE+" groupid not passed:"+groupid);
			}
			String billCycleAmtBasedOn = req.getParameter("billcycleamtbasedon");
			int iBillCycleAmtBasedOn = E24onlineConstants.FULLAMTBASEDONBILLCYCLE;
			
			if(billCycleAmtBasedOn != null && !("").equalsIgnoreCase(billCycleAmtBasedOn)){
				iBillCycleAmtBasedOn = Integer.parseInt(billCycleAmtBasedOn);
			}
			
			String quotaamountbasedon = req.getParameter("quotaamountbasedon");
			int iQuotaAmountBasedOn = E24onlineConstants.FULLAMTBASEDONBILLCYCLE;
			
			if(quotaamountbasedon != null && !("").equalsIgnoreCase(quotaamountbasedon)){
				iQuotaAmountBasedOn = Integer.parseInt(quotaamountbasedon);
			}
			
			String cycleType = null ;
			String cycleMultiplier = null ;
			String billDate = null ;
			
			Tblgroup groupBean = new Tblgroup();
			
			if(isCASMode){
				groupBean.setGroupid(iGroupid);
				groupBean.setNetsecenabled("Y");
			}else{
				groupBean.setNetsecenabled(netSecEnabled);
			}
			E24onlineLogger.appLog.debug(MODULE+" creategroup bean:"+groupBean);
			groupBean.setGroupname(groupName);
			//groupBean.setNetsecenabled(netSecEnabled);
			groupBean.setOnlinepurchase(onlinePurchase);
			groupBean.setProfileid(profileId);
			groupBean.setConnectiontype(connectionId);// Set the connection type (Leased or normal);
			E24onlineLogger.appLog.debug("POLICY ID:"+surfingPolicyId); 
			//groupBean.setPolicyID(E24onlineUtilities.OPENPOLICY);
			groupBean.setPolicyid(surfingPolicyId);
			E24onlineLogger.appLog.debug("ACCESS POLICY ID:"+accessPolId); 
			groupBean.setAccesspolicyid(accessPolId);
			groupBean.setRadiuspolicyid(radiusPolId);
			groupBean.setDescription(pkgDescription);
			
			//Setting Credit Limit for the package
			groupBean.setCreditlimit(creditLimit);
			E24onlineLogger.appLog.debug(MODULE + "Configuring credit limit for the package as # " + groupBean.getCreditlimit());
			
			int poolId = 0;
						
			String strPoolId = req.getParameter("poolid");
			try{
				if(strPoolId != null && strPoolId.length() > 0){
					poolId = Integer.parseInt(strPoolId);
				}
			}catch(Exception e){
				poolId = 0;
			}
			E24onlineLogger.appLog.debug("Pool ID:"+poolId);
		
			
			groupBean.setPoolid(poolId);
			
			/*int idleTimeout = E24onlineConstants.DEFAULTIDLETIMEOUT;
			String strIdleTimeout = req.getParameter("idletimeout");
			try{
				if(strIdleTimeout != null && strIdleTimeout.length() > 0 ){
					idleTimeout = Integer.parseInt(strIdleTimeout);
				}
			}catch(Exception e){
				idleTimeout = E24onlineConstants.DEFAULTIDLETIMEOUT;
			}
			groupBean.setIdleTimeout(idleTimeout);*/
			/*** Added By Nishant Mishra for Inserting Multiple Login Limit at Package Level*/
			String reqLoginLimit = null;
			int multipleLoginLimit = E24onlineConstants.DEFAULTMULTIPLELOGINLIMIT;
			if(req.getParameter("multilimit") != null){
				try{
				reqLoginLimit = req.getParameter("multilimit").trim();
				multipleLoginLimit = Integer.parseInt(reqLoginLimit);
				}catch(Exception e){
					E24onlineLogger.errorLog.error("MODULE"+" Exception in getting USER login limit, Setting to Default");
					multipleLoginLimit = E24onlineConstants.DEFAULTMULTIPLELOGINLIMIT;
				}
			}
			E24onlineLogger.appLog.debug(MODULE + "User Login Limit :"+multipleLoginLimit);
			groupBean.setLoginlimit(multipleLoginLimit);
 			 
			if ( ModuleController.isModuleVisible(E24onlineConstants.MULTIPLEGATEWAYS)){
				String reqPriority = null;
				int iPriorityId = E24onlineConstants.NO_VALUE_PROVIDED;
				if(req.getParameter("priorityid") != null){
					try{
						reqPriority = req.getParameter("priorityid").trim();
						iPriorityId = Integer.parseInt(reqPriority);
					}catch(Exception e){
						E24onlineLogger.errorLog.error("MODULE"+" Exception in getting Priorityid, Setting to Default");
						iPriorityId = E24onlineConstants.NO_VALUE_PROVIDED;
					}
				}
			
				E24onlineLogger.appLog.debug(MODULE + "PriorityId :"+iPriorityId);
				groupBean.setPriorityid(iPriorityId);
			}
			
			String isBindToMAC = "N";
			try {
				isBindToMAC = req.getParameter("isBindToMAC")!=null?req.getParameter("isBindToMAC"):"N";
				E24onlineLogger.appLog.debug(MODULE + "BindToMAC Flag : "+isBindToMAC);
				groupBean.setBindtomac(isBindToMAC);
			} catch(Exception e){
				E24onlineLogger.errorLog.error(MODULE + "Exception while set of BindToMAC: " + e,e);
			}
			
			if(isGraceDaysVisible && isGraceDaysEnable){
				String reqGracedays = null;
				IClientServices clientservicesDAO = factory.getClientServicesDao();
				int gracedays = Integer.parseInt(clientservicesDAO.getValueByKey("System_Gracedays"));
				String gracedaysrel = E24onlineConstants.SYSTEM_LOGIN_LIMIT_REL;
				if(req.getParameter("pkggracedays") != null){
					try{
						reqGracedays = req.getParameter("pkggracedays").trim();
						gracedays = Integer.parseInt(reqGracedays);
						gracedaysrel = E24onlineConstants.GROUP_LOGIN_LIMIT_REL;
					}catch(Exception e){
						E24onlineLogger.errorLog.error("MODULE"+" Exception in getting Package Grace Days, So Setting it to Default");
						gracedays = E24onlineConstants.DISABLEDSYSTEMGRACEDAYS;
						gracedaysrel = E24onlineConstants.SYSTEM_LOGIN_LIMIT_REL;
					}
				}
				
				E24onlineLogger.appLog.debug(MODULE + " Package Grace Days : "+gracedays+ " And Grace Days Relation is " +gracedaysrel);
				groupBean.setGracedays(gracedays);
				groupBean.setGracedaysrel(gracedaysrel);
			}
			
			
			// This code will store value for expire by and expire time
			// -1 -> Global , 0 -> Date ,1-> DateTime
			
			int expireBy=E24onlineConstants.USEREXPIREBYSYSTEM;
			String expireByStr=req.getParameter("expiretype");
			
			try{
				expireBy=Integer.parseInt(expireByStr);
			}catch(Exception e){
				expireBy=E24onlineConstants.USEREXPIREBYSYSTEM;
				E24onlineLogger.errorLog.error(MODULE + "Error while parsing expire by while creating group" +e);
			}
			
			if(expireBy == E24onlineConstants.USEREXPIREBYDATE){
				String expireTimeStr="23:59:59";
				
				int allotedHour = 0;
				int allotedMin = 0;
				int allotedSec = 0;
				
				try{
					allotedHour = Integer.parseInt(req.getParameter("allotedhour"));
				}catch(Exception e){
					allotedHour = 0;
					E24onlineLogger.appLog.debug("ClientServicesServlet, Exception while parsing hours for GlobalExpireTime:"+e);
				}

				try{
					allotedMin = Integer.parseInt(req.getParameter("allotedmin"));
				}catch(Exception e){
					allotedMin = 0;
					E24onlineLogger.appLog.debug("ClientServicesServlet, Exception while parsing minutes for GlobalExpireTime:"+e);
				}

				try{
					allotedSec = Integer.parseInt(req.getParameter("allotedsec"));
				}catch(Exception e){
					allotedSec = 0;
					E24onlineLogger.appLog.debug("ClientServicesServlet, Exception while parsing seconds for GlobalExpireTime:"+e);
				}
				
				expireTimeStr = (allotedHour > 9 ? String.valueOf(allotedHour): "0" + allotedHour) + ":" +
						  (allotedMin > 9 ? String.valueOf(allotedMin): "0" + allotedMin) + ":" +
						  (allotedSec > 9 ? String.valueOf(allotedSec): "0" + allotedSec);
				
				groupBean.setExpiretime(expireTimeStr);
			}
			
			groupBean.setExpireby(expireBy);
			
			//try{
				
				////if(multipleLoginLimit!=E24onlineConstants.DEFAULTMULTIPLELOGINLIMIT){
				//	groupBean.setLoginlimit(multipleLoginLimit);
			//	}else{
//					IE24onlineNASReaderDAO e24onlinenasreaderDAO=factory.getE24onlineNASReaderDAO();
//					Tble24onlinenasreader cyberoamNASReaderBean = e24onlinenasreaderDAO.getRecordByPrimaryKey(Tble24onlinenasreader.MULTI_LOGIN_LIMIT_FOR_SUDIDM);
//					if(cyberoamNASReaderBean != null){
//						multipleLoginLimit = Integer.parseInt(cyberoamNASReaderBean.getValue()); // getting System wide value
//					}
			//		groupBean.setLoginlimit(E24onlineConstants.DEFAULTMULTIPLELOGINLIMIT);
			//	}
				// Group details has been updated 
				//E24onlineLogger.appLog.debug(MODULE + "Login Limit updated for the Group : "+groupName+" and Set to limit = "+multipleLoginLimit);
				// makes changes for the user affiliated with that group
				/*try{
					IUserDAO userDAO = factory.getUserDAO();
					String sqlQuery = "update Tbluser set loginlimit="+multipleLoginLimit+" where loginlimitrel=1 and groupid="+iGroupid;
					int updateValue = userDAO.getRecordBySQLQuery(sqlQuery);
					E24onlineLogger.appLog.debug(MODULE+" "+updateValue+" Records has been updated");
				}catch(Exception e){
					E24onlineLogger.errorLog.debug(MODULE + "Exception while changing the multisession limit of users of the group id = "+iGroupid+""+e);
				}*/
			//}catch(Exception e){
			//	E24onlineLogger.errorLog.debug(MODULE + "Exception while setting Login Limit"+e);
			//	groupBean.setLoginlimit(E24onlineConstants.DEFAULTMULTIPLELOGINLIMIT);
			//}
			/*** Change By Tejas Shah for adding idle time out time and idle time out value */
			String strIdleTimeoutType = req.getParameter("idletimeouttype");
			String strIdleTimeoutValue = req.getParameter("idletimeout");
			String strIsdefaultIdleTimeOut = req.getParameter("chk_default");
			int idleTimeoutType = E24onlineConstants.LIVE_REQUEST_BASED; 
			int idleTimeoutValue = E24onlineConstants.DEFAULTIDLETIMEOUT;
			
			if(connectionId == E24onlineConstants.LEASEDLINE){
				// for lease line user
				idleTimeoutType = E24onlineConstants.NO_IDLE_TIMEOUT;
				idleTimeoutValue = E24onlineConstants.NO_IDLE_TIMEOUT_VALUE;
			}else{
				// for normal user
				
				try{
					idleTimeoutType = Integer.parseInt(strIdleTimeoutType);
				}catch (Exception e) {
					E24onlineLogger.errorLog.error(MODULE+"Exception in parsing idleTimeoutType"+e,e);
					idleTimeoutType = E24onlineConstants.LIVE_REQUEST_BASED;
					idleTimeoutValue = E24onlineConstants.DEFAULTIDLETIMEOUT;
				}
				
				
				if( strIsdefaultIdleTimeOut != null){
					// Check box is check i.e use default value for idle time out
					try{
						
						E24onlineLogger.appLog.debug(MODULE + "[Testing] :value of check box :"+strIsdefaultIdleTimeOut);
						
						if(strIsdefaultIdleTimeOut.equals("on") ){ // this is for default value
							if(idleTimeoutType ==  E24onlineConstants.NO_IDLE_TIMEOUT){
								// in case of selecting  No Idle Timeout 
								idleTimeoutValue = E24onlineConstants.NO_IDLE_TIMEOUT_VALUE;
							}else{
								// in case of  Live Request Based  & Internet Data Transfer Based  idle time out 
								idleTimeoutValue = E24onlineConstants.DEFAULTIDLETIMEOUT;
							}
							
						}
						
					}catch(Exception e){
							E24onlineLogger.errorLog.error(MODULE + "Exception while parsing Default Idle Timeout:"+e,e);
					}
				}else {
					
					// in case of  Live Request Based  & Internet Data Transfer Based  idle time out with user defined values 
						try{
							
							if(idleTimeoutType ==  E24onlineConstants.NO_IDLE_TIMEOUT){
								// in case of selecting  No Idle Timeout 
								idleTimeoutValue = E24onlineConstants.NO_IDLE_TIMEOUT_VALUE;
							}else{
								// in case of  Live Request Based  & Internet Data Transfer Based  idle time out 
								idleTimeoutValue = Integer.parseInt(strIdleTimeoutValue);
							}
						
						}catch (Exception e) {
							idleTimeoutValue = E24onlineConstants.DEFAULTIDLETIMEOUT;
							E24onlineLogger.errorLog.error(MODULE + "Exception while parsing idle timeout value :"+e,e);
						}

					

				}
			}
			E24onlineLogger.appLog.debug(MODULE + "idle timeout value :"+idleTimeoutValue);
			E24onlineLogger.appLog.debug(MODULE + "idle timeout Type :"+idleTimeoutType);
			groupBean.setIdletimeout(idleTimeoutValue);
			groupBean.setIdletimeouttype(idleTimeoutType);
			
			/*********************************************************************/
			
			int bwpolicyid = 0;
			if (isDataMode) {
				try{
					bwpolicyid = Integer.parseInt(bwPolicyIdStr);
					if (bwpolicyid == 0){
						groupBean.setBwpolicyid(E24onlineConstants.NOBANDWIDTHRESTRICTION);
					}else{ 
						groupBean.setBwpolicyid(bwpolicyid);
					}	
				}catch(Exception e){ 
					groupBean.setBwpolicyid(E24onlineConstants.NOBANDWIDTHRESTRICTION);
				}	
			} else if (isVoIPOnly) {
				bwpolicyid = VoIPConstants.DEFAULTBANDWIDTHPOLICY;
			} else if (isCASOnly) {
				bwpolicyid = CASConstants.DEFAULTBANDWIDTHPOLICY;
			}
			E24onlineLogger.appLog.debug("Value of bandwidthpolicy : "+bwPolicyIdStr+" : "+bwpolicyid);
			
			E24onlineLogger.appLog.debug("Value of bandwidthpolicy : "
					+ bwPolicyIdStr + " : " + bwpolicyid);

			int dtpolicyId = 0;
			try{
				if(!isCASOnly){
					dtpolicyId = Integer.parseInt(dtPolicyIdStr);
					if (dtpolicyId == 0){
						groupBean.setDatatransferpolicyid(E24onlineConstants.UNLIMITEDDATATRANSFERPOLICY);
					}else{ 
						groupBean.setDatatransferpolicyid(dtpolicyId);
					}	
				}else{
					//if is cas only mode.
					dtpolicyId = CASConstants.DEFAULTPREPAIDDATATRANSFERPOLICY;
					groupBean.setDatatransferpolicyid(dtpolicyId);
				}
			}catch(Exception e){ 
				groupBean.setDatatransferpolicyid(E24onlineConstants.UNLIMITEDDATATRANSFERPOLICY);
			}
			E24onlineLogger.appLog.debug("Value of datatransferpolicyid : "+dtPolicyIdStr+" : "+dtpolicyId);
			
			// Check for if Surfing policy is Limited (Walking pkg) then Datatransfer can't Cyclic
			IPolicy policyDao=DAOFactory.instance(DAOFactory.HIBERNATE).getPolicyDao();
			IDataTransferPolicy dataTransferPolicyDao=factory.getDataTransferPolicyDao();
			Tbldatatransferpolicy dtPolicyBean = (Tbldatatransferpolicy)dataTransferPolicyDao.getRecordByPrimaryKey(dtpolicyId);			
			Tblpolicy policyBean = (Tblpolicy)policyDao.getRecordByPrimaryKey(surfingPolicyId);
			
			if (dtPolicyBean != null && policyBean != null && (policyBean.getExpiredays() == E24onlineUtilities.LIMITEDTIMESURFING || policyBean.getAllottedunit() == E24onlineConstants.TIME_UNIT ) && dtPolicyBean.getDatatransfercycletype()!= E24onlineConstants.NONCYCLIC){
				E24onlineLogger.appLog.info("Cyclic Datatransfer Policy Not Possible With Limited Surfing Time Policy: " + E24onlineUtilities.CYCLICDTLIMITEDSURFING);
				res.sendRedirect(req.getContextPath()+"/webpages/grpmgt/addupdategroup.jsp?insertstatus="+E24onlineUtilities.CYCLICDTLIMITEDSURFING);
				return ;
			}
			//End for check for Limited Surfing Time With cyclic policy
			
			groupBean.setPackagetype(billscheme);
			
			int definationType=0;
			String checkBoxReg = req.getParameter("chk_registration");
			String checkBoxRenewal = req.getParameter("chk_renewal");
			
			E24onlineLogger.appLog.debug("Reg CheckBox:" +checkBoxReg);
			E24onlineLogger.appLog.debug("Renew CheckBox:" +checkBoxRenewal);
			
			if (checkBoxReg != null && checkBoxRenewal != null ){
				definationType = E24onlineConstants.REGISTRATIONANDRENEWAL;
			} else {
				if (checkBoxReg != null){
					definationType = E24onlineConstants.REGISTRATION; 
				}
				if (checkBoxRenewal != null){
					definationType = E24onlineConstants.RENEWAL;
				}
			}
			groupBean.setDefination(definationType);
			E24onlineLogger.appLog.debug("Package Type selected : " + definationType);
			
			boolean isRatebasePrepaidGroup = false;
			if (billscheme == E24onlineConstants.POSTPAIDSCHEME){ 
				/**
				 * This should be set to some unlimited policy but temporarily it is set to 1.
				 * Change it afterwards.
				 */
				E24onlineLogger.appLog.debug("**In postpaidscheme");
				//groupBean.setPolicyID(1);
				
				cycleType = req.getParameter("cycletype");
				E24onlineLogger.appLog.debug("**CycleType: "+cycleType);
				cycleMultiplier = req.getParameter("cyclemultiplier");
				E24onlineLogger.appLog.debug("**cycleMultiplier: "+cycleMultiplier);
				E24onlineLogger.appLog.debug("CT:CM:BD : "+cycleType+":"+cycleMultiplier+":"+billDate);
				if ("W".equals(cycleType)){
					billDate = req.getParameter("billdatew");
				}else{ 
					billDate = req.getParameter("billdatem");
				}	
				E24onlineLogger.appLog.debug("CT:CM:BD : "+cycleType+":"+cycleMultiplier+":"+billDate);
				groupBean.setCycletype(cycleType);
				groupBean.setCyclemultiplier(Integer.parseInt(cycleMultiplier));
				groupBean.setBillingdate(Integer.parseInt(billDate));
			}else{
				// This is Prepaid package
				Tbldatatransferpolicy dtPolBean = null;
				if (dtpolicyId!=0){
					dtPolBean = (Tbldatatransferpolicy) dataTransferPolicyDao.getRecordByPrimaryKey(dtpolicyId);
				}
				if (dtPolBean!=null && dtPolBean.getScheme()==E24onlineConstants.POSTPAIDSCHEME){
					// this is ratebased user
					isRatebasePrepaidGroup = true;
				}
			}
			E24onlineLogger.appLog.debug("Price in crate group : "+price);
			String priceStr = dformat.format((Double.valueOf(price)).doubleValue());
			E24onlineLogger.appLog.debug("PriceStr in crate group : "+priceStr);
			groupBean.setPrice( (Double.valueOf(priceStr)).doubleValue());
			groupBean.setGroupstatus(req.getParameter("status"));
			if(isCASMode){
				groupBean.setCountamtbasedon(E24onlineConstants.AMT_BASE_DAYS);
			}else{
				groupBean.setCountamtbasedon(E24onlineConstants.AMT_BASE_NOT_APPLICABLE);
			}
			// START OF SETTING BOD ACCOUNTABLE VALUE
			String bodaccountablevalue = req.getParameter("bodaccountablevalue");
			int iBodAcctValue = E24onlineConstants.AMT_BASE_HOURS;
			if(bodaccountablevalue != null && !"".equals(bodaccountablevalue)){
				iBodAcctValue = (Integer.parseInt(bodaccountablevalue));
			}
			groupBean.setBodaccountablevalue(iBodAcctValue);
			// END OF SETTING BOD ACCOUNTABLE VALUE
			groupBean.setBillcycleamtbasedon(iBillCycleAmtBasedOn);
			groupBean.setQuotaamountbasedon(iQuotaAmountBasedOn);
			String proportionType = req.getParameter("proportiontype");
			E24onlineLogger.appLog.debug("CREATE GROUP : proportionType:"+proportionType);
			if(isCASMode){
				groupBean.setProportiontype(E24onlineConstants.MANUALSERVICEPROPORTION);
			}else{
				groupBean.setProportiontype(proportionType);
			}
			// SETTING PROFIT VALUE
			String profitValue = req.getParameter("profitvalue");
			double dProfitValue = 0;
			if(profitValue != null && !"".equals(profitValue)){
				try{
					dProfitValue = (Double.parseDouble(profitValue));
				}catch(Exception e){
					dProfitValue = 0;
					E24onlineLogger.errorLog.error("CREATE GROUP : Exception while parsing Profit Value : "+e,e);
				}
			}
			groupBean.setProfitvalue(dProfitValue);
			
			// SETTING FAPID
			String fapId = req.getParameter("fapid");
			int iFapId = 0;
			if(fapId != null && !"".equals(fapId)){
				try{
					iFapId = (Integer.parseInt(fapId));
				}catch(Exception e){
					iFapId = E24onlineConstants.NOFAPID;
					E24onlineLogger.errorLog.error("CREATE GROUP : Exception while parsing FAP Id : "+e,e);
				}
			}
			groupBean.setFapid(iFapId);
			
				//setting UrlFilteringId
			String urlfilteringpolicyid = req.getParameter("urlfilteringpolicyid");
			E24onlineLogger.appLog.debug(MODULE+"urlfilteringpolicyid :"+urlfilteringpolicyid);
			int iurlfilteringpolicyid = 0;
			if(urlfilteringpolicyid != null && !"".equals(urlfilteringpolicyid)){
				try{
					iurlfilteringpolicyid = (Integer.parseInt(urlfilteringpolicyid));
					if(iurlfilteringpolicyid == 0){
						groupBean.setUrlfilterpolicyid(E24onlineConstants.NOURLFILTERINGID);
					}else{ 
						groupBean.setUrlfilterpolicyid(iurlfilteringpolicyid);
					}
				}catch(Exception e){
					iurlfilteringpolicyid = E24onlineConstants.NOURLFILTERINGID;
					E24onlineLogger.errorLog.error("CREATE GROUP : Exception while parsing urlfiltering Id : "+e,e);
				}
			}
			//groupBean.setUrlfilterpolicyid(iurlfilteringpolicyid);
			
		/**** Processing for cyberoam group starts ****/
			
			String cyberoamGroupId = req.getParameter("cyberoamgroupid");
			int iCyberoamGroupId = Tblcyberoamgroup.DEFAULT_GROUP_ID;
			
			if(cyberoamGroupId != null && !"".equals(cyberoamGroupId)){
				try{
					iCyberoamGroupId = (Integer.parseInt(cyberoamGroupId));
				}catch(Exception e){
					iCyberoamGroupId = Tblcyberoamgroup.DEFAULT_GROUP_ID;
					E24onlineLogger.errorLog.error(MODULE+"Exception while parsing Cyberoam Group Id : "+e,e);
				}
				E24onlineLogger.appLog.debug(MODULE+"Cyberoam Group Id : "+iCyberoamGroupId);
			}
			groupBean.setCyberoamgroupid(iCyberoamGroupId);
			
			/**** Processing for cyberoam group ends ****/
			
			
			String gatewayServiceId[] = req.getParameterValues("gatewayserviceid");
			String gatewayPorportion[] = req.getParameterValues("gatewayserviceproportion");
			String gatewayDiscount[] = req.getParameterValues("gatewayservicediscount");
			
			Tblratebasedgrouprel ratebasedGroupRelBean = null;			
			if (isRatebasePrepaidGroup){
				int cycleDays = -1;
				double cyclePrice = -1;
				String bbca = "Y";
				try {
					cycleDays = Integer.parseInt(req.getParameter("cycledays").trim());
				}catch(Exception e){
					E24onlineLogger.errorLog.error("CreateGroup: Exception in Parsing CycleDays :" + e);
				}
				try {
					cyclePrice = Double.parseDouble(req.getParameter("cycleprice").trim());
				}catch(Exception e){
					E24onlineLogger.errorLog.error("CreateGroup: Exception in Parsing Cycle Price :" + e);
				}
				try {
					bbca = req.getParameter("underbalaceallowed").trim();
				}catch(Exception e){
					E24onlineLogger.errorLog.error("CreateGroup: Exception in Parsing UnderBalanceAllowed:" + e);
				}
				ratebasedGroupRelBean = new Tblratebasedgrouprel();
				ratebasedGroupRelBean.setGroupid(groupBean.getGroupid());
				ratebasedGroupRelBean.setCycledays(cycleDays);
				ratebasedGroupRelBean.setCycleprice(cyclePrice);
				ratebasedGroupRelBean.setBalancebelowcutoffallowed(bbca);
			}
			
			String popId = req.getParameter("popid");
			String[] zoneIdarray = req.getParameterValues("zoneid");
			String zoneId = E24onlineUtilities.toString(zoneIdarray);
			E24onlineLogger.appLog.debug(MODULE+" zoneid str:"+zoneId);
			
			//Discount Amount Calculation
			double discountAmount = 0 ;
			try{
				if(strDiscount != null){
				discountAmount = Double.parseDouble(strDiscount);
				}
				if (discountAmount > 0 ){
					groupBean.setProportiontype(E24onlineConstants.MANUALSERVICEPROPORTION);
				}
			}catch(Exception e){
				E24onlineLogger.appLog.debug(MODULE + "Service Propertion not found " + e , e);
			}
			
			if (iPackageType == E24onlineConstants.VOIPPACKAGETYPE){
				groupBean.setPolicyid(VoIPConstants.DEFAULTSURFPOLICY);
				groupBean.setAccesspolicyid(VoIPConstants.DEFAULTACCESSPOLICY);
				groupBean.setBwpolicyid(VoIPConstants.DEFAULTBANDWIDTHPOLICY);
			}
			//ankita paul start Ticket1104551 atmosphere
			IClientServices clientServicesDAO = factory.getClientServicesDao();
			Tblclientservices csBean1 = clientServicesDAO.getRecordByPrimaryKey("gatewayipfrompackage");
		    String csValue1 = csBean1.getServicevalue();
		    if(csValue1.equalsIgnoreCase("true")){
		    try {
			String gatewayipaddress = req.getParameter("gatewayipaddress");
			IGatewayDAO gatewaydao = factory.getGatewayDao();
			Tblgateway gatewayBean = gatewaydao.getRecordByKeyandValue("ipaddress", gatewayipaddress);
			groupBean.setGatewayname(gatewayBean.getGatewayname());
			groupBean.setGatewayipaddress(gatewayipaddress);
		    }catch(Exception e) {
		    	E24onlineLogger.appLog.debug(MODULE + "No parameter in gateway name and ipaddress");
		    }
		    }
			//end
			int insertStatus = createGroup(groupBean, isRatebasePrepaidGroup,ratebasedGroupRelBean, gatewayServiceId, gatewayPorportion,gatewayDiscount, popId, loggedInUserName, sourceIPAddress,securityLevel);
			
			if(insertStatus>0 ){
				//if(!ModuleController.isModuleVisible(E24onlineConstants.LOCATIONBASEDPACKAGE)){
					
					HttpSession session = req.getSession(false); 
					
					IPackagePoolBindingDAO packagePoolBindingDAO = factory.getPackagePoolBindingDAO();
					//int deleteStatus = packagePoolBindingDAO.deleteAllPackageBindingByPackageID(iGroupid);
					//E24onlineLogger.appLog.debug(MODULE + "createGroup() Delete All PackagePoolBinding Status : "+deleteStatus+" for poolid:"+ipPoolBean.getPoolid());
					
					//String[] groupIdList = req.getParameterValues("locationbasedpackage[]");
					String[] poolIdList = (String[]) session.getAttribute("poolIdList");
					
					if(poolIdList != null && poolIdList.length > 0) {
						E24onlineLogger.appLog.debug(MODULE+"createGroup() getAttribute : "+poolIdList.length);
						List<Integer> locationPoolList = new ArrayList<Integer>();
						for (String locationPoolid : poolIdList) {
							try {
								locationPoolList.add(Integer.parseInt(locationPoolid));
							} catch (NumberFormatException e) {
								E24onlineLogger.appLog.debug(MODULE + "createPool() PackagePoolBinding Package cannot be parsed with packageid: "+locationPoolid);
							}
						}
						int insertstatus = packagePoolBindingDAO.insertPoolBindingByGroupID(locationPoolList, groupBean.getGroupid());
						E24onlineLogger.audit.info(new AuditObject(AuditObject.PACKAGEPOOLBINDING,"PackagePoolBinding",AuditObject.CREATE,null,"{groupId:"+groupBean.getGroupid()+",PoolIdList:"+locationPoolList.toString()+"}",loggedInUserName,(String)session.getAttribute("ipaddress")));
						E24onlineLogger.appLog.debug(MODULE + "createGroup() insert status: "+insertstatus+" for groupId:"+groupBean.getGroupid()+" PoolIdList:"+locationPoolList.toString());
					}
					else {
						E24onlineLogger.appLog.debug(MODULE + "createGroup() No Pool found for binding.");
					}
			//	}
				if(isCacheQosVisible){
					

					int iCacheId=0;
					String strCacheId=null;

					if (billscheme == E24onlineConstants.PREPAIDSCHEME) {
						if (connectionId == E24onlineConstants.LEASEDLINE) {
							strCacheId = req.getParameter("qosprepaidleasedpolicy");
						}else{
							strCacheId = req.getParameter("qosprepaidpolicy");
						}
						E24onlineLogger.appLog.debug("strCacheId:"+strCacheId); 
						
					} else {
						if (connectionId == E24onlineConstants.LEASEDLINE) {
							strCacheId = req.getParameter("qospostpaidleasedpolicy");
						}else{
							strCacheId = req.getParameter("qospostpaidpolicy");
						}
						E24onlineLogger.appLog.debug("strCacheId:"+strCacheId); 
						
					}
					
					
					if(strCacheId!=null && !"null".equals(strCacheId) && !"".equals(strCacheId)){
						try{
							iCacheId=Integer.parseInt(strCacheId);
						}catch(Exception e){
							E24onlineLogger.errorLog.error(MODULE+"Exception While parsing cache id"+e,e);
						}
					}
					if(iCacheId!=E24onlineConstants.NO_QOS_POLICY){
						E24onlineLogger.appLog.debug(MODULE + "Inside Group Rel DAO");
						IGroupPolicyRelDAO iGroupPolicyRel = factory.getGroupPolicyRelDAO();
						Tblgrouppolicyrel tblGroupPolicyRel = new Tblgrouppolicyrel();
						tblGroupPolicyRel.setGroupid(groupBean.getGroupid());
						tblGroupPolicyRel.setPolicyid(iCacheId);
						tblGroupPolicyRel.setPolicytype(E24onlineConstants.CACHE_QOS);
						
						int insert= iGroupPolicyRel.insert(tblGroupPolicyRel);
						E24onlineLogger.appLog.debug(MODULE + "Insert in group policy rel with Id:" + insert);
						
						//AuditLog
						E24onlineLogger.audit.info(new AuditObject(AuditObject.APP_QOS,groupBean.getGroupname(),AuditObject.CREATEPACKAGE,null,tblGroupPolicyRel.toString(),loggedInUserName,(String)httpSession.getAttribute("ipaddress"),groupBean.getGroupid()));
					}else{
						E24onlineLogger.appLog.debug(MODULE+ "No QoS policy Found , so no insert into tblgrouppolicyrel");
					}
						
				}
				//tblGroupPolicyRel.setType(E24onlineConstants.ca);
				
				// Create Relation between hotel and package
				if(HotelUtilities.IS_MANY_HOTEL && hotelIds != null){
					HotelEntityRelationHelper.createHotelEntityRelation(E24onlineConstants.PACKAGE, insertStatus, hotelIds, securityLevel);
				}
				
			}
				// Add VoIP POlicy to that Group.
			if (isVoIPMode) {
				if (insertStatus > 0) {
					TblVoIPGroupRel voipGroup = new TblVoIPGroupRel();
					voipGroup.setGroupid(insertStatus);
					if (iPackageType == E24onlineConstants.DATAPACKAGETYPE){
						intVoIPPolicyId = VoIPConstants.NOVOIPPOLICY ;
					}
					voipGroup.setVoippolicyid(intVoIPPolicyId);
					int createVoIPGroupStatus = VoIPGroupHelper.createVoIPGroup(voipGroup, loggedInUserName,sourceIPAddress);
					E24onlineLogger.appLog.debug(MODULE + "Insert status after creating VoIP Group = " + createVoIPGroupStatus);
				}
			}
			// End - Add VoIP POlicy to that Group.

			if(isCASMode){
				if(insertStatus>0){
					updateCaswiseFields(req,groupBean,iGroupid);
					/*
					String strCasgroupid = req.getParameter("contentgroup");
					String strCasvalidty = req.getParameter("validity");
					String strCasproductid = req.getParameter("productid");
					String strCasMultipleTV = req.getParameter("multipletvprice");
					int casgroupid=0;
					int casvalidity=0;
					double casmultipletvprice=0.0;
					if(strCasgroupid!=null){
						casgroupid = Integer.parseInt(strCasgroupid);
					}
					if(strCasvalidty!=null){
						casvalidity = Integer.parseInt(strCasvalidty);
					}
					if(strCasMultipleTV!=null){
						casmultipletvprice=Double.parseDouble(strCasMultipleTV);
					}
					if(strCasMultipleTV==null){
						strCasMultipleTV="";
					}
					E24onlineLogger.appLog.debug(MODULE
							+ "Cas Group id:"+casgroupid+"validity:"+casvalidity+" MultiTvPrice:"+casmultipletvprice+" Prod Id:"+strCasproductid);
					
					int casrelstatus = CASGroupRelHelper.updateCasGroups(groupBean,casgroupid,casvalidity,casmultipletvprice,strCasproductid);
					E24onlineLogger.appLog.debug(MODULE + "CAS group rel status: " + casrelstatus);
					
					//Now update the groupid in the addons ...
					int updatestatus = CASGroupAddonsHelper.updateAddonsGroupid(iGroupid,groupBean.getGroupid());
					E24onlineLogger.appLog.debug(MODULE + "CAS addons update group status: " + updatestatus);
					*/
				}
				
			}
			//Enters the Group Relation with its type
			GroupTypeRelationHelper.insertRecord(groupBean.getGroupid(), iPackageType);
			// End - Enters the Group Relation with its type

			if (insertStatus > 0) {
				//Creates Discount Value
				if (discountAmount > 0 ){
					Tblgroupgatewayservice ggBean = new Tblgroupgatewayservice();
					IGroupGatewayServiceDAO groupGatewayServiceDAO = factory.getGroupGatewayServiceDAO();
					
					ggBean.setGroupid(insertStatus);
					ggBean.setGatewayserviceid(E24onlineConstants.DEFAULTGATEWAYSERVICETYPEFORDISCOUNT);
					ggBean.setProportion(E24onlineConstants.DEFAULTSERVICEPROPORTIONFORDISCOUNT);
					ggBean.setDiscount(discountAmount);
					//percentage discount change
					ggBean.setPercentagecheck(strPercentageCheck);
					ggBean.setPercentagediscount(0);
					groupGatewayServiceDAO.insert(ggBean);
				}
				
				E24onlineLogger.appLog.info("Insert Status: " + insertStatus);
				req.setAttribute("groupname",groupName);
				req.setAttribute("insertStatus",Integer.toString(insertStatus));
				if (groupBean.getDefination() == E24onlineConstants.REGISTRATION ){
					req.getRequestDispatcher("/webpages/grpmgt/managegroups.jsp?groupid=" + groupBean.getGroupid()).forward(req,res);
				}else{
					req.getRequestDispatcher("/webpages/grpmgt/addupdategroup.jsp?groupid=" + groupBean.getGroupid()).forward(req,res);
				}
				//res.sendRedirect(req.getContextPath()+"/webpages/grpmgt/addupdategroup.jsp?groupid=" + groupBean.getGroupID() + "&groupname" + groupName +"&insertStatus" +Integer.toString(insertStatus));
			}else{
				E24onlineLogger.appLog.info("Insert Status: " + insertStatus);
				res.sendRedirect(req.getContextPath()+"/webpages/grpmgt/addupdategroup.jsp?insertstatus="+insertStatus);
			}
			
			
		}catch(Exception e){
			E24onlineLogger.errorLog.error("Exception in creategroup:"+e,e);
			res.sendRedirect("/corporate/webpages/error.jsp?errormessage=" + URLEncoder.encode("Error in creating group.") + "&exception="+ URLEncoder.encode(e.toString()));
		}
	}
	
	private static void updateCaswiseFields(HttpServletRequest req,Tblgroup groupBean,int oldGroupId) {
		//String strCasgroupid = req.getParameter("contentgroup");
		//String strContentgroupid = req.getParameter("contentgroup[]");
		String[] strContentgroupidarr = req.getParameterValues("contentgroupid[]");
		String strCasvalidty = req.getParameter("validity");
		String strCasdaystype = req.getParameter("daystype");
		String strCasproductid = req.getParameter("productid");
		String strPrice = req.getParameter("casprice");
		String strCasMultipleTV = req.getParameter("multipletvprice");
		String strCasid = req.getParameter("casid");
		
		List<String> casgroupidlist=null;
		int daystype=E24onlineConstants.DAILY;
		int casvalidity=0;
		double casprice = 0.0;
		double casmultipletvprice=0.0;
		int casid = 0;
		if(strContentgroupidarr!=null && strContentgroupidarr.length>0){
			String strcontentgroup = E24onlineUtilities.toString(strContentgroupidarr);
			E24onlineLogger.appLog.debug(MODULE+" content groupid:"+strcontentgroup);
			casgroupidlist = E24onlineUtilities.toArrayListFromString(strcontentgroup);
		}else{
			E24onlineLogger.appLog.debug(MODULE+" content groupid not found:"+strContentgroupidarr);
		}
		
		if(strCasdaystype!=null){
			try{
				daystype=Integer.parseInt(strCasdaystype);
			}catch (Exception e) {
				E24onlineLogger.appLog.debug(MODULE+" updateCaswiseFields err in parsing daystype:"+e);
			}
		}
		
		if(strCasvalidty!=null){
			casvalidity = Integer.parseInt(strCasvalidty);
		}
		if(daystype==E24onlineConstants.MONTHLY){
			E24onlineLogger.appLog.debug(MODULE+" updateCaswiseFields casvalidity:"+casvalidity+" daystype:"+daystype);
			casvalidity= casvalidity*30; 
		}else if(daystype==E24onlineConstants.YEARLY){
			E24onlineLogger.appLog.debug(MODULE+" updateCaswiseFields casvalidity:"+casvalidity+" daystype:"+daystype);
			casvalidity= casvalidity*365; 
		}
		if(isCASOnly){
			casprice = groupBean.getPrice();
		}else{
			if(strPrice!=null){
				casprice=Double.parseDouble(strPrice);
			}
		}
		if(strCasMultipleTV!=null){
			casmultipletvprice=Double.parseDouble(strCasMultipleTV);
		}
		if(strCasMultipleTV==null){
			strCasMultipleTV="";
		}
		if(strCasid!=null){
			casid=Integer.parseInt(strCasid);
		}
		if(strCasid==null){
			casid=0;
		}
		E24onlineLogger.appLog.debug(MODULE+" arr:"+strContentgroupidarr
				+ " Cas Group id:"+casgroupidlist+" validity:"+casvalidity+" MultiTvPrice:"+casmultipletvprice+" Prod Id:"+strCasproductid + "CAS Id:"+casid);
		
		int casrelstatus = GroupCASRelHelper.updateCasGroups(groupBean,casprice,casvalidity,casmultipletvprice,strCasproductid,casid);
		E24onlineLogger.appLog.debug(MODULE + "CAS group rel status: " + casrelstatus);
		if(casrelstatus>=CASConstants.SUCCESSFUL){
			GroupCASRelDetailHelper detailHelper = new GroupCASRelDetailHelper();
			int casdetailstatus =  detailHelper.updateConentGroupDetail(groupBean.getGroupid() ,casgroupidlist);
			E24onlineLogger.appLog.debug(MODULE + "CAS group rel detail status: " + casdetailstatus);

			//Now update the groupid in the addons ...
			int updatestatus = CASGroupAddonsHelper.updateAddonsGroupid(oldGroupId,groupBean.getGroupid());
			E24onlineLogger.appLog.debug(MODULE + "CAS addons update group status: " + updatestatus);
		}
		
	}

	public static int createGroup(Tblgroup groupBean, boolean isRatebasePrepaidGroup, Tblratebasedgrouprel ratebasedGroupRelBean, String[] gatewayServiceId, String[] gatewayPorportion, String[] gatewayDiscount, String popId, String createBy, String sourceIPAddress, int securityLevel) throws Exception {
		return createGroup(groupBean, isRatebasePrepaidGroup, ratebasedGroupRelBean, gatewayServiceId, gatewayPorportion, gatewayDiscount, popId, new Integer(E24onlineConstants.ALLOWEDFROMALLZONE).toString(), createBy, sourceIPAddress, securityLevel);
	}
	
	public static int createGroup(Tblgroup groupBean, boolean isRatebasePrepaidGroup, Tblratebasedgrouprel ratebasedGroupRelBean, String[] gatewayServiceId, String[] gatewayPorportion, String[] gatewayDiscount, String popId, String zoneId, String createBy, String sourceIPAddress, int securityLevel) throws Exception {
		
		if(groupBean.getConnectiontype() == E24onlineConstants.LEASEDLINE){
			groupBean.setAccesspolicyid(E24onlineUtilities.OPENPOLICY);
			groupBean.setNetsecenabled("N");
		}
		if(!(ModuleController.isModuleVisible(E24onlineConstants.NETWORKSECURITY))){
			groupBean.setNetsecenabled("N");
		}
		if(!(ModuleController.isModuleVisible(E24onlineConstants.PAYMENTGATEWAY)) && !(HMSUtilities.isHotelFlowOn()) && !(ModuleController.isModuleVisible(E24onlineConstants.ISSERIALIDENABLE))){
			groupBean.setOnlinepurchase("N");
		}
		//Added by bhavesh to put check for create package from webservice
		if(groupBean.getPackagetype() == E24onlineConstants.POSTPAIDSCHEME && groupBean.getPolicyid() == 0) {
			groupBean.setPolicyid(1);
		}
		
		if(isCASMode){
			groupBean.setNetsecenabled("Y");
		}
		E24onlineLogger.appLog.debug("GroupBean: " + groupBean);
		
		if (isVoIPOnly){
			groupBean.setPolicyid(VoIPConstants.DEFAULTSURFPOLICY);
			groupBean.setAccesspolicyid(VoIPConstants.DEFAULTACCESSPOLICY);
			groupBean.setBwpolicyid(VoIPConstants.DEFAULTBANDWIDTHPOLICY);
		}
		if(isCASOnly){
			groupBean.setPolicyid(CASConstants.DEFAULTSURFPOLICY);
			groupBean.setAccesspolicyid(CASConstants.DEFAULTACCESSPOLICY);
			groupBean.setBwpolicyid(CASConstants.DEFAULTBANDWIDTHPOLICY);
		}
		
		
		
		E24onlineLogger.appLog.debug("GroupBean: " + groupBean);
		IGroupDAO groupDAO = factory.getGroupDAO();
		int insertStatus = groupDAO.insert(groupBean);
		
		if(insertStatus > 0){
			E24onlineLogger.audit.info(new AuditObject(AuditObject.PACKAGE,groupBean.getGroupname(),AuditObject.CREATEPACKAGE,null,groupBean.toString(),createBy,sourceIPAddress,groupBean.getGroupid()));
			Tblgroupgatewayservice groupGatewayServiceBean = null;
			IGroupGatewayServiceDAO groupGatewayServiceDAO = factory.getGroupGatewayServiceDAO();
			int serviceProportionStatus = -1;
			if(groupBean.getProportiontype().equals(E24onlineConstants.MANUALSERVICEPROPORTION)&& isMultipleServicesInvoiceVisible) {
				int iGatewayServiceId = 0;
				double dGatewayProportion = 0;
				double dGatewayDiscount = 0;
				
				for(int i=0; i<gatewayServiceId.length; i++){
					
					iGatewayServiceId = 0;
					dGatewayProportion = 0;
					dGatewayDiscount = 0;
					
					if(gatewayServiceId[i] != null){
						try{
							iGatewayServiceId = Integer.parseInt(gatewayServiceId[i]);
						}catch(Exception e){
							E24onlineLogger.errorLog.error("CREATE GROUP,Exception while parsing Gateway Service Id :"+e,e);
						}
					}
					if(gatewayPorportion[i] != null){
						try{
							dGatewayProportion = Double.parseDouble(gatewayPorportion[i]);
						}catch(Exception e){
							E24onlineLogger.errorLog.error("CREATE GROUP,Exception while parsing Gateway Service Proportion :"+e,e);
						}
					}
					if(gatewayDiscount != null && gatewayDiscount[i] != null){
						try{
							dGatewayDiscount = Double.parseDouble(gatewayDiscount[i]);
						}catch(Exception e){
							E24onlineLogger.errorLog.error("CREATE GROUP,Exception while parsing Gateway Service Discount :"+e,e);
						}
					}
					groupGatewayServiceBean = new Tblgroupgatewayservice();
					
					groupGatewayServiceBean.setGroupid(groupBean.getPrimaryKey());
					groupGatewayServiceBean.setGatewayserviceid(iGatewayServiceId);
					groupGatewayServiceBean.setProportion(dGatewayProportion);
					groupGatewayServiceBean.setDiscount(dGatewayDiscount);
					
					serviceProportionStatus = groupGatewayServiceDAO.insert(groupGatewayServiceBean);
					
				}
				E24onlineLogger.appLog.debug("CREATE GROUP : serviceProportionStatus:" + serviceProportionStatus);
			}
			
			if (isRatebasePrepaidGroup){
				IRateBasedGroupRelationDAO rateBasedGroupRelationDAO = factory.getRateBasedGroupRelationDAO();
				int rateRelInsertStatus = rateBasedGroupRelationDAO.insert(ratebasedGroupRelBean);
				E24onlineLogger.appLog.debug("CreateGroup: RatebasedGroupRel Insert Status:" + rateRelInsertStatus + " for group id:" + ratebasedGroupRelBean.getGroupid()); 
			}
			
			// set default all package rule for packages of renewal type
			if(groupBean.getDefination() == E24onlineConstants.REGISTRATIONANDRENEWAL ||
			   groupBean.getDefination() == E24onlineConstants.RENEWAL ){	
				E24onlineLogger.appLog.debug("Adding ALL PACKAGE Rule");
				Tblrenewalrule renewRuleBean = new Tblrenewalrule();
				IRenewalRuleDAO renewalRuleDAO = factory.getRenewalRuleDAO();
				renewRuleBean.setNewpackageid(insertStatus);
				renewRuleBean.setOldpackageid(E24onlineUtilities.ALLPACKAGES);
				
				renewRuleBean.setShifttonew(E24onlineConstants.ALLOWED);
				
				renewRuleBean.setCarryforwardhours(E24onlineConstants.NOTALLOWED);
				renewRuleBean.setCarryforwardduration(E24onlineConstants.NOTALLOWED);
				renewRuleBean.setCarryforwarddatatransfer(E24onlineConstants.NOTALLOWED);
				if (isCASMode){
					renewRuleBean.setRenewalruleamtflag(E24onlineConstants.ALLOWED);
					renewRuleBean.setAddvaluebasedon(E24onlineConstants.AMT_BASE_DAYS);
				}else{
					renewRuleBean.setRenewalruleamtflag(E24onlineConstants.NOTALLOWED);
					renewRuleBean.setAddvaluebasedon(E24onlineConstants.AMT_BASE_NOT_APPLICABLE);
				}
				
				renewalRuleDAO.insert(renewRuleBean);
			}
			
			
		}
		
		// Insert Default Ancillary Serivce Values and Tax Values
		if( insertStatus > 0 ){
			CreateGroup.insertDefaultAncAndTaxValues(E24onlineConstants.GROUPANCILLARYSERVICEREL,insertStatus);								
		}
		
		if(insertStatus > 0 ){
			IZoneDao zoneDao = factory.getZoneDao();
			int groupId = insertStatus;
			// Insert in Entity Zone Relation only when POP Mgmt. customization is enabled
			if(isPOPEnabled){
				ArrayList zoneIdListForPop = null;
				int iPopId = E24onlineConstants.NOPOPSELECTED;
				if(popId != null && !("").equals(popId)){
					try{
						iPopId = Integer.parseInt(popId);
					}catch(Exception e){
						E24onlineLogger.errorLog.error("Create Package, Exception while parsing Pop Id :"+e,e);
					}
				}
				
			//Pop Zone Changes mohit
				
				if(iPopId > 0){
					
					
				//	zoneIdListForPop = zoneDao.getZoneIdListByPOPId(iPopId);
					String izoneid = E24onlineConstants.ALLOWEDFROMALLZONE+"";
					if(zoneId!=null && !zoneId.equals("") && !zoneId.equalsIgnoreCase("null")){
						izoneid = zoneId;
					}
				//	if(zoneIdListForPop != null && zoneIdListForPop.size() > 0){
						EntityZoneRelation.createEntityZoneRelation(E24onlineConstants.PACKAGE,groupId,iPopId,izoneid,securityLevel);
				//	}
				}									
			}else if(isZoneEnabled){
				//If pop is off, then all zone will be inserted for that package..
			//	ArrayList zoneIdListForPop = null;
				int iPopId = E24onlineConstants.NOPOPSELECTED;
				String izoneid = E24onlineConstants.ALLOWEDFROMALLZONE+"";
				if(zoneId!=null && !zoneId.equals("") && !zoneId.equalsIgnoreCase("null")){
					izoneid = zoneId;
				}
		//		zoneIdListForPop = zoneDao.getZoneIdList();
			//	if(zoneIdListForPop != null && zoneIdListForPop.size() > 0){
					EntityZoneRelation.createEntityZoneRelation(E24onlineConstants.PACKAGE,groupBean.getGroupid(),iPopId,izoneid,securityLevel);
				//}
				
			}
		}
		return insertStatus;
		
	}
	
	public static void createGroupFromDashboard(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
		E24onlineLogger.appLog.debug( MODULE+" createGroupFromDashboard() called");
		
		String groupName = null;
		String bwPolicyId = null;
		String allottedMinutes = null;
		String allottedDays = null;
		String price = null;
		String onlinePurchase = null;		
		
		int iBWPolicyId = E24onlineConstants.NOBANDWIDTHRESTRICTION;
		int iSurfingPolicyId = E24onlineConstants.VALUENOTPROVIDED; 
		int iAllottedMinutes = E24onlineConstants.VALUENOTPROVIDED;
		int iAllottedDays = E24onlineConstants.VALUENOTPROVIDED;
		double dPrice = 0;
		
		HttpSession session = req.getSession(false);
		String loggedInUserName = (String)session.getAttribute("user");
		
		Tblgroup groupBean = null;
		int insertValue = -1;
		int iGroupId = -1;
		
		try{
			groupName = req.getParameter("groupname_add");
			bwPolicyId = req.getParameter("bwpolicyid_add");
			allottedMinutes = req.getParameter("allottedminutes_add");
			allottedDays = req.getParameter("allotteddays_add");
			price = req.getParameter("price_add");
			onlinePurchase = req.getParameter("onlinepurchase_add");						
			
			if(bwPolicyId != null && !("").equals(bwPolicyId) && !("null").equalsIgnoreCase(bwPolicyId)){
				try{
					iBWPolicyId = Integer.parseInt(bwPolicyId);
					if(iBWPolicyId == 0){
						iBWPolicyId = E24onlineConstants.NOBANDWIDTHRESTRICTION;
					}
				}catch(Exception e){
					iBWPolicyId = E24onlineConstants.NOBANDWIDTHRESTRICTION;
					E24onlineLogger.errorLog.error(MODULE + "createGroupFromDashboard(), Exception while parsing BW Policy Id : "+e,e);
				}
			}
			
			if(allottedMinutes != null && !("").equals(allottedMinutes) && !("null").equalsIgnoreCase(allottedMinutes)){
				try{
					iAllottedMinutes = Integer.parseInt(allottedMinutes);
				}catch(Exception e){
					iAllottedMinutes = E24onlineConstants.VALUENOTPROVIDED;
					E24onlineLogger.errorLog.error(MODULE + "createGroupFromDashboard(), Exception while parsing Allotted Minutes : "+e,e);
				}
			}
			
			if(allottedDays != null && !("").equals(allottedDays) && !("null").equalsIgnoreCase(allottedDays)){
				try{
					iAllottedDays = Integer.parseInt(allottedDays);
				}catch(Exception e){
					iAllottedDays = E24onlineConstants.VALUENOTPROVIDED;
					E24onlineLogger.errorLog.error(MODULE + "createGroupFromDashboard(), Exception while parsing Allotted Days : "+e,e);
				}
			}
			
			if(price != null && !("").equals(price) && !("null").equalsIgnoreCase(price)){
				try{
					dPrice = Double.parseDouble(price);
				}catch(Exception e){
					E24onlineLogger.errorLog.error(MODULE + "createGroupFromDashboard(), Exception while parsing Price : "+e,e);
				}
			}
			IPolicy policyDao=DAOFactory.instance(DAOFactory.HIBERNATE).getPolicyDao();
			iSurfingPolicyId = policyDao.getPolicyIdByAllottedMin_AllottedDays(iAllottedMinutes,iAllottedDays);
			
			if(onlinePurchase == null || ("").equals(onlinePurchase) || ("null").equalsIgnoreCase(onlinePurchase)){
				onlinePurchase = "N";
			}
			
			groupBean = new Tblgroup();	
						
			groupBean.setGroupname(groupName);
			groupBean.setNetsecenabled("Y");
			groupBean.setOnlinepurchase(onlinePurchase);
			groupBean.setConnectiontype(E24onlineConstants.NORMALLINE);
			groupBean.setPolicyid(iSurfingPolicyId);
			groupBean.setAccesspolicyid(1);
			groupBean.setDescription(null);
			groupBean.setPoolid(0);
			groupBean.setIdletimeout(E24onlineConstants.DEFAULTIDLETIMEOUT);
			groupBean.setBwpolicyid(iBWPolicyId);
			groupBean.setDatatransferpolicyid(E24onlineConstants.UNLIMITEDDATATRANSFERPOLICY);
			groupBean.setPackagetype(E24onlineConstants.PREPAIDSCHEME);
			groupBean.setDefination(E24onlineConstants.REGISTRATIONANDRENEWAL);
			groupBean.setPrice(dPrice);
			groupBean.setGroupstatus("Y");
			if(isCASMode){
				groupBean.setCountamtbasedon(E24onlineConstants.AMT_BASE_DAYS);
				groupBean.setProportiontype(E24onlineConstants.MANUALSERVICEPROPORTION);
			}else{
				groupBean.setCountamtbasedon(E24onlineConstants.AMT_BASE_NOT_APPLICABLE);
				groupBean.setProportiontype(E24onlineConstants.DEFAULTSERVICEPROPORTION);
			}
			
			groupBean.setBodaccountablevalue(E24onlineConstants.AMT_BASE_HOURS);
			
			groupBean.setProfitvalue(0);
			groupBean.setFapid(E24onlineConstants.NOFAPID);

			if (isVoIPOnly){
				groupBean.setPolicyid(VoIPConstants.DEFAULTSURFPOLICY);
				groupBean.setAccesspolicyid(VoIPConstants.DEFAULTACCESSPOLICY);
				groupBean.setBwpolicyid(VoIPConstants.DEFAULTBANDWIDTHPOLICY);
			}
			if(isCASOnly){
				groupBean.setPolicyid(CASConstants.DEFAULTSURFPOLICY);
				groupBean.setAccesspolicyid(CASConstants.DEFAULTACCESSPOLICY);
				groupBean.setBwpolicyid(CASConstants.DEFAULTBANDWIDTHPOLICY);
			}
			
			if(isGraceDaysVisible && isGraceDaysEnable){
				IClientServices clientServicesDAO = factory.getClientServicesDao();
				int gracedaysvalue=Integer.parseInt(clientServicesDAO.getValueByKey("System_Gracedays"));
				groupBean.setGracedays(gracedaysvalue);
				groupBean.setGracedaysrel(E24onlineConstants.SYSTEM_LOGIN_LIMIT_REL);
			}
			IGroupDAO groupDAO = factory.getGroupDAO();
			insertValue = groupDAO.insert(groupBean);
			E24onlineLogger.appLog.debug(MODULE + " createGroupFromDashboard(), insertValue : "+insertValue);
			
			if(insertValue >0){	
				iGroupId = insertValue;
				
				E24onlineLogger.appLog.debug(MODULE + " createGroupFromDashboard(), Adding ALL PACKAGE Rule");
				Tblrenewalrule renewRuleBean = new Tblrenewalrule();
				IRenewalRuleDAO renewalRuleDAO = factory.getRenewalRuleDAO();
				renewRuleBean.setNewpackageid(iGroupId);
				renewRuleBean.setOldpackageid(E24onlineUtilities.ALLPACKAGES);				
				renewRuleBean.setShifttonew(E24onlineConstants.ALLOWED);				
				renewRuleBean.setCarryforwardhours(E24onlineConstants.NOTALLOWED);
				renewRuleBean.setCarryforwardduration(E24onlineConstants.NOTALLOWED);
				renewRuleBean.setCarryforwarddatatransfer(E24onlineConstants.NOTALLOWED);
				renewRuleBean.setRenewalruleamtflag(E24onlineConstants.NOTALLOWED);
				renewRuleBean.setAddvaluebasedon(E24onlineConstants.AMT_BASE_NOT_APPLICABLE);
				renewalRuleDAO.insert(renewRuleBean);
				
				CreateGroup.insertDefaultAncAndTaxValues(E24onlineConstants.GROUPANCILLARYSERVICEREL,iGroupId);
				
				E24onlineLogger.audit.info(new AuditObject(AuditObject.PACKAGE,groupBean.getGroupname(),AuditObject.CREATEPACKAGE,null,groupBean.toString(),loggedInUserName,(String)session.getAttribute("ipaddress"),groupBean.getGroupid()));									
			}
		}catch(Exception e){
			insertValue = E24onlineUtilities.ERROR;
			E24onlineLogger.errorLog.error( MODULE+" createGroupFromDashboard(), Exception occured : " +e,e);
		}
		
		res.sendRedirect(req.getContextPath()+"/webpages/dashboard/manageplans.jsp?insertstatus="+insertValue+"&groupname="+groupName);		
	}
	
	public static int insertDefaultAncAndTaxValues(String relationType, int relationId){
		int insertValue = -1;
		String insertAncValues = null;
		String insertTaxableAncValues = null;
		String insertTaxInfoValues = null;
		//String insertTaxonTaxInfoValues = null;
		SqlReader sqlReader = null;
		ArrayList ancillaryServiceRelKeyList = null;
		ArrayList<Integer> taxInfoRelKeyList = null;
		
		int ancillaryServiceRelId = 0;
		int taxInfoRelId = 0;
		
		try
		{
			sqlReader = new SqlReader(false);
			IAncillaryServiceRelDAO ancillaryServiceRelDAO = factory.getAncillaryServiceRelDAO();
			ancillaryServiceRelKeyList = (ArrayList<Integer>) ancillaryServiceRelDAO.getPrimaryKeyCollection( "where relationtype = "+SqlMaker.makeString(E24onlineConstants.DEFAULTANCILLARYSERVICEREL)+" and relationid="+E24onlineConstants.DEFAULTANCILLARYSERVICERELID);
			
			if(ancillaryServiceRelKeyList != null){
				
				for(int i=0;i<ancillaryServiceRelKeyList.size();i++){
					ancillaryServiceRelId = E24onlineUtilities.getNextSequenceKey("tblancillaryservicerel_seq");
					
					insertAncValues = "insert into tblancillaryservicerel " +
					"( ancillaryservicerelid,relationid,relationtype,ancillaryserviceid,chargetype,chargevalue,internetserviceid,invoicegenerated ) "+
					"( select " +
					ancillaryServiceRelId  + ", " +
					relationId  + ", " +
					SqlMaker.makeString(relationType)  + ", " +
					"ancillaryserviceid, chargetype, chargevalue,internetserviceid,invoicegenerated from tblancillaryservicerel "  +
					"where ancillaryservicerelid="+ancillaryServiceRelKeyList.get(i)+ 
					" )";
					
					E24onlineLogger.appLog.debug( "Ancillary Serivce Relation Query :"+insertAncValues);
					insertValue = sqlReader.executeUpdate(insertAncValues,PropertyReader.QUERYTIMEOUT);
					E24onlineLogger.appLog.debug( "Ancillary Serivce Relation insertValue :"+insertValue);
					
					insertTaxableAncValues = "insert into tbltaxableancservice " +
					"( ancillaryservicerelid,taxinfoid,taxvalue ) "+
					"( select " +					
					ancillaryServiceRelId  + ", " +
					"taxinfoid,taxvalue from tbltaxableancservice "  +
					"where ancillaryservicerelid="+ancillaryServiceRelKeyList.get(i)+ 
					" )";
				
					if (insertValue > 0){
						E24onlineLogger.appLog.debug( "Tax On Ancillary Serivce Query :"+insertTaxableAncValues);
						insertValue = sqlReader.executeUpdate(insertTaxableAncValues,PropertyReader.QUERYTIMEOUT);
						E24onlineLogger.appLog.debug( "Tax On Ancillary Serivce insertValue :"+insertValue);
					}
				} // loop over
			} // if over
			
			ITaxInfoRelDAO taxInfoRelDAO = factory.getTaxInfoRelDAO();
			taxInfoRelKeyList = (ArrayList<Integer>) taxInfoRelDAO.getPrimaryKeyCollection( "where relationtype = "+SqlMaker.makeString(E24onlineConstants.DEFAULTANCILLARYSERVICEREL)+" and relationid="+E24onlineConstants.DEFAULTANCILLARYSERVICERELID);
			
			if(taxInfoRelKeyList != null){
							
				for(int i=0;i<taxInfoRelKeyList.size();i++){
					taxInfoRelId = E24onlineUtilities.getNextSequenceKey("tbltaxinforel_seq");
					
					insertTaxInfoValues = "insert into tbltaxinforel " +
					"( taxinforelid,relationid,relationtype,taxtype,taxinfoid,taxvalue,internetserviceid ) "+
					"( select " +					
					taxInfoRelId  + ", " +
					relationId  + ", " +
					SqlMaker.makeString(relationType)  + ", " +
					"taxtype,taxinfoid,taxvalue,internetserviceid from tbltaxinforel "  +
					"where taxinforelid="+taxInfoRelKeyList.get(i)+ 
					" )";
					
					E24onlineLogger.appLog.debug( "Tax Info Relation Query :"+insertAncValues);
					insertValue = sqlReader.executeUpdate(insertTaxInfoValues,PropertyReader.QUERYTIMEOUT);
					E24onlineLogger.appLog.debug( "Tax Info Relation insertValue :"+insertValue);
					
					Tbltaxontaxableamt taxtaxontaxableamt = new Tbltaxontaxableamt();
					
					ITaxOnTaxableAmountDAO taxOnTaxableAmountDAO = factory.getTaxOnTaxableAmountDAO();
					List<Tbltaxontaxableamt> listByCondition = taxOnTaxableAmountDAO.getListByCondition("WHERE taxinforelid = "+taxInfoRelKeyList.get(i));
					if(listByCondition != null && listByCondition.size() > 0){
						Tbltaxontaxableamt tbltaxontaxableamt = listByCondition.get(0);
						taxtaxontaxableamt.setTaxvalue(tbltaxontaxableamt.getTaxvalue());
						taxtaxontaxableamt.setTaxinfoid(tbltaxontaxableamt.getTaxinfoid());
						taxtaxontaxableamt.setTaxinforelid(taxInfoRelId);
						
						insertValue = taxOnTaxableAmountDAO.insert(taxtaxontaxableamt);
						
						E24onlineLogger.appLog.debug( "Tax On Tax Info Rel insertValue :"+insertValue);
					}
					/*
					insertTaxonTaxInfoValues = "insert into tbltaxontaxableamt " +
					"( taxinforelid,taxinfoid,taxvalue ) "+
					"( select " +					
					taxInfoRelId  + ", " +
					"taxinfoid,taxvalue from tbltaxontaxableamt "  +
					"where taxinforelid="+taxInfoRelKeyList.get(i)+ 
					" )";
					if (insertValue > 0){
						E24onlineLogger.appLog.debug( "Tax On Tax Info Rel Query :"+insertTaxonTaxInfoValues);
						insertValue = sqlReader.executeUpdate(insertTaxonTaxInfoValues,PropertyReader.QUERYTIMEOUT);
						E24onlineLogger.appLog.debug( "Tax On Tax Info Rel insertValue :"+insertValue);
					}
					*/
					
				} // loop over
			} // if over
			
			TaxableAncServiceDAO.loadAll(); 
			TaxOnTaxableAmountDAO.loadAll();
			
		}
		catch(Exception e)
		{
			insertValue = E24onlineUtilities.ERROR;
			E24onlineLogger.errorLog.error("insertDefaultAncAndTaxValues(), Got an exception while inserting record: " + e,e);
		}
		finally{
			
			try{
				sqlReader.close();
			}catch(Exception e){
				E24onlineLogger.errorLog.error("insertDefaultAncAndTaxValues(), Error in closing sqlReader: " + e,e);
			}
		}
		return insertValue;
	}
	
	/**
	 * It will create runtime package when Event got activated.
	 * @param groupName
	 * @param surfingPolicyId
	 * @param accessPolId
	 * @param bwPolicyId
	 * @param dtPolicyId
	 * @return
	 */
	public static int createGroupForEvent(String groupName,int surfingPolicyId,int accessPolId,int bwPolicyId,int dtPolicyId ,int poolId ,int totalGuests,double price){
		E24onlineLogger.appLog.info(MODULE + "Inside createGroupForEvent, groupName : "+groupName +",SurfingPolicyId : "+surfingPolicyId +" ,AccessPolicyId:" +accessPolId +" ,BandwidthPolicyId : "+bwPolicyId + ",DatatransferPolicyId :" +dtPolicyId + ",PoolId :" +poolId + ",Total guests:" +totalGuests + ",Price :" +price);
		int retStatus=0;
		Tblgroup groupBean=null;
		
		try{
			// Create Group
			groupBean = new Tblgroup();
			groupBean.setGroupname(groupName);
			groupBean.setOnlinepurchase("N");	
			groupBean.setPolicyid(surfingPolicyId);	
			groupBean.setAccesspolicyid(accessPolId);
			groupBean.setBwpolicyid(bwPolicyId);				
			groupBean.setDatatransferpolicyid(dtPolicyId);
			groupBean.setProfileid(0);	
			groupBean.setConnectiontype(E24onlineConstants.NORMALLINE);// Set the connection type (Leased or normal);
			groupBean.setRadiuspolicyid(0);	
			groupBean.setDescription(null);	
			groupBean.setCreditlimit(0D);				
			groupBean.setPoolid(poolId);				
			groupBean.setLoginlimit(totalGuests);								
			groupBean.setIdletimeout(E24onlineConstants.NO_IDLE_TIMEOUT);				
			groupBean.setIdletimeouttype(E24onlineConstants.NO_IDLE_TIMEOUT);				
			groupBean.setPackagetype(E24onlineConstants.PREPAIDSCHEME);				
			groupBean.setDefination(E24onlineConstants.REGISTRATIONANDRENEWAL);				
			groupBean.setPrice(price);				
			groupBean.setGroupstatus(E24onlineConstants.ACTIVEPACKAGE);				
			groupBean.setCountamtbasedon(E24onlineConstants.AMT_BASE_NOT_APPLICABLE);				
			groupBean.setBodaccountablevalue(E24onlineConstants.AMT_BASE_HOURS);				
			groupBean.setBillcycleamtbasedon(E24onlineConstants.FULLAMTBASEDONBILLCYCLE);
			groupBean.setQuotaamountbasedon(E24onlineConstants.FULLAMTBASEDONBILLCYCLE);
			groupBean.setProfitvalue(0);
			groupBean.setFapid(0);
			groupBean.setCyberoamgroupid(Tblcyberoamgroup.DEFAULT_GROUP_ID);
			groupBean.setProportiontype(E24onlineConstants.MANUALSERVICEPROPORTION);

			retStatus = createGroup(groupBean,false,null,null,null,null,"0","System",null,E24onlineConstants.CYBEROAMADMINUSER);
			
		}catch(Exception e){
			E24onlineLogger.errorLog.error(MODULE + "Error in create group for Event" +e,e);
		}
		
		return retStatus;
	}
}
