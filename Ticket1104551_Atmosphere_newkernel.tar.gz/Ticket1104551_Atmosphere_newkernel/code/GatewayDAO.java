package e24online.corporate.systemmgt.dao.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;

import com.elitecore.hibernate.base.DAOFactory;
import com.elitecore.hibernate.base.GenericDAOImpl;
import com.elitecore.jdbchelper.SqlMaker;

import e24online.corporate.policy.dao.base.IGroupDAO;
import e24online.corporate.systemmgt.dao.ibase.IGatewayDAO;
import e24online.corporate.systemmgt.dao.ibase.IGatewayNetworkRelDAO;
import e24online.corporate.systemmgt.entity.Tblgateway;
import e24online.corporate.utilities.MessageConstants;
import e24online.log.E24onlineLogger;
import e24online.utilities.E24onlineUtilities;

public class GatewayDAO extends GenericDAOImpl<Tblgateway,Integer> implements IGatewayDAO{
	public static final int INTERFACEISNULL = -10;
	private static final String MODULE = "[GATEWAYDAO]";
	private static TreeMap<Integer,Tblgateway> gatewayBeanMap = null ;
	private static ArrayList<Integer> gatewayTableIdList = null ;
	public static int DEFAULTGATEWAY = -10;
	
	 private static DAOFactory factory=null;
	 static{
		 factory=DAOFactory.instance(DAOFactory.HIBERNATE);
		 loadAll();
	 }
	public static synchronized boolean loadAll(){
		
		E24onlineLogger.appLog.debug(MODULE+"loadAll() Called ");
		try{
			if(gatewayBeanMap!=null){
				return true;
			}
			GatewayDAO gatewayDAO=new GatewayDAO();
			List<Tblgateway> gatewayList =gatewayDAO.getList();
			gatewayBeanMap=new TreeMap<Integer, Tblgateway>();
			if(gatewayList!=null && !gatewayList.isEmpty()){
				for(Tblgateway gatewayBean : gatewayList){
					gatewayBeanMap.put(gatewayBean.getGatewayid(), gatewayBean);
				}
				E24onlineLogger.appLog.debug(MODULE+"loadAll exit with gatewayBeanMap.size()="+gatewayBeanMap.size());
			}else{
				E24onlineLogger.appLog.debug(MODULE+"loadAll exit with gatewayBeanMap.size()= 0");
			}
			
		}catch(Exception e){
			E24onlineLogger.errorLog.error(MODULE +"Exception found at loadAll"+e,e);
			return false;
		}
		return true;
		
	}
	

	public TreeMap<Integer,Tblgateway> getGatewayBeanMap(){ 
		if (gatewayBeanMap == null){
			loadAll();
		}
		return gatewayBeanMap;
	}
	
	
	public Tblgateway getRecordByPrimaryKey(int primaryKey){
		
		Tblgateway gwBean = null;
		
		try{
			if((gatewayBeanMap != null ) &&
			   (gwBean = gatewayBeanMap.get(new Integer(primaryKey))) != null){
			}else{
				if(gatewayBeanMap == null){
					loadAll();
					gwBean = gatewayBeanMap.get(new Integer(primaryKey));
				}
				if(gwBean == null){
					gwBean = super.getRecordByPrimaryKey(primaryKey);
					if(gwBean != null){
						gatewayBeanMap.put(new Integer(gwBean.getGatewayid()),gwBean);
					}
				}
			}
		}catch(Exception e){
			E24onlineLogger.sysLog.error("Got Exception while getting record by primary key: " + e,e);
		}
		return gwBean;
	}
	
	
	
	public Integer insertRecord(Tblgateway gatewayBean){
		
		
		// added for preventing invalid interface entry in database....by Pankaj on 10th May, 2005
		if (gatewayBean.getInterface_()==null || gatewayBean.getInterface_().trim().length()==0){
			return INTERFACEISNULL;
		}
		
		
		int insertValue= 0;
		
		try{
		
			/*
			 * Added by biren for not allowing same gatewayname or ipaddress to be added again.
			 */
			String query = " where gatewayname="+SqlMaker.makeString(gatewayBean.getGatewayname());			
			int count = count(query);
			
			if (count>0){ 
				E24onlineLogger.sysLog.info("Gateway Name ALREADY EXISTS");
				return MessageConstants.NAMEALREADYEXISTS;
			}
			
			query = " where  ipaddress = " + SqlMaker.makeString(gatewayBean.getIpaddress());			
			count = count(query);			
			if (count >0){ 
				E24onlineLogger.sysLog.info("IpAddress ALREADY EXISTS");
				return MessageConstants.IPALREADYEXISTS;
			}
			
/*
			insert ="insert into tblgateway "+
					"(gatewayid,gatewayname,interface,ipaddress,gwtableid,isdefault) "+
					" values " +
					"(NULL,"+ SqlMaker.makeString(gatewayName) + "," + SqlMaker.makeString(gwInterface) + "," +
					SqlMaker.makeString(ipAddress) + "," +
					gwTableId + "," + SqlMaker.makeString(isDefault) + ")";
*/			
			/* Purav Gandhi on 26-05-04
			 * added the field weight for insertion */
			insertValue=super.insert(gatewayBean);
			
			E24onlineLogger.sysLog.info("Insert value : "+insertValue);
			
			 if(insertValue > 0){
				if (gatewayBeanMap != null ){
					gatewayBeanMap.put(new Integer(gatewayBean.getGatewayid()),gatewayBean);
				}else{
					loadAll();
					gatewayBeanMap.put(new Integer(gatewayBean.getGatewayid()),gatewayBean);
				}
			 }

		}catch(Exception e){
			E24onlineLogger.sysLog.error("Got an exception while inserting record " + this + e,e);
			insertValue = -1;
		}
		return insertValue;
	}
	
	
	public int update(Tblgateway gatewayBean){
		int INTERFACEISNULL = -10;
		if (gatewayBean.getInterface_()==null || gatewayBean.getInterface_().trim().length()==0){
			return INTERFACEISNULL;
		}
		int count=0;
		int updateStatus=-1;
		try{
			
			updateStatus=super.update(gatewayBean);
			if(updateStatus > 0){
				if(gatewayBeanMap==null){
					loadAll();		
				}
				gatewayBeanMap.put(new Integer(gatewayBean.getGatewayid()),gatewayBean);
				updateStatus = MessageConstants.SUCCESSFUL;
			}else{
				updateStatus=MessageConstants.UNSUCCESSFUL;
			}
		}catch (Exception e) {
			E24onlineLogger.sysLog.error("Exception in gatewayDao, in updateGatewayRecord() "+e,e);
			updateStatus=MessageConstants.UNSUCCESSFUL;
		}
		return updateStatus;
	}
	
	
	
	public int delete(Tblgateway gatewayBean){
				
		int deleteValue = -1;
		try{

			
			if(gatewayBean!=null && gatewayBean.getIsdefault()!=null && !gatewayBean.getIsdefault().equals("")&&  'Y' == Character.toUpperCase(gatewayBean.getIsdefault())){
				return DEFAULTGATEWAY;
			}
			
			//ankita start Ticket1104551 atmosphere
			IGroupDAO groupBean = factory.getGroupDAO();
			int iCount=groupBean.count(" where gatewayname = '"+gatewayBean.getGatewayname()+"'");
			E24onlineLogger.appLog.info(MODULE + "count value before delete:" + iCount);
			if(iCount>0){
				E24onlineLogger.appLog.info("Gateway has Foreign key");
				return E24onlineUtilities.FOREIGNKEYPRESENT ;
			}
			//end
			int count=count("where effectivegatewayid="+gatewayBean.getGatewayid()+ " and gatewayid != "+gatewayBean.getGatewayid());
			
			
			if (count>0){ 
				E24onlineLogger.sysLog.info("ITS EFFECTIVE GATWAY");
				return E24onlineUtilities.FOREIGNKEYPRESENT ;
			}
			
			IGatewayNetworkRelDAO gatewayNetworkRelDAO=factory.getGatewayNetworkRelDao();
			deleteValue = gatewayNetworkRelDAO.getExecuteUpdate("delete from Tblgatewaynetworkrel where id.gatewayid="+gatewayBean.getGatewayid());;
			if(deleteValue < 0){
				return deleteValue ;
			}
			
			deleteValue=super.delete(gatewayBean);
		
			if ( deleteValue >=0 && gatewayBeanMap != null ){
				gatewayBeanMap.remove(new Integer(gatewayBean.getGatewayid()));
			}
			if ( deleteValue >=0 && gatewayTableIdList != null){
				gatewayTableIdList.add(new Integer(gatewayBean.getGwtableid()));
			}	
				
			/* Purav Gandhi 28-05-04
			* Now as the weight is taken from the user we need not have to update the
			* weight by script.
			*/
			/*
			buf = new StringBuffer("/usr/local/scripts/updateweight.sh ");			
//			buf = new StringBuffer("/usr/local/scripts/editquery.sh ");			
			Process process = Runtime.getRuntime().exec(buf.toString());
			retStatus = process.waitFor();
			*/
		}catch(Exception e){
			E24onlineLogger.sysLog.error("Exception in deleting record: " + this + e,e);
			deleteValue = -1;			
		}
		E24onlineLogger.sysLog.info("Returning status of delete from GatewayBean : "+deleteValue);
		return deleteValue;
	}
	
	
	
	
	
	public String getDisplayGatewayName(Tblgateway gatewayBean) {
		String displayName =gatewayBean.getGatewayname() ;
		if(gatewayBean.getIsdefault()!=null){
			if('Y'==(Character.toUpperCase(gatewayBean.getIsdefault()))){
				displayName = gatewayBean.getGatewayname() + " (Default)";
				
			}
		}
		return  displayName;
	}
	public boolean getIsDefaultBool(Tblgateway gatewayBean) {
		boolean isDefault=false;
		if(gatewayBean.getIsdefault() != null){
			if(gatewayBean.getIsdefault() == 'Y' ||gatewayBean.getIsdefault()=='y' ) {
				isDefault=true;
			}
		}
		return isDefault;
	}
	
	public int updateGatewayRecord(Tblgateway gatewayBean) {
		// TODO Auto-generated method stub
		int INTERFACEISNULL = -10;
		if (gatewayBean.getInterface_()==null || gatewayBean.getInterface_().trim().length()==0){
			return INTERFACEISNULL;
		}
		int count=0;
		int updateStatus=-1;
		try{
			String condition="where (gatewayname = "+SqlMaker.makeString(gatewayBean.getGatewayname()) +
				" and gatewayid != " + gatewayBean.getGatewayid() + " ) ";
			count=count(condition);
			if(count > 0){
				updateStatus=MessageConstants.NAMEALREADYEXISTS;
			}else{
				condition="where (ipaddress = "+SqlMaker.makeString(gatewayBean.getIpaddress()) +
				" and gatewayid != " + gatewayBean.getGatewayid() + ")";
				count=count(condition);
				if(count > 0){
					updateStatus=MessageConstants.IPALREADYEXISTS;
				}else{
					updateStatus=update(gatewayBean);
					if(gatewayBeanMap==null){
						loadAll();
						
					}
					gatewayBeanMap.put(new Integer(gatewayBean.getGatewayid()),gatewayBean);
				}
			}
			StringBuffer buf = null ;
			int retStatus = -1;

			buf = new StringBuffer("/bin/sh /usr/local/scripts/updatescript.sh ");
			Process process = Runtime.getRuntime().exec(buf.toString());
			retStatus = process.waitFor();
			E24onlineLogger.sysLog.error("update script :"+retStatus);
		}catch (Exception e) {
			E24onlineLogger.sysLog.error("Exception in gatewayDao, in updateGatewayRecord() "+e,e);
			updateStatus=-1;
		}
		return updateStatus;
	}
	
	public int getNextTableId() {
		/*List<Tblgateway> gatewayList= getList();
		ArrayList<Integer> gatewayTableIdList=new ArrayList();
		ArrayList<Integer> gwTableList=new ArrayList();
		//put Null check and try catch 
		//Use for each Loop
		for(Tblgateway gatewayBean:gatewayList){					
			gwTableList.add(gatewayBean.getGwtableid());			
		}
		for(int i=2;i<=250; i++){ 
			gatewayTableIdList.add(i);
		}
		gatewayTableIdList.removeAll(gwTableList);		
		E24onlineLogger.appLog.debug("GenericDao, getNextTableId :  "+gatewayTableIdList);
		return Integer.parseInt(gatewayTableIdList.get(0).toString());*/
		
		
		if (gatewayTableIdList == null){ 
			loadGatewayTableIdList();
		}
		Integer retValue = (Integer)gatewayTableIdList.get(0);
		gatewayTableIdList.remove(0);
		
		return (retValue.intValue());
	}
	
	public void loadGatewayTableIdList(){ 
		gatewayTableIdList = new ArrayList<Integer>();
		ArrayList<Integer> gwTableList = new ArrayList<Integer>();
			
		TreeMap<Integer,Tblgateway> map = getGatewayBeanMap();
		if(map!=null && !map.isEmpty()){
			Iterator<Tblgateway> iterator = map.values().iterator();
			Tblgateway gwBean = null ;
			while(iterator.hasNext()){ 
				gwBean = iterator.next();
				gwTableList.add(new Integer(gwBean.getGwtableid()));
			}
		}
		
		for(int i=2;i<=250; i++){ 
			gatewayTableIdList.add(new Integer(i));
		}
		gatewayTableIdList.removeAll(gwTableList);
	}
	
}
