package e24online.corporate.servlets ;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.StringTokenizer;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.elitecore.hibernate.base.DAOFactory;
import com.elitecore.jdbchelper.SqlMaker;

import cyberoam.nas.common.ReleaseProcessResourceUtilities;

import e24online.corporate.modes.Modes;
import e24online.corporate.policy.dao.base.IGroupDAO;
import e24online.corporate.systemmgt.DGDConfigurationManager;
import e24online.corporate.systemmgt.GatewayUtilities;
import e24online.corporate.systemmgt.dao.ibase.IDGDGatewayRuleDAO;
import e24online.corporate.systemmgt.dao.ibase.IGatewayDAO;
import e24online.corporate.systemmgt.dao.ibase.IGatewayNetworkRelDAO;
import e24online.corporate.systemmgt.dao.ibase.IGatewayPriorityRelDAO;
import e24online.corporate.systemmgt.dao.ibase.IIpv6GatewayDAO;
import e24online.corporate.systemmgt.dao.ibase.IPrioritiesDAO;
import e24online.corporate.systemmgt.entity.Tbldgdgatewayrule;
import e24online.corporate.systemmgt.entity.Tblgateway;
import e24online.corporate.systemmgt.entity.Tblgatewaynetworkrel;
import e24online.corporate.systemmgt.entity.TblgatewaynetworkrelId;
import e24online.corporate.systemmgt.entity.Tblgatewaypriorityrel;
import e24online.corporate.systemmgt.entity.Tblipv6gateway;
import e24online.corporate.systemmgt.entity.Tblpriorities;
import e24online.corporate.user.dao.ibase.IUserDAO;
import e24online.corporate.utilities.E24onlineConstants;
import e24online.corporate.utilities.MessageConstants;
import e24online.corporate.utilities.PropertyReader;
import e24online.general.IPCalculator;
import e24online.general.ModuleController;
import e24online.log.E24onlineLogger;
import e24online.utilities.AuditObject;
import e24online.utilities.E24onlineUtilities;
import e24online.utilities.InterfaceObject;
import e24online.utilities.StringUtilities;

public class NetworkConfigurationServlet extends HttpServlet { 
	String dnsFile = PropertyReader.DNSFILE ;
	
	public void init (ServletConfig config) throws ServletException {
		super.init(config);
	}

	private static final String MODULENAME = "NetworkConfigurationServlet : ";
	private static DAOFactory factory;
	private static IDGDGatewayRuleDAO dgdGatewayRuleDAO;
	
	static{
		factory = DAOFactory.instance(DAOFactory.HIBERNATE);
		dgdGatewayRuleDAO = factory.getDGDGatewayRuleDAO();
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) {
		try {
			HttpSession session = null ;
			
			int sessionstatus = E24onlineUtilities.checkSession(req);
			if (sessionstatus == E24onlineUtilities.NOTAUTHENTICATED){ 
				res.sendRedirect(req.getContextPath()+"/webpages/sessionexpired.jsp");
				return ;
			}
			int mode = Integer.parseInt(req.getParameter("mode"));

		}catch(Exception e) {
			E24onlineLogger.sysLog.error(MODULENAME + "Exception in doGet() : "+e,e);
		}
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) { 
		try {
			HttpSession session = req.getSession(false);
			int securityLevel= ((Integer)session.getAttribute("securitylevel")).intValue();
			int sessionstatus=-1;
			String loggedInUserName=(String)session.getAttribute("user");
			int mode = Integer.parseInt(req.getParameter("mode"));
			
			if(Modes.ADDGWNWREL == mode || Modes.REMOVEGWNWREL == mode){
				if(securityLevel != E24onlineConstants.CYBEROAMOPERATOR){
					 sessionstatus = E24onlineUtilities.checkSession(req);
					if (sessionstatus == E24onlineUtilities.NOTAUTHENTICATED){ 
						res.sendRedirect(req.getContextPath()+"/webpages/sessionexpired.jsp");
						return ;
					}
				}					
			}else{
				sessionstatus = E24onlineUtilities.checkSession(req);
				if (sessionstatus == E24onlineUtilities.NOTAUTHENTICATED){ 
					res.sendRedirect(req.getContextPath()+"/webpages/sessionexpired.jsp");
					return ;
				}
			}
			
			String hostIp = (String)session.getAttribute("ipaddress");
			if (Modes.NETWORKCONFIGURATION == mode){ 
				String interfaces = req.getParameter("interface");
				String retStatus = updateNetwork(req);
				req.setAttribute("status",retStatus);
				req.getRequestDispatcher("/system/interfaceconfiguration.do").forward(req,res);
				//res.sendRedirect(req.getContextPath()+"/system/interfaceconfiguration.do?status="+retStatus);
				return ;
			}else if(Modes.CREATEGATEWAY == mode){
				int gatewayId = 0;
				int insertStatus=0, success=0, errors=0, listCount=0;
				boolean isCacheEntry = false;
				String gatewayName = req.getParameter("gatewayname");
				String ipAddress = req.getParameter("ipaddress");
				String gwInterface = getInterfaceByGatewayAddress(ipAddress);
				String networkId = req.getParameter("networkid");
				String netmask = req.getParameter("netmask");
				String cacheEntry = req.getParameter("cacheentry");
				String strFwMark = req.getParameter("fwmarkid");
				int iFwMark = E24onlineConstants.NO_VALUE_PROVIDED;
				String ipversion = null;
				try{
					ipversion = req.getParameter("ipversion");
				}catch(Exception e){
					E24onlineLogger.errorLog.error(MODULENAME + "ERROR IN UPDATING Gateway while fetching ipversion request parameter"+e,e);
					ipversion = E24onlineConstants.IPV4;
				}
				E24onlineLogger.sysLog.debug(MODULENAME + "ipversion ::::::::: " + ipversion  );
				try {
					if(StringUtilities.isValidStringWithNull(strFwMark)){
						iFwMark = Integer.parseInt(strFwMark);
					}
				}catch(Exception e) {
					iFwMark = E24onlineConstants.NO_VALUE_PROVIDED;
				}
				String prioritylist[]=null;
				prioritylist =req.getParameterValues("priorityid");
				int weight = 1;
				try {
					weight = Integer.parseInt(req.getParameter("weight"));
				}catch(Exception e) {
					weight = 1;
				}
				E24onlineLogger.sysLog.debug(MODULENAME + "CACHEENTRY: "+ cacheEntry); 
				if("y".equalsIgnoreCase(cacheEntry)){
					isCacheEntry = true;
				}
				String strIsBackup = req.getParameter("isbackup");
				String strBackupgatewayid = req.getParameter("backupgatewayid");
				int iBackupgatewayid=-1;
				try{
					if(StringUtilities.isValidString(strBackupgatewayid)){
						iBackupgatewayid = Integer.parseInt(strBackupgatewayid);
					}
				}catch(Exception e){
					iBackupgatewayid=-1;
				}
				if(StringUtilities.isValidStringWithNull(strIsBackup)) {
					if(strIsBackup.equalsIgnoreCase("Y")){
						iBackupgatewayid = E24onlineConstants.NO_VALUE_PROVIDED;
						iFwMark = E24onlineConstants.NO_VALUE_PROVIDED;
					}
				}else{
					strIsBackup="N";
				}
				
				String oldGWBeanStr = null;
				Tblgateway gwBean = null;
				int retStatus = 0;
				int retUpdate = 0;
				gwBean = new Tblgateway();
				IGatewayDAO gatewayDao=null;
				try{
					gatewayDao=DAOFactory.instance(DAOFactory.HIBERNATE).getGatewayDao();
				}catch(Exception e){
					E24onlineLogger.sysLog.error(MODULENAME + "Exception : "+e,e);
				}
				gwBean.setGatewayname(gatewayName);
				gwBean.setIpaddress(ipAddress);

				gwBean.setInterface_(gwInterface);
				gwBean.setWeight(weight);
				gwBean.setIsbackup(strIsBackup);
				gwBean.setBackupgatewayid(iBackupgatewayid);
				gwBean.setFwmarkid(iFwMark);

				int INTERFACEISNULL = -10;
				
				//logic change by mohit for inserting record in tblgateway
				int countGwName=gatewayDao.count("where gatewayname="+SqlMaker.makeString(gatewayName));
				int countIpAdd=gatewayDao.count("where ipaddress = " + SqlMaker.makeString(ipAddress));
				gwBean.setGwtableid(gatewayDao.getNextTableId());
				if(gwBean.getInterface_()==null || gwBean.getInterface_().trim().length()==0){
					retStatus=INTERFACEISNULL;
				}else if(countGwName > 0){
					retStatus=MessageConstants.NAMEALREADYEXISTS;
				}else if(countIpAdd >0){
					retStatus=MessageConstants.IPALREADYEXISTS;
				}else{
					retStatus = gatewayDao.insert(gwBean);
				}
				
				E24onlineLogger.sysLog.error(MODULENAME + "Return status from Insert Gateway :"+retStatus);
				if(retStatus <= 0){
					if (retStatus == MessageConstants.IPALREADYEXISTS || retStatus == MessageConstants.NAMEALREADYEXISTS){ 
						req.getSession(false).setAttribute("gatewaybean",gwBean);			
					}
					res.sendRedirect(req.getContextPath()+"/webpages/sysmgt/creategateway.jsp?instatus="+retStatus+"&ipversion="+ipversion);
					return ;
				}

				E24onlineLogger.audit.info(new AuditObject(AuditObject.GATEWAY,gatewayName,AuditObject.INSERT,null,gwBean.toString(),loggedInUserName,hostIp));
				if (prioritylist != null){
					listCount = prioritylist.length;
					gwBean = gatewayDao.getRecordByKeyandValue("gatewayname", gatewayName);
					int igatewayId = gwBean.getGatewayid();
					IGatewayPriorityRelDAO gatewayPriorityRelDAO = factory.getGatewayPriorityRelDAO();
					Tblgatewaypriorityrel tblgatewaypriorityrel = new Tblgatewaypriorityrel();
					E24onlineLogger.sysLog.debug(MODULENAME + " Inserting priorities for gateway:: "+ gatewayName);
					for(int i=0; i < listCount; i++){
						int i_priorityid  =Integer.parseInt(prioritylist [i]);
						tblgatewaypriorityrel.setGatewayid(igatewayId);
						tblgatewaypriorityrel.setPriorityid(i_priorityid);
						if(tblgatewaypriorityrel != null){
							insertStatus = gatewayPriorityRelDAO.insert(tblgatewaypriorityrel);
							if (insertStatus < 0 )
								errors+= 1;
							else{
								success+=1;
								E24onlineLogger.audit.info(new AuditObject(AuditObject.GATEWAY_PRIORITY,gatewayName,AuditObject.INSERT,null,tblgatewaypriorityrel.toString(),loggedInUserName,hostIp));
							}				
							
						// if any of record inserted successfully than true
							if(success > 0){
								insertStatus = 1;
							}else{
								insertStatus = E24onlineUtilities.ERROR;
							}
						
							if (errors > 0){
								E24onlineLogger.appLog.debug("Few Errors while inserting gateway priorities");
							}
						}
					}
				
				}
				oldGWBeanStr = gwBean.toString();
					
				gwBean.setEffectivegatewayid(retStatus);
				retUpdate = gatewayDao.updateGatewayRecord(gwBean);
				int gwstatus = 0;
				if(iFwMark != E24onlineConstants.NO_VALUE_PROVIDED){
					gwstatus = 1;
				}
				if(retUpdate >=0){
					E24onlineLogger.audit.info(new AuditObject(AuditObject.GATEWAY,gatewayName,AuditObject.UPDATE,null,"Effective Gatewayid:"+gwBean.getEffectivegatewayid(),loggedInUserName,hostIp));
				}
				GatewayUtilities.addGateway(gwBean.getGatewayid());

				E24onlineLogger.sysLog.debug(MODULENAME + "retStatus :: " + retStatus);
//				retStatus = -1;

				/*
				 * Change made on 7-01-2005 by Biren Shah for updating 
				 * tbldgdgateway and action in tblgateway
				 * 
				 */
				E24onlineLogger.sysLog.debug(MODULENAME + "Inserting the default rule");
				int gatewayID = gwBean.getGatewayid();
				int status = MessageConstants.UNSUCCESSFUL;
					Tbldgdgatewayrule dgdGatewayRuleBean = new Tbldgdgatewayrule();				
					dgdGatewayRuleBean.setGatewayid(gatewayID);
					dgdGatewayRuleBean.setProtocol("PING");
					dgdGatewayRuleBean.setHost(gwBean.getIpaddress());
					dgdGatewayRuleBean.setPort(0);
					status = dgdGatewayRuleDAO.insert(dgdGatewayRuleBean);
					
					E24onlineLogger.sysLog.debug(MODULENAME + "status of rule insert is " + status);
					E24onlineLogger.sysLog.debug(MODULENAME + "Inserted the default rule");	
					if(status > 0){
						E24onlineLogger.sysLog.debug(MODULENAME + "Inserting the Action");
						gwBean.setAction(dgdGatewayRuleDAO.getActionStringByGatewayID(gatewayID));
						gatewayDao.update(gwBean);
						
						E24onlineLogger.sysLog.debug(MODULENAME + "Updating action in networkConfiguration servlet");
						
						ArrayList gwList = (ArrayList) gatewayDao.getList();
						int size = gwList.size();
						E24onlineLogger.sysLog.debug(MODULENAME + "the gatewaylist size is " + size);
						DGDConfigurationManager confManager = DGDConfigurationManager.getInstance();
						if (ModuleController.isModuleVisible(E24onlineConstants.MULTIPLEGATEWAYS) && size >1){
							E24onlineLogger.sysLog.debug(MODULENAME + "configuring the dgd.conf");
							confManager.configure();
							confManager.restartDGDDaemon();
							
						}
					}
				res.sendRedirect(req.getContextPath()+"/system/managegateway.do?instatus="+retStatus+"&gwstatus="+gwstatus+"&ipversion="+ipversion);
				return ;
				
			}else if(Modes.UPDATEGATEWAY == mode){
				int gatewayId = 0;
				String gwInterface = null;
				int insertStatus=0, success=0, errors=0, listCount=0;
				String prioritylist[]=null;
				String ipversion = null;
				try{
					gatewayId = Integer.parseInt(req.getParameter("gatewayid"));
						
				}catch(Exception e){
					E24onlineLogger.errorLog.error(MODULENAME + "ERROR IN UPDATING Gateway "+e,e);
				}
				try{
					ipversion = req.getParameter("ipversion");
				}catch(Exception e){
					E24onlineLogger.errorLog.error(MODULENAME + "ERROR IN UPDATING Gateway while fetching ipversion request parameter"+e,e);
					ipversion = E24onlineConstants.IPV4;
				}
				
				int retStatus = 0;
				String gatewayName = req.getParameter("gatewayname");			
				String ipAddress = req.getParameter("ipaddress");
				
				try{
					boolean validIpAddress = IPCalculator.isIpAddressValid(ipAddress);
					if (!validIpAddress){
						retStatus = E24onlineConstants.INVALID_IP_ADDRESS;
						res.sendRedirect(req.getContextPath()+"/system/managegateway.do?updstatus="+retStatus+"&ipversion="+ipversion);
						return;
					}
				}catch(Exception e){
					E24onlineLogger.errorLog.error(MODULENAME + "Exception while validating Ip Address "+e);
				}
				E24onlineLogger.sysLog.debug(MODULENAME + "Ip Address is valid : " + ipAddress );
				E24onlineLogger.sysLog.debug(MODULENAME + "while updating gateway ipversion is "+ ipversion);
				if(ipversion.equalsIgnoreCase(E24onlineConstants.IPV6)){
					
					ipAddress = getOperationOnIpAddress(ipAddress,E24onlineConstants.EXPAND_IP_ADDRESS);
					gwInterface = getInterfaceByIpv6GatewayAddress(ipAddress);
					E24onlineLogger.sysLog.debug(MODULENAME + "Expanded ip Address : " + ipAddress );
					
					IIpv6GatewayDAO ipv6GatewayDAO = null;
					Tblipv6gateway ipv6GatewayBean = null;
					try{
						ipv6GatewayDAO = DAOFactory.instance(DAOFactory.HIBERNATE).getIpv6GatewayDao();
						ipv6GatewayBean = (Tblipv6gateway)ipv6GatewayDAO.getRecordByPrimaryKey(gatewayId);
					}catch(Exception ex){
						E24onlineLogger.errorLog.error(MODULENAME + "ERROR IN UPDATING Ipv6 Gateway"+ex,ex);
					}
					
					E24onlineLogger.sysLog.debug(MODULENAME + "ipv6GatewayBean : " + ipv6GatewayBean);
					Tblipv6gateway cloneIpv6GatewayBean = (Tblipv6gateway)ipv6GatewayBean.clone(); 
					
					String oldGatewayStr = ipv6GatewayBean.toString();
					String oldGatewayName = ipv6GatewayBean.getGatewayname();
					String oldIPAddress = ipv6GatewayBean.getIpv6address();
					
					cloneIpv6GatewayBean.setGatewayname(gatewayName);
					cloneIpv6GatewayBean.setInterface_(gwInterface);
					cloneIpv6GatewayBean.setIpv6address(ipAddress);
					
					retStatus = ipv6GatewayDAO.updateIpv6GatewayRecord(cloneIpv6GatewayBean); 
					
					if (retStatus == E24onlineUtilities.ALREADYEXISTS || retStatus <0){ 
						ipv6GatewayBean.setGatewayname(oldGatewayName);
						req.getSession(false).setAttribute("ipv6gatewaybean",ipv6GatewayBean);
						res.sendRedirect(req.getContextPath()+"/webpages/sysmgt/creategateway.jsp?gatewayid="+gatewayId+"&updstatus="+retStatus+"&ipversion="+ipversion);
						return ;
					}
					E24onlineLogger.audit.info(new AuditObject(AuditObject.GATEWAY_IPV6,gatewayName,AuditObject.UPDATE,oldGatewayStr,cloneIpv6GatewayBean.toString(),loggedInUserName,hostIp));
					
				} else {

				String network = req.getParameter("network");
				String weight = req.getParameter("weight");
				String strIsBackup = req.getParameter("isbackup");
				prioritylist =req.getParameterValues("priorityid");
				String strBackupgatewayid = req.getParameter("backupgatewayid");
				String strFwMark = req.getParameter("fwmarkid");
				gwInterface = getInterfaceByGatewayAddress(ipAddress);
				
				int iFwMark = E24onlineConstants.NO_VALUE_PROVIDED;
				try {
					if(StringUtilities.isValidStringWithNull(strFwMark)){
						iFwMark = Integer.parseInt(strFwMark);
					}
				}catch(Exception e) {
					iFwMark = E24onlineConstants.NO_VALUE_PROVIDED;
				}
				int iBackupgatewayid=-1;
				
				try{
					if(StringUtilities.isValidString(strBackupgatewayid)){
						iBackupgatewayid = Integer.parseInt(strBackupgatewayid);
					}
				}catch(Exception e){
					iBackupgatewayid=-1;
				}
				if(StringUtilities.isValidStringWithNull(strIsBackup)) {
					if(strIsBackup.equalsIgnoreCase("Y")){
						iBackupgatewayid = E24onlineConstants.NO_VALUE_PROVIDED;
						iFwMark = E24onlineConstants.NO_VALUE_PROVIDED;
					}
				}else{
					strIsBackup="N";
				}
				IGatewayDAO gatewayDao=null;
				try{
					gatewayDao=DAOFactory.instance(DAOFactory.HIBERNATE).getGatewayDao();
				}catch(Exception e){
					E24onlineLogger.sysLog.error(MODULENAME + "Exception : "+e,e);
				}
				Tblgateway tblgateway = gatewayDao.getRecordByKeyandValue("backupgatewayid", gatewayId);
				if(tblgateway != null && strIsBackup.equalsIgnoreCase("N")){
					E24onlineLogger.appLog.debug(MODULENAME + " Gateway to be updated is backup Gateway of one of the primary gateway So Cannot Update ");
					retStatus = E24onlineConstants.DEFAULT;
				}else{
					Tblgateway gwBean = (Tblgateway)gatewayDao.getRecordByPrimaryKey(gatewayId);
					Tblgateway cloneGWBean = (Tblgateway)gwBean.clone();
//					Tblipv6gateway ipv6GWBean = (Tblipv6gateway) 
					String oldGatewayStr = gwBean.toString();
					String oldGatewayName = gwBean.getGatewayname();
					String oldIPAddress = gwBean.getIpaddress();
	
					cloneGWBean.setGatewayname(gatewayName);
				
					cloneGWBean.setInterface_(gwInterface);
					cloneGWBean.setIpaddress(ipAddress);
					cloneGWBean.setWeight(Integer.parseInt(weight));
					cloneGWBean.setIsbackup(strIsBackup);
					cloneGWBean.setBackupgatewayid(iBackupgatewayid);
					cloneGWBean.setFwmarkid(iFwMark);
							
					retStatus = gatewayDao.updateGatewayRecord(cloneGWBean);
			
					if (retStatus == E24onlineUtilities.ALREADYEXISTS || retStatus <0){ 
						gwBean.setGatewayname(oldGatewayName);
						req.getSession(false).setAttribute("gatewaybean",gwBean);
						res.sendRedirect(req.getContextPath()+"/webpages/sysmgt/creategateway.jsp?gatewayid="+gatewayId+"&updstatus="+retStatus+"&ipversion="+ipversion);
						return ;
					}else if(retStatus >=0){
						if(iFwMark != gwBean.getFwmarkid())
							retStatus = 2; 
						E24onlineLogger.sysLog.debug(MODULENAME + "mark value from jsp "+iFwMark+" from database"+gwBean.getFwmarkid());
						IGatewayPriorityRelDAO gatewayPriorityRelDAO = factory.getGatewayPriorityRelDAO();
												
						if(strIsBackup.equalsIgnoreCase("Y") || iFwMark == E24onlineConstants.NO_VALUE_PROVIDED){
							int count = gatewayPriorityRelDAO.count( " where gatewayid = "+gatewayId);
							if(count > 0){
								E24onlineLogger.sysLog.debug(MODULENAME + " Updating gateway to backup/ selecting identifier as no mark so deleting existing gateway-priorities relations ");
								String query = " delete from Tblgatewaypriorityrel where gatewayid = "+gatewayId;
								gatewayPriorityRelDAO.getRecordBySQLQuery(query);
							}
						}else{
							boolean insertreq = true;
							if (prioritylist != null){
								listCount = prioritylist.length;
								Tblgatewaypriorityrel tblgatewaypriorityrel = new Tblgatewaypriorityrel();
								List<Tblgatewaypriorityrel> gatewayprioritylist = gatewayPriorityRelDAO.getListByCondition( " where gatewayid = "+gatewayId);
								if(gatewayprioritylist != null && !gatewayprioritylist.isEmpty()){
									String oldprioritylist[] = new String[gatewayprioritylist.size()];
									Tblgatewaypriorityrel tblgatewaypriorityrel2 = null;
									for(int j=0; j < gatewayprioritylist.size() ; j++){
										tblgatewaypriorityrel2 = gatewayprioritylist.get(j);
										oldprioritylist[j] = String.valueOf(tblgatewaypriorityrel2.getPriorityid());
									}
									if(oldprioritylist != null && oldprioritylist.length > 0 && !Arrays.equals(oldprioritylist, prioritylist)){
										int count1 = gatewayPriorityRelDAO.count( " where gatewayid = "+gatewayId);
										if(count1 > 0){
											String query = " delete from Tblgatewaypriorityrel where gatewayid = "+gatewayId;
											gatewayPriorityRelDAO.getRecordBySQLQuery(query);
											retStatus = 2;
										}
									}else{
										insertreq = false;
									}
								}
								E24onlineLogger.sysLog.debug(MODULENAME + " Updating priorities for gateway:: "+ gatewayName);
								for(int i=0; i < listCount; i++){
									int i_priorityid  =Integer.parseInt(prioritylist [i]);
									tblgatewaypriorityrel.setGatewayid(gatewayId);
									tblgatewaypriorityrel.setPriorityid(i_priorityid);
									if(tblgatewaypriorityrel != null && insertreq){
										insertStatus = gatewayPriorityRelDAO.insert(tblgatewaypriorityrel);
										if (insertStatus < 0 )
											errors+= 1;
										else{
											success+=1;
											E24onlineLogger.audit.info(new AuditObject(AuditObject.GATEWAY_PRIORITY,gatewayName,AuditObject.INSERT,null,tblgatewaypriorityrel.toString(),loggedInUserName,hostIp));
										}				
										
									// if any of record inserted successfully than true
										if(success > 0){
											insertStatus = 1;
										}else{
											insertStatus = E24onlineUtilities.ERROR;
										}
									
										if (errors > 0){
											E24onlineLogger.appLog.debug("Few Errors while inserting gateway priorities");
										}
									}
								}
													
							}
						}
						IGatewayNetworkRelDAO gatewayNetworkRelDao=DAOFactory.instance(DAOFactory.HIBERNATE).getGatewayNetworkRelDao();
						ArrayList gwNetworkList = (ArrayList) gatewayNetworkRelDao.getListByKeyandValue("id.gatewayid",gatewayId);
						if(gwNetworkList != null && gwNetworkList.size() > 0 && strIsBackup.equalsIgnoreCase("Y")){
							E24onlineLogger.sysLog.info(MODULENAME+ " Gateway do have networks explicitly routed and is to be made backup Gateway So Deleting networks");
							Tblgatewaynetworkrel gwNetworkBean = null;
							for(int i=0;i<gwNetworkList.size();i++){
								gwNetworkBean = (Tblgatewaynetworkrel)gwNetworkList.get(i);
								gatewayNetworkRelDao.delete(gwNetworkBean);
							}
						}
							if (E24onlineConstants.IS_BRIDGE_ENABLED == 0){
								Process process = Runtime.getRuntime().exec("sh /usr/local/scripts/setgw_in_sysconfignetwork.sh");
							}
							if(!oldIPAddress.equals(ipAddress)){
								
								GatewayUtilities.changeGwRoute(oldIPAddress,ipAddress,"gw"+cloneGWBean.getGatewayid());
								
								ArrayList gwNetList = (ArrayList) gatewayNetworkRelDao.getListByKeyandValue("id.gatewayid",gatewayId);
								int size = gwNetList.size();
								Tblgatewaynetworkrel gwNetworkBean = null;
								String outGoingInterface = null;
								for(int i=0;i<size;i++){
									gwNetworkBean = (Tblgatewaynetworkrel)gwNetList.get(i);
									network = gwNetworkBean.getId().getNetwork();
									outGoingInterface = getInterfaceByGWAddress(ipAddress);
								}
								
							}
							
							E24onlineLogger.audit.info(new AuditObject(AuditObject.GATEWAY,gatewayName,AuditObject.UPDATE,oldGatewayStr,cloneGWBean.toString(),loggedInUserName,hostIp));
							
							ArrayList gwList = (ArrayList) gatewayDao.getList();
							int size = gwList.size();
							DGDConfigurationManager confManager = DGDConfigurationManager.getInstance();
							if (ModuleController.isModuleVisible(E24onlineConstants.MULTIPLEGATEWAYS) && size >1){
								E24onlineLogger.sysLog.debug(MODULENAME + "MULTIPLEGATEWAY MODULE REGISTERED AND GATEWAY SIZE > 1 SO RESTARTING DGD..."); 
								confManager.configure();
								confManager.restartDGDDaemon();
							}
						}
					}
				}
				
					E24onlineLogger.sysLog.debug(MODULENAME + "Update Status for updateing Gateway : " + retStatus );
					res.sendRedirect(req.getContextPath()+"/system/managegateway.do?updstatus="+retStatus+"&ipversion="+ipversion);
					return ;
							
			}else if(Modes.DELETEGATEWAY == mode){
				String ipversion = null;
				try{
					ipversion = req.getParameter("ipversion");
				}catch(Exception e){
					E24onlineLogger.errorLog.error(MODULENAME + "ERROR IN UPDATING Gateway while fetching ipversion request parameter"+e,e);
					ipversion = E24onlineConstants.IPV4;
				}
				String[] strArrGWId = req.getParameterValues("select");
				int length = strArrGWId != null ? strArrGWId.length : 0 ;
				E24onlineLogger.appLog.debug(MODULENAME + "Length of the selected values  are : " + length + " value is + "+ strArrGWId[0]);
				String outgoingInterface = null;
				String network = null;
				boolean isCacheEntry = false;
				String cacheEntry = req.getParameter("isentrycache");
				if(cacheEntry != null && cacheEntry.equalsIgnoreCase("y")){
					isCacheEntry = true;
				}
				int deleteStatus =0;
				int delCacheStatus = 0;
				Tblgateway gwBean = null;
				IGatewayDAO gatewayDao=DAOFactory.instance(DAOFactory.HIBERNATE).getGatewayDao();
				IGatewayPriorityRelDAO gatewayPriorityRelDAO = factory.getGatewayPriorityRelDAO();
				Tblgatewaynetworkrel gNBean = null;
				IGatewayNetworkRelDAO gatewayNetworkRelDao=null;
				int finalstatus = 0;
				ArrayList gwNetworklist = null ;
				for(int i=0;i<length;i++){
					try{
						gatewayNetworkRelDao=DAOFactory.instance(DAOFactory.HIBERNATE).getGatewayNetworkRelDao();
						gwBean = (Tblgateway)gatewayDao.getRecordByPrimaryKey(Integer.parseInt(strArrGWId[i]));
						if(gwBean!=null){
							E24onlineLogger.appLog.debug(MODULENAME + "GWBean is Not null");
							
						}else{
							E24onlineLogger.appLog.debug(MODULENAME + "GWBEAN is null");
						}
						
						Tblgateway tblgateway = gatewayDao.getRecordByKeyandValue("backupgatewayid", Integer.parseInt(strArrGWId[i]));
						if(tblgateway != null){
							E24onlineLogger.appLog.debug(MODULENAME + " Gateway to be deleted is backup Gateway of one of the primary gateway So Cannot Delete ");
							finalstatus = E24onlineConstants.DEFAULT;
							res.sendRedirect(req.getContextPath()+"/webpages/sysmgt/managegateway.jsp?delstatus="+finalstatus+"&ipversion="+ipversion);
							return ;
						}else{
							// added by biren
							/*
							 * delete all gatewayrules by gatewayid from tbldgdgatewayrule
							 */
							int retValue =  dgdGatewayRuleDAO.deleteAllRuleByGatewayID(Integer.parseInt(strArrGWId[i]));
							
							gwNetworklist = (ArrayList) gatewayNetworkRelDao.getListByKeyandValue("id.gatewayid",gwBean.getGatewayid());						
							
							deleteStatus = gatewayDao.delete(gwBean);
							E24onlineLogger.sysLog.debug(MODULENAME + "Deleting gateway : "+ gwBean.getGatewayid());
							E24onlineLogger.sysLog.debug(MODULENAME + "DELETE STATUS:"+deleteStatus);
							//ankita start Ticket1104551 atmosphere
							boolean foreign_key_flag = false;
							if (deleteStatus == E24onlineUtilities.FOREIGNKEYPRESENT  ){
								foreign_key_flag=true;
								finalstatus = E24onlineUtilities.FOREIGNKEYPRESENT;
							}
							//end adding else below previously it was else
							else if (deleteStatus < 0 ){
								finalstatus = deleteStatus ;
							}else{
								if(gwBean.getFwmarkid()!= -1){
									finalstatus = 2;
								}
										
								int count = gatewayPriorityRelDAO.count( " where gatewayid = "+strArrGWId[i]);
								if(count > 0){
									E24onlineLogger.sysLog.debug(MODULENAME + "Deleting gateway priorities for gatewayid :: "+ strArrGWId[i]);
									String query = " delete from Tblgatewaypriorityrel where gatewayid = "+strArrGWId[i];
									gatewayPriorityRelDAO.getRecordBySQLQuery(query);
								}
								E24onlineLogger.sysLog.debug(MODULENAME + "Calling GatewayUtilities.delGateway ");
								GatewayUtilities.delGateway(gwBean,gwNetworklist);
								E24onlineLogger.audit.info(new AuditObject(AuditObject.GATEWAY,gwBean.getGatewayname(),AuditObject.DELETE,gwBean.toString(),null,loggedInUserName,hostIp));
	
								// Delete the network from cache also if cache entry is true.
								if(isCacheEntry){
									int networkSize = gwNetworklist.size();
									for(i=0;i<networkSize;i++){
										gNBean = (Tblgatewaynetworkrel)gwNetworklist.get(i);
										network = gNBean.getId().getNetwork(); 
									}
									E24onlineLogger.sysLog.debug(MODULENAME + "DELETE CACHE:"+delCacheStatus);
								}
								E24onlineLogger.sysLog.debug(MODULENAME + "isCacheEntry:"+isCacheEntry);
							}
						}
					}catch(Exception e){ 
						E24onlineLogger.errorLog.error(MODULENAME + "Got Exception while deleting gateway "+e,e);
						finalstatus = -1 ;
					}	
				}
				ArrayList gwList = (ArrayList) gatewayDao.getList();
				int size = gwList.size();
				E24onlineLogger.sysLog.debug(MODULENAME + "No OF Gateways = "+ size);
				DGDConfigurationManager confManager = DGDConfigurationManager.getInstance();
				if (ModuleController.isModuleVisible(E24onlineConstants.MULTIPLEGATEWAYS) && size >1){
					E24onlineLogger.sysLog.debug(MODULENAME + "Gateway SIZE  > 1 && MULTIPLEGATEWAYS MODULE REGISTERED SO RESTARTING DGD");
					confManager.configure();
					confManager.restartDGDDaemon();
				}else if( ModuleController.isModuleVisible(E24onlineConstants.MULTIPLEGATEWAYS) && size <=1 ){
					E24onlineLogger.sysLog.debug(MODULENAME + "Gateway SIZE  <= 1 && MULTIPLEGATEWAYS MODULE REGISTERED SO STOPING DGD");
					confManager.stopDGDDaemon();
				}
				res.sendRedirect(req.getContextPath()+"/system/managegateway.do?delstatus="+finalstatus+"&ipversion="+ipversion);
				return ;
			}else if(Modes.MAKEDEFAULTGATEWAY == mode){
				String strGWId = (String)req.getParameter("isdefault");
				String network = (String)req.getParameter("network");
				int retStatus =0;
				Tblgatewaynetworkrel gwNetworkBean = null;
				IGatewayNetworkRelDAO gatewayNetworkRelDao=null;
				ArrayList gwNetList = null;
				int gwId = 0;
				IGatewayDAO gatewayDao=null;
				try{
					gwId = Integer.parseInt(strGWId);
					gatewayDao=DAOFactory.instance(DAOFactory.HIBERNATE).getGatewayDao();
					gatewayNetworkRelDao=DAOFactory.instance(DAOFactory.HIBERNATE).getGatewayNetworkRelDao();
				}catch(Exception e){
					E24onlineLogger.sysLog.error(MODULENAME + "Exception in getting getwayid"+e,e);
				}
				
				Tblgateway cloneBean = null ;
				Tblgateway gwDefaultBean = (Tblgateway)gatewayDao.getRecordByPrimaryKey(gwId);
				Tblgateway gwBean = gatewayDao.getRecordByKeyandValue("isdefault" , "y");
								
				if (gwBean != null && gwDefaultBean != null && gwBean.getGatewayid() != gwDefaultBean.getGatewayid() && !(gwBean.getGatewayid()!=gwBean.getEffectivegatewayid())){

					//hibernate chages by mohit
					ArrayList gwNetworklist = (ArrayList) gatewayNetworkRelDao.getListByKeyandValue("id.gatewayid", gwBean.getGatewayid());
					cloneBean = (Tblgateway)gwBean.clone();
					cloneBean.setIsdefault('N');
					retStatus = gatewayDao.updateGatewayRecord(cloneBean);
					if(retStatus >=0){
						E24onlineLogger.sysLog.debug(MODULENAME + "Network is:"+network);
						
						if(network != null && !gatewayNetworkRelDao.isNetworkDefined(cloneBean.getGatewayid())){
							Tblgatewaynetworkrel gwNWRelBean = new Tblgatewaynetworkrel();
							TblgatewaynetworkrelId gwNetRelIdBean=new TblgatewaynetworkrelId();
							
							gwNetRelIdBean.setGatewayid(cloneBean.getGatewayid());
							gwNetRelIdBean.setNetwork(network);
							gwNWRelBean.setId(gwNetRelIdBean);
							E24onlineLogger.appLog.debug(MODULENAME + "Before inserting record in tblgatewaynetworkRel : ");
							int count=gatewayNetworkRelDao.count("where  network="+SqlMaker.makeString(network));
							int insStatus =0;
							if(count==0){
								TblgatewaynetworkrelId gatewayNetworkRelIdBean= gatewayNetworkRelDao.insert(gwNWRelBean);
								if(gatewayNetworkRelIdBean !=null){
									insStatus= 1;
								}
							}else{
								insStatus=-2;
							}
							if(insStatus >0){
								E24onlineLogger.appLog.debug(MODULENAME + "Record inserted successfully in tblgatewaynetworkrel : "); 
								/**
								 * Logic to add cache tcp outgoing relation for alternate gateway
								 */
								String interfaceAddress = getInterfaceByGWAddress(cloneBean.getIpaddress());
								E24onlineLogger.audit.info(new AuditObject(AuditObject.GATEWAYNETWORKREL,gwBean.getGatewayname(),AuditObject.INSERT,null,network,loggedInUserName,(String)session.getAttribute("ipaddress")));
							}else{
								E24onlineLogger.appLog.debug(MODULENAME + "Record is not inserted : ");
							}
						}else{
							/**
							 * This is to change gateway cahce outgoing relationship for already
							 * existing network
							 */
							gwNetList = (ArrayList) gatewayNetworkRelDao.getListByKeyandValue("id.gatewayid",cloneBean.getGatewayid());
							int size = gwNetList.size();
							String outGoingInterface = null;
							for(int i=0;i<size;i++){
								gwNetworkBean = (Tblgatewaynetworkrel)gwNetList.get(i);
								network = gwNetworkBean.getId().getNetwork();
							}
						}
						E24onlineLogger.audit.info(new AuditObject(AuditObject.GATEWAY,gwBean.getGatewayname(),AuditObject.UPDATE,gwBean.toString(),cloneBean.toString(),loggedInUserName,hostIp));
					}	
					
					cloneBean = (Tblgateway)gwDefaultBean.clone();
					cloneBean.setIsdefault('Y');
					retStatus = gatewayDao.updateGatewayRecord(cloneBean);
					if(retStatus >=0){
						/**
						 * This is to change gateway cahce outgoing relationship for already
						 * existing network
						 */
						gwNetList = (ArrayList) gatewayNetworkRelDao.getListByKeyandValue("id.gatewayid",cloneBean.getGatewayid());
						int size = gwNetList.size();
						String outGoingInterface = null;
						for(int i=0;i<size;i++){
							gwNetworkBean = (Tblgatewaynetworkrel)gwNetList.get(i);
							network = gwNetworkBean.getId().getNetwork();
						}
						E24onlineLogger.audit.info(new AuditObject(AuditObject.GATEWAY,gwDefaultBean.getGatewayname(),AuditObject.UPDATE,gwDefaultBean.toString(),cloneBean.toString(),loggedInUserName,hostIp));
					}
					GatewayUtilities.makeDefaultGateway(gwBean.getGatewayid(),gwDefaultBean.getGatewayid());
					E24onlineLogger.appLog.debug(MODULENAME + "Return from makeDefaultGateway ");
				}

				res.sendRedirect(req.getContextPath()+"/webpages/sysmgt/managegateway.jsp?updstatus="+retStatus);
				return ;
			}else if(Modes.CHANGEEFFECTIVEGATEWAY == mode){
				String[] strArrGWId = req.getParameterValues("select");
				String strEffectiveGWId = req.getParameter("effectivegateway");
				int effectiveGWId =0;
				int applEffGWId = 0;
				
				try{
					effectiveGWId = Integer.parseInt(strEffectiveGWId);
					E24onlineLogger.sysLog.debug(MODULENAME + "Effective gw:"+effectiveGWId);
				}catch(Exception e){
					E24onlineLogger.sysLog.error(MODULENAME + "Exception in getting effective gateway id:"+e,e);
				}
				int length = strArrGWId != null ? strArrGWId.length : 0 ;
									
				int retStatus =0;
				Tblgateway gwBean = null;
				int oldEffGWId = 0;
				int tmpStatus =1;
				IGatewayDAO gatewayDao=null;
				try{
					gatewayDao=DAOFactory.instance(DAOFactory.HIBERNATE).getGatewayDao();
				}catch(Exception e){
					E24onlineLogger.sysLog.error(MODULENAME + "Exception : "+e,e);
				}
				for(int i=0;i<length;i++){
					try{
						gwBean = (Tblgateway)gatewayDao.getRecordByPrimaryKey(Integer.parseInt(strArrGWId[i]));
						if(effectiveGWId == E24onlineConstants.NOREDIRECTION){
							applEffGWId = gwBean.getGatewayid();
						}else{
							applEffGWId = effectiveGWId;
						}
						oldEffGWId = gwBean.getEffectivegatewayid();
						if(oldEffGWId != applEffGWId){
							
							String condition=" where effectivegatewayid ="+ gwBean.getGatewayid()+" and gatewayid !=" + gwBean.getGatewayid() ;
							int count=gatewayDao.count(condition);
							boolean canRedirected=true;
							
							if(count>0){
								canRedirected=false;
							}
							boolean isDefaultBool=('y'==Character.toUpperCase(gwBean.getIsdefault()));
							E24onlineLogger.sysLog.debug(MODULENAME + "isDefaultbool + " + isDefaultBool);
							if(canRedirected && !isDefaultBool){
									gwBean.setEffectivegatewayid(applEffGWId);
									retStatus = gatewayDao.updateGatewayRecord(gwBean);
									if (retStatus > 0 ){
										changeCacheInterface(gwBean.getGatewayid(),applEffGWId);
									}
							}else{
								tmpStatus = E24onlineConstants.CANNOTREDIRECT ;
							}
						}
						}catch(Exception e){ 
						E24onlineLogger.errorLog.error(MODULENAME + "Got Exception while deleting gateway ",e);
						retStatus = -1 ;
					}	
					
				} 
				retStatus = tmpStatus ;
				res.sendRedirect(req.getContextPath()+"/webpages/sysmgt/managegateway.jsp?updstatus="+retStatus);
				return ;
			}else if(Modes.ADDGWNWREL == mode){
				
				IGatewayDAO gatewayDao=null;
				int status=0;
				String ipversion = null;
				try{
					ipversion = req.getParameter("ipversion");
				}catch(Exception e){
					E24onlineLogger.errorLog.error(MODULENAME + "ERROR IN fetching ipversion mode REMOVEGWNWREL : "+e,e);
					ipversion = E24onlineConstants.IPV4;
				}
				try{
					gatewayDao=DAOFactory.instance(DAOFactory.HIBERNATE).getGatewayDao();
					int gatewayId = Integer.parseInt(req.getParameter("gatewayid"));
					Tblgateway gwbean = null;
					String gName = null;
					gwbean = (Tblgateway)gatewayDao.getRecordByPrimaryKey(gatewayId);
					if(gwbean != null){
						gName = gwbean.getGatewayname();
						if(gwbean.getIsbackup().equalsIgnoreCase("Y")){
							status=-3;
							res.sendRedirect(req.getContextPath()+"/webpages/sysmgt/creategateway.jsp?gatewayid="+gatewayId+"&status="+status+"&ipversion="+ipversion);
							return;
						}
					}
					
					boolean isCacheEntry = false;
					boolean failover = false;				
					String networkStr = req.getParameter("network");
					int index = networkStr.indexOf ("&");
					String network = networkStr.substring(0,index); 
					E24onlineLogger.sysLog.debug(MODULENAME + "Network:"+network);
					String networktype = networkStr.substring(index+1,networkStr.length()); 
					int networkType = E24onlineConstants.PRIVATENETWORKTYPE;
					try {
						networkType = Integer.parseInt(networktype);
					}catch(Exception e) {
						E24onlineLogger.sysLog.error(MODULENAME + "While parsing networktype: " + networktype + " for network:" + network);
					}
					
					String CacheEntry = "y"; // default yes
					if(CacheEntry.equalsIgnoreCase("y")){
						isCacheEntry = true;
					}
					String failoverval = networkStr.substring(index+1,networkStr.length());
					if(failoverval.equalsIgnoreCase("y")){
						failover = true;
					}
					E24onlineLogger.sysLog.debug(MODULENAME + "ISCACHEENTRY:"+isCacheEntry);
					E24onlineLogger.sysLog.debug(MODULENAME + "FailoverVal:"+failoverval);
					
					Tblgatewaynetworkrel gwNWRelBean = new Tblgatewaynetworkrel();
					TblgatewaynetworkrelId gwNetworkRelIdBean=new TblgatewaynetworkrelId();
 					IGatewayNetworkRelDAO gatewayNetworkRelDao=DAOFactory.instance(DAOFactory.HIBERNATE).getGatewayNetworkRelDao();
 					
					gwNetworkRelIdBean.setGatewayid(gatewayId);
					gwNetworkRelIdBean.setNetwork(network);
					gwNWRelBean.setId(gwNetworkRelIdBean);
					gwNWRelBean.setFailover(failoverval.charAt(0));
					
					int count=gatewayNetworkRelDao.count("where id.network="+SqlMaker.makeString(network));
					if(count==0){
						TblgatewaynetworkrelId gatewayNetworkRelIdBean= gatewayNetworkRelDao.insert(gwNWRelBean);
						if(gatewayNetworkRelIdBean!=null){
							status=1;
						}
					}else{
						status=-2;
					}
									
					
					if(status>0){
						GatewayUtilities.changeGwRule(network,gwbean,true,failover);
						E24onlineLogger.audit.info(new AuditObject(AuditObject.GATEWAYNETWORKREL,gName,AuditObject.INSERT,null,network,loggedInUserName,(String)session.getAttribute("ipaddress")));
						DGDConfigurationManager confManager = DGDConfigurationManager.getInstance();
						if (ModuleController.isModuleVisible(E24onlineConstants.MULTIPLEGATEWAYS)){
							E24onlineLogger.sysLog.debug(MODULENAME + "Configuring the DGD.conf File After Adding Network");
							confManager.configure();
							confManager.restartDGDDaemon();
							
						}
						E24onlineLogger.sysLog.debug(MODULENAME + "AFTER CHANGE RULE:");
						if(isCacheEntry){
							E24onlineLogger.sysLog.debug(MODULENAME + "IN IS CACHE ENTRY:"+isCacheEntry);
							String interfaceAddress = getInterfaceByGWAddress(gwbean.getIpaddress());
						}					
					}
					res.sendRedirect(req.getContextPath()+"/webpages/sysmgt/creategateway.jsp?gatewayid="+gatewayId+"&status="+status+"&ipversion="+ipversion);	
				}catch(Exception e){
					res.sendRedirect(req.getContextPath()+"/webpages/sysmgt/managegateway.jsp?updstatus="+status+"&ipversion="+ipversion);
					return;
				}
			}else if(Modes.REMOVEGWNWREL == mode){
				int status = 0;
				IGatewayNetworkRelDAO gatewayNetworkRelDao=null;
				String ipversion = null;
				try{
					ipversion = req.getParameter("ipversion");
				}catch(Exception e){
					E24onlineLogger.errorLog.error(MODULENAME + "ERROR IN fetching ipversion in mode REMOVEGWNWREL : "+e,e);
					ipversion = E24onlineConstants.IPV4;
				}
				try{
					boolean isEntry = false;
					String cacheEntry = req.getParameter("isentrycache");
					if(cacheEntry.equalsIgnoreCase("y")){
						isEntry = true;
					}
					int gatewayId = Integer.parseInt(req.getParameter("gatewayid"));
					IGatewayDAO gatewayDao=DAOFactory.instance(DAOFactory.HIBERNATE).getGatewayDao();
					Tblgateway gwbean = (Tblgateway)gatewayDao.getRecordByPrimaryKey(gatewayId);
					String gName = null;
					if(gwbean != null){
						gName = gwbean.getGatewayname();
					}
					String[] networks = req.getParameterValues("gwnw");
					int length = networks != null ? networks.length : 0 ;
					E24onlineLogger.sysLog.debug(MODULENAME + "NETWORK LIST:"+length);
					String key = null;
					gatewayNetworkRelDao=DAOFactory.instance(DAOFactory.HIBERNATE).getGatewayNetworkRelDao();
					for(int i=0;i<length;i++){
						key = networks[i];
						Tblgatewaynetworkrel gwNWRelBean = new Tblgatewaynetworkrel();
						TblgatewaynetworkrelId gwNWRelIdBean=new TblgatewaynetworkrelId();
						gwNWRelIdBean.setGatewayid(gatewayId);
						gwNWRelIdBean.setNetwork(key);
						gwNWRelBean.setId(gwNWRelIdBean);
						
						status = gatewayNetworkRelDao.delete(gwNWRelBean);				
							if(status>=0){
								E24onlineLogger.appLog.debug(MODULENAME + "Record deleted successfully  ");
								GatewayUtilities.changeGwRule(key,gwbean,false,false);
								E24onlineLogger.audit.info(new AuditObject(AuditObject.GATEWAYNETWORKREL,gName,AuditObject.DELETE,key,null,loggedInUserName,(String)session.getAttribute("ipaddress")));
								DGDConfigurationManager confManager = DGDConfigurationManager.getInstance();
								if (ModuleController.isModuleVisible(E24onlineConstants.MULTIPLEGATEWAYS)){
									E24onlineLogger.sysLog.debug(MODULENAME + "Configuring the DGD.conf File After Removing Network");
									confManager.configure();
									confManager.restartDGDDaemon();
									
								}
							}
							if(isEntry){
								Hashtable extInterface = E24onlineUtilities.getAllInterfaces();
								E24onlineLogger.sysLog.debug(MODULENAME + "extInterface table:"+extInterface);
								Enumeration extInter = extInterface.keys();
								InterfaceObject iObject = null ;
								int interfaceSize = extInterface.size();
								String interSubStr = null;
								String interfaceStr = null;
								String gwId = gwbean.getIpaddress();
								String gwSubStr = null;
								String interfaceName = null;
								String interfaceDup = null;
								while(extInter.hasMoreElements()){
									interfaceDup = (String)extInter.nextElement();
									if(interfaceDup.indexOf(":") < 0 ){
										interfaceName = interfaceDup;
										iObject = (InterfaceObject)extInterface.get(interfaceName);
										interfaceStr = iObject.getIPAddress();
										interSubStr = interfaceStr.substring(0,interfaceStr.lastIndexOf("."));
										E24onlineLogger.sysLog.debug(MODULENAME + "Interface Name:"+interfaceName+ " ipaddress:"+interfaceStr);
										gwSubStr = gwId.substring(0,gwId.lastIndexOf("."));
										E24onlineLogger.sysLog.debug(MODULENAME + "gwSubStr:"+gwSubStr+ " interSubStr:"+interSubStr);
								    }	
								}
						}
								
					}
					if(isEntry){
					}
					res.sendRedirect(req.getContextPath()+"/webpages/sysmgt/creategateway.jsp?gatewayid="+gatewayId+"&removestatus="+status+"&ipversion="+ipversion);
				}catch(Exception e){
					res.sendRedirect(req.getContextPath()+"/webpages/sysmgt/managegateway.jsp?updstatus="+status+"&ipversion="+ipversion);
					return;
				}
			}else if(Modes.CREATE_PRIORITY == mode){
				String priorityname = req.getParameter("priorityname");
				String prioritydesc = req.getParameter("prioritydesc");
				Tblpriorities tblpriorities = null;
				int retStatus = 0;
				tblpriorities = new Tblpriorities();
				IPrioritiesDAO prioritiesDAO=null;
				try{
					prioritiesDAO=factory.getPrioritiesDAO();
				}catch(Exception e){
					E24onlineLogger.sysLog.error(MODULENAME + "Exception : "+e,e);
				}
				tblpriorities.setPriorityname(priorityname);
				tblpriorities.setDescription(prioritydesc);
				int countPrName=prioritiesDAO.count("where priorityname="+SqlMaker.makeString(priorityname));
				if(countPrName > 0){
					retStatus=MessageConstants.NAMEALREADYEXISTS;
				}else{
					retStatus = prioritiesDAO.insert(tblpriorities);
				}
				E24onlineLogger.sysLog.error(MODULENAME + "Return status from Insert Priority :"+retStatus);
				if(retStatus <= 0){
					res.sendRedirect(req.getContextPath()+"/webpages/sysmgt/createpriorities.jsp?instatus="+retStatus+"&priorityname="+tblpriorities.getPriorityname()+"&prioritydesc="+tblpriorities.getDescription());
					return ;
				}
				E24onlineLogger.audit.info(new AuditObject(AuditObject.PRIORITY,priorityname,AuditObject.INSERT,null,tblpriorities.toString(),loggedInUserName,hostIp));
				res.sendRedirect(req.getContextPath()+"/webpages/sysmgt/managepriorities.jsp?instatus="+retStatus);
				return ;
			}else if(Modes.UPDATE_PRIORITY == mode){
				int priorityId = 0;
				try{
					priorityId = Integer.parseInt(req.getParameter("priorityid"));
						
				}catch(Exception e){
					E24onlineLogger.errorLog.error(MODULENAME + "ERROR IN UPDATING priority "+e,e);
				}
				String priorityName = req.getParameter("priorityname");			
				String prioritydesc = req.getParameter("prioritydesc");
				int retStatus = 0;
				IPrioritiesDAO prioritiesDAO = null;
				try{
					prioritiesDAO=factory.getPrioritiesDAO();
				}catch(Exception e){
					E24onlineLogger.sysLog.error(MODULENAME + "Exception : "+e,e);
				}
				Tblpriorities tblpriorities = prioritiesDAO.getRecordByPrimaryKey(priorityId);
				Tblpriorities cloneTblpriorities = (Tblpriorities)tblpriorities.clone();
				cloneTblpriorities.setPriorityname(priorityName);
				cloneTblpriorities.setDescription(prioritydesc);
				
				int countPrName=prioritiesDAO.count("where priorityname="+SqlMaker.makeString(priorityName)+ " and priorityid != "+priorityId);
				if(countPrName > 0){
					retStatus=MessageConstants.NAMEALREADYEXISTS;
				}else{
					retStatus = prioritiesDAO.update(cloneTblpriorities);
				}
				E24onlineLogger.sysLog.error(MODULENAME + "Return status from update Priority :"+retStatus);
				if(retStatus < 0){
					if (retStatus == MessageConstants.NAMEALREADYEXISTS){ 
						req.getSession(false).setAttribute("tblpriorities",tblpriorities);			
					}
					res.sendRedirect(req.getContextPath()+"/webpages/sysmgt/createpriorities.jsp?priorityid="+priorityId+"&updstatus="+retStatus);
					return ;
				}
				E24onlineLogger.audit.info(new AuditObject(AuditObject.PRIORITY,priorityName,AuditObject.UPDATE,tblpriorities.toString(),cloneTblpriorities.toString(),loggedInUserName,hostIp));
				res.sendRedirect(req.getContextPath()+"/webpages/sysmgt/managepriorities.jsp?updstatus="+retStatus);
				return ;
				
			}else if(Modes.DELETE_PRIORITY == mode){
				String[] strArrPrId = req.getParameterValues("select");
				int length = strArrPrId != null ? strArrPrId.length : 0 ;
				E24onlineLogger.appLog.debug(MODULENAME + "Length of the selected values  are : " + length + " value is  "+ strArrPrId[0]);
				int deleteStatus =-1;
				Tblpriorities tblpriorities = null;
				IPrioritiesDAO prioritiesDAO=factory.getPrioritiesDAO();
				IUserDAO userDAO = factory.getUserDAO();
				IGroupDAO groupDAO = factory.getGroupDAO();
				IGatewayPriorityRelDAO gatewayPriorityRelDAO = factory.getGatewayPriorityRelDAO();
				for(int i=0;i<length;i++){
					try{
						int gwCount = gatewayPriorityRelDAO.count(" where priorityid = "+Integer.parseInt(strArrPrId[i]));
						int count = groupDAO.count(" where priorityid = "+Integer.parseInt(strArrPrId[i]));
						int count1 = userDAO.count(" where priorityid = "+Integer.parseInt(strArrPrId[i]));
						E24onlineLogger.sysLog.debug(MODULENAME + " GatewayPriorityRel has " + gwCount +" records,Group has "+count+ " records, and User has "+count1+ " records for PriorityId "+strArrPrId[i]);
						if(gwCount > 0 || count > 0 || count1 > 0){
							deleteStatus = E24onlineConstants.DEFAULT;
						}else{
							tblpriorities = (Tblpriorities)prioritiesDAO.getRecordByPrimaryKey(Integer.parseInt(strArrPrId[i]));
							if(tblpriorities!=null){
								E24onlineLogger.sysLog.debug(MODULENAME + "Tblpriority is Not null");
								deleteStatus = prioritiesDAO.delete(tblpriorities);
								E24onlineLogger.sysLog.debug(MODULENAME + "DELETE STATUS:"+deleteStatus);
							}else{
								E24onlineLogger.appLog.debug(MODULENAME + "Tblpriority is null");
							}
						}
					}catch(Exception e){ 
						E24onlineLogger.errorLog.error(MODULENAME + "Got Exception while deleting gateway "+e,e);
						deleteStatus = -1 ;
					}	
				}
				res.sendRedirect(req.getContextPath()+"/webpages/sysmgt/managepriorities.jsp?delstatus="+deleteStatus);
				return ;
			}
			
		}catch(Exception e) { 
			E24onlineLogger.sysLog.error(MODULENAME + "Exception in doPost() : "+e,e); 	
		}	
	}
	
	public synchronized String updateNetwork(HttpServletRequest req){ 
		String retStatus = "success";
		HttpSession session = req.getSession(false);
		String loggedInUserName = (String)session.getAttribute("user");
		String hostIp = (String)session.getAttribute("ipaddress");
		try{
			String count = req.getParameter("count");
			int size = count != null ? Integer.parseInt(count) : 0 ;
			
			//Changing Ip of interfaces
			String ip = null ;
			String netmask = null ;
			String oldip = null ;
			String oldnetmask = null ;
			String interfacename = null ;
			
			String line = null ;
			File orgfile = null ;
			File newfile = null ;
			RandomAccessFile rfile = null ;
			StringTokenizer stok = null ;
			String tmpstr = null ;
			
			FileWriter writer = null ;
			boolean valid = false ;
			String network = null ;
			String internalip = null ;
			for (int i=0; i<size; i++){ 
				interfacename = req.getParameter("interfacename"+(i+1));
				ip = req.getParameter("eth"+(i+1)+"ip");
				if (interfacename != null && "eth0".equals(interfacename)){ 
					internalip = ip ;
				}
				netmask = req.getParameter("eth"+(i+1)+"netmask");
				oldip = req.getParameter("oldeth"+(i+1)+"ip");
				oldnetmask = req.getParameter("oldeth"+(i+1)+"netmask");
				
				ip = ip.trim();
				netmask = netmask.trim();
					
				//Check if ip or netmask for that interface is changed
				if (! (ip.equals(oldip) && netmask.equals(oldnetmask)) ){
					//Check if new ip or netmak is valid
					if ( (E24onlineUtilities.validateIPAddress(ip))&& (E24onlineUtilities.validateIPNetmask(netmask)) ){
						E24onlineLogger.sysLog.debug(MODULENAME + "Opening file /etc/sysconfig/network-scripts/ifcfg-"+interfacename.trim() );
						orgfile = new File("/etc/sysconfig/network-scripts/ifcfg-"+interfacename.trim());
						
						if (orgfile.exists()){
							newfile = new File("/etc/sysconfig/network-scripts/iftmp");
							writer = new FileWriter(newfile);
							rfile = new RandomAccessFile(orgfile,"r");
							while ( (line = rfile.readLine() ) != null ) { 
								stok = new StringTokenizer(line,"=");
								tmpstr = stok.hasMoreTokens() ? stok.nextToken(): "" ;
								if ("IPADDR".equals(tmpstr.trim()))  {
									writer.write("IPADDR="+ip+"\n");
								}else if ("NETMASK".equals(tmpstr.trim())) {
									writer.write("NETMASK="+netmask+"\n");
								}else{ 
									writer.write(line+"\n");
								}
							}
							writer.flush();
							writer.close();
							//This should be done by script taking backup of the org file
							orgfile.delete();
							newfile.renameTo(orgfile);
							rfile.close();
						}else{ 
							retStatus = interfacename ;
							E24onlineLogger.sysLog.warn(MODULENAME + "/etc/sysconfig/network-scripts/ifcfg-"+interfacename+" does not exists, skipping this file ");
						}
					}else{ 
						E24onlineLogger.sysLog.warn(MODULENAME + "IP Address or Netmask is not valid, skipping writing to "+interfacename);
					}	
				}	
			}  // End for
			/**
			 * if internal ip is changed, we need to update /etc/hosts and dns file
			 * replacing all entries of oldinternalip to newinternalip
			 */
			//ip = req.getParameter("eth1ip");
			String oldinternalip = req.getParameter("oldinternalip");
			E24onlineLogger.sysLog.debug(MODULENAME + "old:new : "+internalip+":"+oldinternalip);
			String hostip = null ;
			if (! internalip.trim().equals(oldinternalip.trim())) {
				if (E24onlineUtilities.validateIPAddress(internalip)) {
					E24onlineLogger.sysLog.info(MODULENAME + "updating /etc/hosts ... ");
					// Updating /etc/hosts
					orgfile = new File("/etc/hosts");
					if (orgfile.exists()) {
						newfile = new File("/etc/tmphosts");
						rfile = new RandomAccessFile(orgfile,"r");
						writer = new FileWriter(newfile);
						while ( (line = rfile.readLine() ) != null ) { 
							if (line.length() < 2 || line.trim().charAt(0) == '#' ) {
								writer.write(line+"\n");
								continue ;	
							}	
							if (line.indexOf(oldinternalip.trim()) != -1 ){
								stok = new StringTokenizer(line);
								while(stok.hasMoreTokens()){ 
									hostip = stok.hasMoreTokens() ? stok.nextToken().trim() : "" ;
									if (oldinternalip.trim().equals(hostip)){
										writer.write(internalip+" ");
									}else{ 
										writer.write(hostip+" ");
									}	
								}
								writer.write("\n");
							}else{
								writer.write(line+"\n");
							}	
						}
						writer.flush();
						writer.close();
						orgfile.delete();
						newfile.renameTo(orgfile);
						rfile.close();
					}else{ 
						E24onlineLogger.sysLog.warn(MODULENAME + "/etc/hosts does not exists, skipping change in this file");
						retStatus = "hosts";
					}
				
					E24onlineLogger.sysLog.debug(MODULENAME + "updating dns ... ");
					// Updating dns
					orgfile = new File(dnsFile);
					if (orgfile.exists()) {
						newfile = new File(dnsFile+".tmp");
						rfile = new RandomAccessFile(orgfile,"r");
						writer = new FileWriter(newfile);
						String domainname = null ;
						while ( (line = rfile.readLine() ) != null ) { 
							if (line.length() < 2 || line.trim().charAt(0) == '#' ) {
								writer.write(line);
								continue ;	
							}	
							if (line.indexOf(oldinternalip) != -1 ){
								stok = new StringTokenizer(line);
								while(stok.hasMoreTokens()){
									domainname = stok.nextToken().trim();
									if (domainname.equals(oldinternalip)){
										if (stok.hasMoreTokens()) writer.write(internalip+"\t");
										else writer.write(ip);
									}else if (domainname.equals(oldinternalip+".")){
										if (stok.hasMoreTokens()) writer.write(internalip+".\t");
										else writer.write(internalip+".");
									}else {
										if (stok.hasMoreTokens()) writer.write(domainname+"\t");
										else writer.write(domainname);
									}	
								}		
							}else{
									writer.write(line);
							}
							writer.write("\n");
						}
						writer.flush();
						writer.close();
						orgfile.delete();
						newfile.renameTo(orgfile);
						rfile.close();
					}
				}	
			}						
			// Restarting network
			E24onlineLogger.audit.info(new AuditObject(AuditObject.NETWORKCONFIG,null,AuditObject.UPDATE,null,null,loggedInUserName,(String)session.getAttribute("ipaddress")));	
			Process process = Runtime.getRuntime().exec("sh /etc/rc.d/init.d/network restart");
			process.waitFor();
			process = Runtime.getRuntime().exec("sh /etc/rc.d/init.d/named restart");
			process.waitFor();	
			
			E24onlineUtilities.getPrimaryInterfaceDetails(true);
		}catch(Exception e){ 
			retStatus = "error";
			E24onlineLogger.sysLog.error(MODULENAME + "Got Exception in updatenetwork : "+e,e);
		}	
		return retStatus ;
	}
	
	private void changeCacheInterface(int gatewayId,int effectiveGatewayId){
		E24onlineLogger.sysLog.debug(MODULENAME + "This is change interface for :"+gatewayId + " And :"+effectiveGatewayId);
		IGatewayDAO gatewayDao=null;
		
		IGatewayNetworkRelDAO gatewayNetworkRelDao=null;
		try{
			gatewayDao=DAOFactory.instance(DAOFactory.HIBERNATE).getGatewayDao();
			Tblgateway gwBean = (Tblgateway)gatewayDao.getRecordByPrimaryKey(gatewayId);
			Tblgateway effectiveGWBean = (Tblgateway)gatewayDao.getRecordByPrimaryKey(effectiveGatewayId);
			gatewayNetworkRelDao=DAOFactory.instance(DAOFactory.HIBERNATE).getGatewayNetworkRelDao();
		
			ArrayList gwNetList = (ArrayList) gatewayNetworkRelDao.getListByKeyandValue("id.gatewayid",gatewayId);
			int size = gwNetList.size();
			E24onlineLogger.sysLog.debug(MODULENAME + "GWNetList SIZE IS: "+size);
			Tblgatewaynetworkrel gwNetworkBean = null;
			String network = null;
			String outGoingInterface = null;
			E24onlineLogger.appLog.debug(MODULENAME + "changeCacheInterface() getway network rel list size =  "+size);
			for(int i=0;i<size;i++){
				gwNetworkBean = (Tblgatewaynetworkrel)gwNetList.get(i);
				network = gwNetworkBean.getId().getNetwork();
				outGoingInterface = getInterfaceByGWAddress(effectiveGWBean.getIpaddress());
			}
		}catch(Exception e){
			E24onlineLogger.errorLog.error(MODULENAME + "Exception "+e,e);
		}
	}
	
	private static String getInterfaceByGatewayAddress(String ipaddress){
		String interfaceStr = null;
		String getInterfaceByGW = "/usr/local/scripts/getdevbygw.sh "+ipaddress;
		try{
			E24onlineLogger.sysLog.debug(MODULENAME + "getInterfaceByGWAddress:"+getInterfaceByGW);
			Process dataTransferProcess = Runtime.getRuntime().exec(getInterfaceByGW);
			InputStream is = dataTransferProcess.getInputStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
			interfaceStr = br.readLine();
			is.close();
		}catch(Exception e){
			E24onlineLogger.sysLog.error(MODULENAME + "Error in getInterfaceByGWAddress:"+e,e);
		}
		E24onlineLogger.sysLog.debug(MODULENAME + "Return string: "+interfaceStr);
		return interfaceStr;
	}
	
	private static String getOperationOnIpAddress(String ipAddress, String operation){
		String expandedIpAddress = null;
		String getExpandedIpAddress = "/usr/local/scripts/ipv6_address_sipcalc.sh " +  operation + " "  + ipAddress;
		try {
			E24onlineLogger.sysLog.debug(MODULENAME + "getExpandedIpAddress : "+getExpandedIpAddress);
			Process dataTransferProcess = Runtime.getRuntime().exec(getExpandedIpAddress);
			InputStream in = dataTransferProcess.getInputStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			expandedIpAddress = br.readLine();
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			E24onlineLogger.sysLog.error(MODULENAME + "Error in getExpandedIpAddress:"+e,e);
		}
		E24onlineLogger.sysLog.debug(MODULENAME + "Return string: " + expandedIpAddress);
		return expandedIpAddress;
	}
	
	private static String getInterfaceByIpv6GatewayAddress(String ipv6address){
		String interfaceStr = null;
		String getInterfaceByGW = "/usr/local/scripts/getdevbygwipv6.sh "+ipv6address;
		BufferedReader br = null;
		Process dataTransferProcess = null;
		try{
			E24onlineLogger.sysLog.debug(MODULENAME + "getInterfaceByGWAddress:"+getInterfaceByGW);
			dataTransferProcess = Runtime.getRuntime().exec(getInterfaceByGW);
			int status = dataTransferProcess.waitFor();
			InputStream is = dataTransferProcess.getInputStream();
			br = new BufferedReader(new InputStreamReader(is));
			interfaceStr = br.readLine();
			is.close();
		}catch(Exception e){
			E24onlineLogger.sysLog.error(MODULENAME + "Error in getInterfaceByGWAddress:"+e,e);
		}
		finally{
			try{
				if ( br != null ) br.close();
			}catch(Exception e){
				E24onlineLogger.errorLog.error(MODULENAME+"Error while closing stream : "+e,e);
			}
			try {
				ReleaseProcessResourceUtilities.releaseProcessResources(dataTransferProcess);
			} catch (Exception e) {
				E24onlineLogger.errorLog.error(MODULENAME + "Exception while releasing Process resources in getInterfaceByIpv6GatewayAddress(): "+ e,e);
			}
		}
		E24onlineLogger.sysLog.debug(MODULENAME + "Return string:"+interfaceStr);
		return interfaceStr;
	}

	private static String getInterfaceByGWAddress(String ipaddress){
		String interfaceStr = null;
		String getInterfaceByGW = "/usr/local/scripts/getipbygw.sh "+ipaddress;
		try{
			E24onlineLogger.sysLog.debug(MODULENAME + "getInterfaceByGWAddress:"+getInterfaceByGW);
			Process dataTransferProcess = Runtime.getRuntime().exec(getInterfaceByGW);
			InputStream is = dataTransferProcess.getInputStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
			interfaceStr = br.readLine();
			is.close();
		}catch(Exception e){
			E24onlineLogger.sysLog.error(MODULENAME + "Error in getInterfaceByGWAddress:"+e,e);
		}
		E24onlineLogger.sysLog.debug(MODULENAME + "Return string:"+interfaceStr);
		return interfaceStr;
	}
}	


