package cyberoam.resourcemgt.helper;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.elitecore.hibernate.base.DAOFactory;

import cyberoam.access.poolmgt.IPPoolManager;
import cyberoam.integration.base.CyberoamCommunicator;
import cyberoam.leasedline.configuration.ReadLeasedLineUsers;
import cyberoam.leasedline.user.LeasedLineUser;
import cyberoam.logon.server.configuration.LogonServerProperties;
import cyberoam.nas.common.NasPortTypes;
import cyberoam.nas.common.QosConstants;
import cyberoam.nas.common.ResourceParameters;
import cyberoam.syslogcomm.helper.SyslogCommunicationObject;
import cyberoam.syslogcomm.helper.SyslogCommunicator;
import cyberoam.util.FirewallChainsUtility;
import cyberoam.util.NASModesUtility;
import e24online.corporate.customization.CustomizationConstants;
import e24online.corporate.policy.dao.base.IGroupDAO;
import e24online.corporate.policy.entity.Tblgroup;
import e24online.corporate.systemmgt.dao.ibase.IGatewayPriorityRelDAO;
import e24online.corporate.systemmgt.dao.ibase.IInternalNetworkDAO;
import e24online.corporate.systemmgt.dao.ibase.IVlanInterfacesDAO;
import e24online.corporate.systemmgt.entity.Tblgatewaypriorityrel;
import e24online.corporate.user.dao.ibase.IIpPool;
import e24online.corporate.user.dao.ibase.IUserDAO;
import e24online.corporate.user.entity.Tblippool;
import e24online.corporate.user.pojo.Tbluser;
import e24online.corporate.utilities.BandwidthScriptParameters;
import e24online.corporate.utilities.E24onlineConstants;
import e24online.corporate.utilities.PropertyReader;
import e24online.corporate.utilities.ResourceConfigProvider;
import e24online.corporate.utilities.ZeroConfPropertyReader;
import e24online.general.CustomizationController;
import e24online.general.ModuleController;
import e24online.general.dao.ibase.IIPAddressDAO;
import e24online.general.dao.ibase.ILiveUserDAO;
import e24online.general.dao.ibase.ILiveUserDetailDAO;
import e24online.general.dao.ibase.INetworkDAO;
import e24online.general.entity.Tblipaddress;
import e24online.general.entity.Tblliveuser;
import e24online.general.entity.Tblliveuserdetail;
import e24online.general.entity.Tblnetwork;
import e24online.log.E24onlineLogger;
import e24online.log.ResourceManagerLogger;
import e24online.utilities.VlanUtilities;


public class ResourceAccessProvider
{
	/**
	 * This has to be called from TOMCAT JVM
	 */
	
	//private static ArrayList redirectedGWList = GatewayNetworkRelBean.getRedirectedGWNetworkList();
	
	private static ArrayList redirectedGWList = new ArrayList();
	private static final String LOGMODULE = "[LOGGING-ResourceAccessProvider]: ";
	private static final String BWMODULE = "[BWMGMT: ResourceAccessProvider]: ";
	private static ILiveUserDetailDAO liveuserdetailDAO = null;
	private static boolean isLoginOnce = CustomizationController.isCustomizationVisible(CustomizationConstants.LOGINONCE);
	private static boolean isZeroConfigurationVisible = ModuleController.isModuleVisible(E24onlineConstants.ZEROCONFIGURATION);
	private static boolean isIpsetIPMACBindingVisible = CustomizationController.isCustomizationVisible(CustomizationConstants.IPSETIPMACBINDING);
	private static boolean isSnatIpaddressVisible = ModuleController.isModuleVisible(E24onlineConstants.SNATIPADDRESSMANAGEMENT);
	/**** For websurfing logger module ****/
	private static boolean isWebSurfingLoggerModuleVisible = ModuleController.isModuleVisible(E24onlineConstants.WEBSURFINGLOGGER);

	/**** For syslog management module ****/
	private static boolean isNetKaptureVisible = ModuleController.isModuleVisible(E24onlineConstants.NETKAPTURE);
	
	private static boolean isCacheQOSVisible = ModuleController.isModuleVisible(E24onlineConstants.CACHEQOS);
	
	//FLAG FOR NETWORK ID SUPPORT
	//private static boolean isNetworkId=false;
	private static Tblnetwork nwBean=null;
	private static DAOFactory factory=null;
	
	static{
		factory=DAOFactory.instance(DAOFactory.HIBERNATE);
		liveuserdetailDAO=factory.getLiveUserDetailDAO();
	}
	
	public static boolean login(ResourceParameters resObj,boolean isReconnectAll)
	{
		boolean isNetworkId=false;
		int bwPolicyId = resObj.getBandwidthPolicyId();
		String qos = resObj.get24OnlineQos();
		String userName = resObj.getUserName();
		String ipAddress = resObj.getIPAddress();
		int sessionId = resObj.getSessionId();
		String macAddress = resObj.getMacAddress();
		String snatip = resObj.getSNATIPAddress();
		boolean snatipfromresponse = resObj.isSNATIPFromResponse();
		
		String MODULE = "[ResourceAccessProvider_Login:<" + userName + ":" + ipAddress + ">]: " ;
		
		System.out.println(MODULE + "Session id:"+sessionId);
		ResourceManagerLogger.appLog.info(MODULE + "ResourceAccessProvider login called for "+resObj);
		
		
		Tblliveuserdetail liveUserDetailBean = new Tblliveuserdetail();
		liveUserDetailBean.setAcctsessionid(sessionId);
		
		long start = System.currentTimeMillis();
		IIPAddressDAO ipAddressDAO=factory.getIpAddressDAO();
		Tblipaddress ipAddressBean = ipAddressDAO.getRecordByPrimaryKey(ipAddress);
		ResourceManagerLogger.appLog.debug(MODULE + "IPADDRESS BEAN: "+ipAddressBean);
		Tblippool ippoolBean = null ;
		String effectivesnatip = snatip ;
		String poolChainName = null ;
		boolean islive = false ;
		boolean mapWithLive = false ;
		IIpPool ipPoolDao=factory.getIpPoolDAO();
		nwBean=null;
		
		
		
		if (ipAddressBean != null){
			ippoolBean = (Tblippool)ipPoolDao.getRecordByPrimaryKey(ipAddressBean.getPoolid());
			if(ippoolBean != null){
				ResourceManagerLogger.appLog.debug(MODULE + "IpPoolBean is not null  type : " +ippoolBean.getType()); 
				if (ippoolBean.getType() == E24onlineConstants.LIVE ){ 
					islive = true ;
				}else if(ippoolBean.getType() == E24onlineConstants.NM || ippoolBean.getType()==E24onlineConstants.SNAT){
					mapWithLive = true;
				}
			}
			ResourceManagerLogger.appLog.debug(MODULE + "isLive = "+islive +" mapWithLive = "+mapWithLive+" snatip = "+snatip);
			
			if(resObj.isSNATIPFromResponse() == true){
				mapWithLive = true;
				ResourceManagerLogger.appLog.debug(MODULE + " Snatipfromrequest is true so fetching SNAT IP from liveuserdetail  ");
				effectivesnatip = resObj.getSNATIPAddress();
			}else if(snatip != null){
				if(ippoolBean.getType() == E24onlineConstants.NM){
					Tblippool nmIPPoolBean = (Tblippool)ipPoolDao.getRecordByPrimaryKey(ippoolBean.getLivepoolid());
					effectivesnatip = ipPoolDao.getSnatIpAfterRestartNas(nmIPPoolBean, snatip, new Integer(sessionId));
				}else{
					effectivesnatip = snatip;
				}
				ResourceManagerLogger.appLog.debug(MODULE + " Snatipfromrequest from liveuser :"+snatip+", after leased :"+effectivesnatip);
			}else{
				ResourceManagerLogger.appLog.debug(MODULE + " Snatipfromrequest is false so calling getEffectiveSnatIPAddress() to get SNAT IP ");
				effectivesnatip = getEffectiveSnatIPAddress(ipAddress,ippoolBean,new Integer(sessionId)) ;
			}

			try{
				liveUserDetailBean.setSnatipaddress(effectivesnatip);
				ResourceManagerLogger.appLog.debug(MODULE + "SNAT IP IS BEFORE UPDATE " + liveUserDetailBean.getSnatipaddress());
				//int iUpdateStatus = liveUserDetailBean.updateRecord();
				int iUpdateStatus = liveuserdetailDAO.updateSNATIPAddress(liveUserDetailBean);
				if (iUpdateStatus > 0 )
					ResourceManagerLogger.appLog.debug(MODULE + "Update Successful Status Is: " + iUpdateStatus);
				else
					ResourceManagerLogger.appLog.debug(MODULE + "Update UnSuccessful Status Is: " + iUpdateStatus);
								
			}catch(Exception e){
				ResourceManagerLogger.errorLog.error(MODULE + "Exception in live user update:"+e,e);
			}
		
			poolChainName = "p"+ippoolBean.getPoolid();				

		}else{
			try{
				ResourceManagerLogger.appLog.debug(MODULE + "IPAddressBean is null, thus searching from network");
				
				int poolId=-1;
				// THE IP IS NETWORK ID INSTEAD OF SINGLE IPADDRESS 
				INetworkDAO networkDAO=factory.getNetworkDao();
				nwBean=(Tblnetwork) networkDAO.getRecordByPrimaryKey(ipAddress);
				if(nwBean!=null){
					isNetworkId=true;
					poolId = nwBean.getPoolid();
				}
				//IF IP FALLS IN VLAN, GET POOLID for VLAN
				if(poolId==-1){
					ResourceManagerLogger.appLog.debug(MODULE + "NetworkBean not found, thus searching from VLAN");
					int vlanId = VlanUtilities.getVlanIdByIpAddress(ipAddress);
					if(vlanId != E24onlineConstants.NOVLAN){
						IVlanInterfacesDAO vlanInterfacesDAO = factory.getVlanInterfacesDAO();
						poolId = vlanInterfacesDAO.getPoolIdByVlanId(vlanId);
					}
				}
				
				// IF ZERO CONFIGURATION IS ON, SET POOLID TO DEFAULT POOL'S ID 
				if(poolId==-1 && isZeroConfigurationVisible){
					poolId=ZeroConfPropertyReader.DEFAULTPOOLID;
					ResourceManagerLogger.appLog.debug(MODULE + "ZeroConfiguration is Enabled,so poolId:"+poolId);
				}
				
				ippoolBean = (Tblippool)ipPoolDao.getRecordByPrimaryKey(poolId);
				if(ippoolBean != null){
					if (ippoolBean.getType() == E24onlineConstants.LIVE ){ 
						islive = true ;
					}else if(ippoolBean.getType() == E24onlineConstants.NM){
						mapWithLive = true;
					}
				}
			

				if(snatipfromresponse){
					ResourceManagerLogger.appLog.debug(MODULE + "SNAT IP Received so its map with Live set true ");				
					mapWithLive = true;	
					ResourceManagerLogger.appLog.debug(MODULE + "Snatipfromrequest is true so fetching SNAT IP from liveuserdetail");
					effectivesnatip = resObj.getSNATIPAddress();
				}else{
					ResourceManagerLogger.appLog.debug(MODULE + "Snatipfromrequest is false so calling getEffectiveSnatIPAddress() to get SNAT IP ");
					effectivesnatip = getEffectiveSnatIPAddress(ipAddress,ippoolBean,new Integer(sessionId)) ;
				}			
				
				// Get effectivesnatip for iptables chains
				/*if(snatip==null){
					effectivesnatip = getEffectiveSnatIPAddress(ipAddress,ippoolBean,new Integer(sessionId),liveUserBean.getUserid()) ;
				}else{
					effectivesnatip=snatip;
				}*/
				poolChainName = "p"+ippoolBean.getPoolid();

				ResourceManagerLogger.appLog.debug(MODULE + "SNAT IP FOR NETWORK IP IS: " + effectivesnatip);			
				liveUserDetailBean.setSnatipaddress(effectivesnatip);
				ResourceManagerLogger.appLog.debug(MODULE + "SNAT IP FOR NETWORK IP: BEFORE UPDATE IS:" + liveUserDetailBean.getSnatipaddress());
				
				int iUpdateStatus = liveuserdetailDAO.updateSNATIPAddress(liveUserDetailBean);
				if (iUpdateStatus > 0 )
					ResourceManagerLogger.appLog.debug(MODULE + "Update Successful Status Is: " + iUpdateStatus);
				else
					ResourceManagerLogger.appLog.debug(MODULE + "Update UnSuccessful Status Is: " + iUpdateStatus);
			}catch(Exception e){
				ResourceManagerLogger.errorLog.error(MODULE + "Exception in live user update with Network IP:"+e,e);
			}
			
		}//END OF ELSE
		
		
		long scrstart = System.currentTimeMillis();
		
		if (ippoolBean != null && ippoolBean.getType() == E24onlineConstants.NM){
			Tblippool nmIPPoolBean = (Tblippool)ipPoolDao.getRecordByPrimaryKey(ippoolBean.getLivepoolid());
			ipPoolDao.removeNPLIVEIpaddress(liveUserDetailBean.getSnatipaddress(),nmIPPoolBean);
		}
		
		scrstart = System.currentTimeMillis();
		resObj.setMapWithLive(mapWithLive);
		resObj.setLivePool(islive);
		resObj.setPoolChainName(poolChainName);
		resObj.setSNATIPAddress(effectivesnatip);
		resObj.setNetworkId(isNetworkId);
		
		ResourceManagerLogger.appLog.debug(MODULE+"Calling applyfirewallchains with Updated ResourceParameter Obj = "+resObj);
		if(isReconnectAll){
			FirewallChainsUtility.applyFirewallChains(resObj,true);
		}else{
			applyFirewallChains(resObj,true); // insert/ delete
		}
		ResourceManagerLogger.appLog.info(MODULE + "ResourceAccessProvider applyfirewallchains from login end");
		ResourceManagerLogger.appLog.debug(MODULE + "Total time in applyFirewallChains : "+ (System.currentTimeMillis()-scrstart) );
		ResourceManagerLogger.appLog.debug(MODULE + "Total time in login : "+ (System.currentTimeMillis()-start) );
		
		
		/** For Syslog Communication for Websurfinglogger and Netkapture **/
		
		ResourceManagerLogger.appLog.debug(MODULE+"Values of isWebSurfingLoggerModuleVisible : "+isWebSurfingLoggerModuleVisible
			+",  isNetKaptureVisible : "+isNetKaptureVisible);
		
		if ( isWebSurfingLoggerModuleVisible || isNetKaptureVisible ){
			try{
				SyslogCommunicationObject sco = SyslogCommunicationObject.getLoginCommObject
					(ipAddress, userName, effectivesnatip, macAddress);
				SyslogCommunicator.sendObject(sco);
			}catch (Exception e) {
				ResourceManagerLogger.errorLog.error(MODULE+" Exception while sending Object to Syslog : "+e,e);
			}
		}
		
		/** For Cyberoam Integration **/ 
		/** RESOURCE MANAGER FLOW : If cyberoam communicator is initialized then send the logout request. **/
		
		if ( CyberoamCommunicator.initialized ){ 
			try{
				ResourceManagerLogger.appLog.debug(MODULE+"Enqueuing login request of ( ipAddress, effectivesnatip, userName, islive ) : ( "+ipAddress+", "+effectivesnatip+", "+userName+", "+islive+" )." );
				if ( islive ) effectivesnatip = ipAddress;
				CyberoamCommunicator.createAndEnqueueLoginPushRequest( ipAddress,effectivesnatip, userName );
				ResourceManagerLogger.appLog.debug(MODULE+"Enqueued login request of ( ipAddress, effectivesnatip, userName, islive ) : ( "+ipAddress+", "+effectivesnatip+", "+userName+", "+islive+" )." );

			}catch (Exception e) {
				ResourceManagerLogger.errorLog.error(MODULE+" Exception while Enqueuing push request : "+e,e);
			}
		}
			
		return true;
	}

	public static boolean logout(ResourceParameters resObj)
	{
		String userName = resObj.getUserName();
		int policyID = resObj.getSecurityPolicyId();
		int bwPolicyId = resObj.getBandwidthPolicyId();
		String ipAddress = resObj.getIPAddress();
		int sessionId = resObj.getSessionId();
		String snatip = resObj.getSNATIPAddress();
		boolean snatipfromresponse = resObj.isSNATIPFromResponse();
		boolean isNetworkId=false;
		Tblippool ippoolBean = null ;
		Tblliveuser luBean = null;
		String effectivesnatip = null;
		Integer sessionIdObject = null;
		boolean  retValue = false;
		nwBean=null;
		boolean islive = false ;
		
		String MODULE = "[ResourceAccessProvider_Logout:<" + userName + ":" + ipAddress + ">] " ;
		
		ResourceManagerLogger.appLog.info(MODULE + "ResourceAccessProvider logout called for user<->ip " + userName + "<->" + ipAddress);
		try{
				long start = System.currentTimeMillis();
		
				IIPAddressDAO ipAddressDAO=factory.getIpAddressDAO();
				Tblipaddress ipAddressBean = ipAddressDAO.getRecordByPrimaryKey(ipAddress);
				IIpPool ipPoolDao=factory.getIpPoolDAO();
				if (ipAddressBean != null){
					ippoolBean = (Tblippool)ipPoolDao.getRecordByPrimaryKey(ipAddressBean.getPoolid());
					if(ippoolBean != null && (ippoolBean.getType()== E24onlineConstants.NM || ippoolBean.getType()== E24onlineConstants.LIVE)){
						ResourceManagerLogger.appLog.debug(MODULE + "NM/LIVE POOL in logout : "+ippoolBean.getType());
					}
				}else{
					// THE IP IS NETWORK ID INSTEAD OF SINGLE IPADDRESS 
					INetworkDAO networkDAO=factory.getNetworkDao();
					nwBean=(Tblnetwork)networkDAO.getRecordByPrimaryKey(ipAddress);
					if(nwBean!=null){
						isNetworkId=true;
						ippoolBean = (Tblippool)ipPoolDao.getRecordByPrimaryKey(nwBean.getPoolid());
						if(ippoolBean != null && (ippoolBean.getType()== E24onlineConstants.NM || ippoolBean.getType()== E24onlineConstants.LIVE)){
							ResourceManagerLogger.appLog.debug(MODULE + "NM/LIVE POOL in logout for Network IP: "+ippoolBean.getType());
						}	
					}else{
						
						int vlanId = VlanUtilities.getVlanIdByIpAddress(ipAddress);
						if(vlanId != E24onlineConstants.NOVLAN){
							IVlanInterfacesDAO vlanInterfacesDAO = factory.getVlanInterfacesDAO();
							int poolId = vlanInterfacesDAO.getPoolIdByVlanId(vlanId);
							ippoolBean =  (Tblippool)ipPoolDao.getRecordByPrimaryKey(poolId);
						}
					
						if(isZeroConfigurationVisible && ippoolBean == null){
							ResourceManagerLogger.appLog.debug(MODULE + "isZeroConfigurationVisible: " + isZeroConfigurationVisible);
							ippoolBean = (Tblippool)ipPoolDao.getRecordByPrimaryKey(ZeroConfPropertyReader.DEFAULTPOOLID);
							ResourceManagerLogger.appLog.debug(MODULE + "ZeroConfiguration enabled IPPoolBean : "+ippoolBean.getType());
	 					}
					}
				}

				sessionIdObject=new Integer(sessionId);				
				//Get appropriate(final) ippoolbean
				Tblippool finalIPPoolBean=null;
				if(ippoolBean != null){
					if (ippoolBean.getType() == E24onlineConstants.NM){
						finalIPPoolBean=(Tblippool)ipPoolDao.getRecordByPrimaryKey(ippoolBean.getLivepoolid());
					}else if (ippoolBean.getType() == E24onlineConstants.LIVE){
						finalIPPoolBean=ippoolBean;
					}
				}
				
				
				//First get the effectivesnatip from the Map				
				if(finalIPPoolBean != null && (ipPoolDao.getLeasedIPMap(finalIPPoolBean)).containsKey(sessionIdObject)){
					effectivesnatip=(String)(ipPoolDao.getLeasedIPMap(finalIPPoolBean)).get(sessionIdObject);
					ResourceManagerLogger.appLog.debug(MODULE + "SNAT ipaddress in logout(from MAP) : "+effectivesnatip + " : SESSION-ID : " + sessionIdObject);
				}else{//Go for database or access server
					ILiveUserDAO liveuserDAO=factory.getLiveUserDAO();
					luBean = liveuserDAO.getRecordByPrimaryKey(new Integer(sessionId));
					if(luBean == null){
						ResourceManagerLogger.appLog.debug(MODULE + "GOT NULL LIVEUSERBEAN BY USERNAME AND IPADDRESS");
						//If No Live user Records Available then take snatip provided by Access Server
						effectivesnatip = snatip;
						ResourceManagerLogger.appLog.debug(MODULE + "SNAT ipaddress in logout(from Access Server) : "+effectivesnatip);
					}else{
						effectivesnatip = luBean.getSnatIpAddress();
						ResourceManagerLogger.appLog.debug(MODULE + "GOT LIVEUSERBEAN BY USER ID: EFFECTIVE SNAT ADDRESS IN LOGOUT: " + effectivesnatip + " : IPADDRESS : " + luBean.getIpAddress());
						ResourceManagerLogger.appLog.debug(MODULE + "SNAT ipaddress in logout(from DB) : "+effectivesnatip + " : IPADDRESS : " + luBean.getIpAddress());
					}
				}
				
				if (ippoolBean != null){
					if (!(ipAddress.equals(effectivesnatip)) && effectivesnatip != null && !(("").equals(effectivesnatip)) && !("null").equalsIgnoreCase(effectivesnatip) ){
						if (ippoolBean.getType() == E24onlineConstants.NM){
							ResourceManagerLogger.appLog.debug(MODULE + "E24onlineConstants.NM : "+ippoolBean.getType());
							Tblippool nmpoolBean = (Tblippool)ipPoolDao.getRecordByPrimaryKey(ippoolBean.getLivepoolid());
							if(!"0.0.0.0".equals(effectivesnatip) && !snatipfromresponse){

								if(IPPoolManager.doesIpBelongToPool(effectivesnatip, nmpoolBean.getPoolid())){
									ResourceManagerLogger.appLog.debug(MODULE + "Going to release IP:" + effectivesnatip);
								ipPoolDao.releaseLiveIpaddress(effectivesnatip,sessionIdObject,nmpoolBean);
							}else{
									ResourceManagerLogger.appLog.debug(MODULE + "Ip does not belong to the pool so not going to release live ip - effectivesnatip: " + effectivesnatip);
								}
							}else{
								ResourceManagerLogger.appLog.debug(MODULE + "SNAT IP from RADIUS or 0.0.0.0, So No Need To Release IP ");
							}
						}
					}else{ 
						if (ippoolBean.getType() == E24onlineConstants.LIVE){
							ResourceManagerLogger.appLog.debug(MODULE + "E24onlineConstants.LIVE : "+ippoolBean.getType());
							if(!snatipfromresponse && !"0.0.0.0".equals(ipAddress) && ipAddress != null && !(("").equals(ipAddress)) && !("null").equalsIgnoreCase(ipAddress) ){
								if(IPPoolManager.doesIpBelongToPool(ipAddress, ippoolBean.getPoolid())){
									ResourceManagerLogger.appLog.debug(MODULE + "Going to release IP:" + ipAddress);
								ipPoolDao.releaseLiveIpaddress(ipAddress,sessionIdObject,ippoolBean);
								}else{
									ResourceManagerLogger.appLog.debug(MODULE + "Ip does not belong to the pool so not going to release live ip: " + ipAddress);
								}
							}else{
								ResourceManagerLogger.appLog.debug(MODULE + "SNAT IP from RADIUS or 0.0.0.0, So No Need To Release IP ");
							}
						}
					}
				}	
				
				boolean mapWithLive = false ;
		
				if(ippoolBean != null){
					if (ippoolBean.getType() == E24onlineConstants.LIVE ){ 
						islive = true ;
					}else if(ippoolBean.getType() == E24onlineConstants.NM ){
						mapWithLive = true;
					}
				}
				
				if(snatipfromresponse){
					ResourceManagerLogger.appLog.debug(MODULE + "SNAT IP Received so its map with Live set true ");
					mapWithLive=true;
				}
				
				String poolChainName = null ;
				if(ippoolBean != null){
					poolChainName = "p"+ippoolBean.getPoolid();
				}	

				//UserBean userBean = (UserBean)UserBean.getRecordByPrimaryKey(userId);
				//userBean.setIPAddress(ipAddress);
				ResourceManagerLogger.appLog.debug(MODULE + "bwPolicyId="+bwPolicyId);
				ResourceManagerLogger.appLog.info(MODULE + "applyfirewallchains from logout called");
				resObj.setMapWithLive(mapWithLive);
				resObj.setLivePool(islive);
				resObj.setPoolChainName(poolChainName);
				resObj.setSNATIPAddress(effectivesnatip);
				resObj.setSessionId(sessionId);
				resObj.setNetworkId(isNetworkId);
				applyFirewallChains(resObj, false);
				//applyFirewallChains(userId,userName,ipAddress,islive,mapWithLive,poolChainName,policyID,effectivesnatip,false,new Integer(sessionId),bwPolicyId,qos,macAddress,clientType);
				ResourceManagerLogger.appLog.info(MODULE + "ResourceAccessProvider applyfirewallchains from logout end");
		
				ResourceManagerLogger.appLog.debug(MODULE + "Total time in logout: "+ (System.currentTimeMillis()-start));		
		}catch(Exception e){
			ResourceManagerLogger.errorLog.error(MODULE + "Error in user logout:"+e,e);		
		}
		
		/** For Syslog Communication for Websurfinglogger and Netkapture **/
		
		ResourceManagerLogger.appLog.debug(MODULE+"Values of isWebSurfingLoggerModuleVisible : "+isWebSurfingLoggerModuleVisible
				+",  isNetKaptureVisible : "+isNetKaptureVisible);
		
		if ( isWebSurfingLoggerModuleVisible || isNetKaptureVisible ){
			try{
				SyslogCommunicationObject sco =	SyslogCommunicationObject.getLogoutCommObject(ipAddress);
				SyslogCommunicator.sendObject(sco);
			}catch (Exception e) {
				ResourceManagerLogger.errorLog.error(MODULE+"Exception while sending Object to Syslog : "+e,e);
			}
		}
		
		/** For Cyberoam Integration **/
		/** RESOURCE MANAGER FLOW : If cyberoam communicator is initialized then send the logout request. **/
		
		if ( CyberoamCommunicator.initialized ){
			try{
				ResourceManagerLogger.appLog.debug(MODULE+"Enqueuing logout request of ( ipAddress, effectivesnatip, userName, islive ) : ( "+ipAddress+", "+effectivesnatip+", "+userName+", "+islive+" )." );
				if ( islive ) effectivesnatip = ipAddress;
				CyberoamCommunicator.createAndEnqueueLogoutPushRequest(ipAddress,effectivesnatip, userName);
				ResourceManagerLogger.appLog.debug(MODULE+"Enqueuing logout request of ( ipAddress, effectivesnatip, userName, islive ) : ( "+ipAddress+", "+effectivesnatip+", "+userName+", "+islive+" )." );
			}catch (Exception e) {
				ResourceManagerLogger.errorLog.error(MODULE+" Exception while Enqueuing push request : "+e,e);
			}
		}
		
		return retValue;
	}
	
	
	private static void applyFirewallChains(ResourceParameters resObj,boolean insert){ 
		int sessionId = resObj.getSessionId();
		int userId = resObj.getUserId();
		String userName = resObj.getUserName();
		String ipAddress = resObj.getIPAddress();
		int bwPolicyId = resObj.getBandwidthPolicyId();
		String qos = resObj.get24OnlineQos();
		boolean islive = resObj.isLivePool();
		boolean mapWithLive = resObj.isMapWithLive();
		String effectivesnatip = resObj.getSNATIPAddress();
		String poolChain = resObj.getPoolChainName();
		int clientType = resObj.getNasPortType();
		String macAddress = resObj.getMacAddress();
		int policyID = resObj.getSecurityPolicyId();
		boolean isNetworkId = resObj.isNetworkId();
		String bandwidth = resObj.getBandwidth();
		//ankita Ticket1104551 atmosphere
		String gwip="";
		Tbluser userBean = null;
		if(ModuleController.isModuleVisible("gatewayipfrompackage") && (NASModesUtility.IS_MULTI_MODE || NASModesUtility.IS_RADIUS_MODE)){
		IUserDAO userDao = factory.getUserDAO();
		userBean = userDao.getRecordByPrimaryKey(userId);
		IGroupDAO groupDao = factory.getGroupDAO();
		Tblgroup groupBean = groupDao.getRecordByPrimaryKey(userBean.getGroupid());
		gwip = groupBean.getGatewayipaddress();
		}
		//end
		
		int gwId = -1;
		if(ModuleController.isModuleVisible("multiplegateways")){
			if(resObj.getGwpriority()!=-1){
				gwId = getGatewayId(resObj.getGwpriority());
			}
		}
		String MODULE = "[RAP_applyFirewallChains():<" + userName + ":" + ipAddress + ">] " ;
		if(ModuleController.isModuleVisible("gatewayipfrompackage")){
		ResourceManagerLogger.appLog.info(MODULE +"gwip::"+gwip + " userid :: "+userId+" groupid::"+userBean.getGroupid()); 
		}
		System.out.println(MODULE + "Session id:"+sessionId);
		ResourceManagerLogger.appLog.info(MODULE +"Session id:"+sessionId); 
		ResourceManagerLogger.appLog.info(MODULE + "ResourceAccessProvider applyfirewallchains called");
		StringBuffer script = new StringBuffer()  ;
		StringBuffer bwScript = new StringBuffer();
		String action = null ;
		BandwidthScriptParameters bwParamObj = null;
		ResourceConfigProvider resorceConf = new ResourceConfigProvider(userId,userName,sessionId,ipAddress,bwPolicyId);
		//int userId = userBean.getUserId();
		String toIPAddress = "NONE";
		IInternalNetworkDAO internalNetworkDAO = factory.getInternalNetworkDAO();
		
		if (insert){ 
			if(bandwidth==null){
				bwParamObj = resorceConf.execAddCommand(sessionId);
			}else{
				bwParamObj = resorceConf.execAddCommand(sessionId,bandwidth);
			}
			System.out.println(MODULE+"bwParamObj="+bwParamObj + "\n");
			ResourceManagerLogger.appLog.info(MODULE+"bwParamObj="+bwParamObj);
			script.append("sh " + PropertyReader.LOGINSCRIPTPATH );
			System.out.println(LOGMODULE + "Script HERE:"+script);
			ResourceManagerLogger.appLog.info(MODULE + "Script HERE:"+script);
		}else{ 
			script.append("sh " + PropertyReader.LOGOUTSCRIPTPATH );
			//bwParamObj = BandwidthScriptParameters.getBWParam(new Integer(userId));
			bwParamObj = BandwidthScriptParameters.getBWParam(sessionId);
		}
		
		if (islive){
			action = "accept" ;
		}else{ 
			if (effectivesnatip != null && isSnatIpaddressVisible ){
				action = "snat" ;				
			}else{	
				action = "masq" ;
			}	
		}	
				
		script.append(" -i "+ ipAddress);
		String ipSetName=internalNetworkDAO.getIPSETName(ipAddress);
		// IF ZERO CONFIGURATION IS ON SET ITS PARAMETER TO BWSCRIPT
		boolean isNewKernel = PropertyReader.ISNEWKERNEL;
		if ((isZeroConfigurationVisible && (ipSetName == null || "".equals(ipSetName)))){
			bwScript.append(" -Z "+  1);
			ipSetName = "NONE";
		}else if(isNewKernel){
			bwScript.append(" -Z "+  1);	
		}
		script.append(" -S "+ipSetName);
		//script.append(" -g "+ gwChain) ;
		script.append(" -m "+ 10 );
		if ( poolChain != null){
			script.append(" -P "+ poolChain);
		}
		script.append(" -a "+ action );
		
		//Adding Gateway Id
		script.append(" -G "+gwId);
		//if isNetworkId is true then send NetworkID/Mask parameter to script
		
		//ankita start Ticket1104551 atmosphere
		//Adding Gateway ipaddress
		if(gwip!=null && ModuleController.isModuleVisible("gatewayipfrompackage")) {
			script.append(" -T "+gwip);
		}
		//end
		
		if(isNetworkId==true){
			String strNetwork=ipAddress+"/";
			try{
				INetworkDAO networkDAO=factory.getNetworkDao();
				nwBean=(Tblnetwork) networkDAO.getRecordByPrimaryKey(ipAddress);
				if(nwBean!=null){
					if(isNewKernel){
						strNetwork=strNetwork+nwBean.getCidr(); // Changes By Dashang
					}else{					
						strNetwork=strNetwork+nwBean.getNetmask();
					}
					ResourceManagerLogger.appLog.debug(MODULE+"NetworkID="+strNetwork);
					script.append(" -N "+ strNetwork);
				}else{
					ResourceManagerLogger.appLog.debug(MODULE+"isNetworkId=true but NetworkID="+ipAddress+" not found in tblnetwork");
				}
			}catch(Exception e){
				ResourceManagerLogger.errorLog.error(MODULE+"Exception in setting N/W ID:"+e,e);
			}
		}
		
		if (effectivesnatip != null && isSnatIpaddressVisible && !islive ){ 
			if(mapWithLive){
				/**
				 * This parameter will be used to DNAT for such ip
				 */
				script.append(" -L 1" );
			}
			script.append(" -s "+ effectivesnatip );
		}
		
		if(policyID != 0){
			script.append(" -o "+ policyID );
		}
		
		/**
		 * Userid required for Traffic discovery
		 * Added by rakesh
		 */
		if(! PropertyReader.IS24ONLINE){
			//script.append(" -j " + userId);
		}

		/** 
		 * Added bu nishit for client type specific task
		 */
		script.append(" -C " + clientType);		
		
		if(PropertyReader.IS24ONLINE){
			if(((clientType == NasPortTypes.LEASEDLINE || isIpsetIPMACBindingVisible ))&&(clientType!=NasPortTypes.PPPOE)){
				//if(macAddress != null){
					//if((macAddress.trim().length())>1){
// changes done by vijay for auto mac of Leased line users
				
				//if(macAddress != null){
					//if((macAddress.trim().length())>1){
				String fileName = LogonServerProperties.getParameter("LeasedUsersListFileName","/usr/local/nascomponents/leasedline/leasedlineusers");
				   ReadLeasedLineUsers rllu = new ReadLeasedLineUsers(fileName);
				   Hashtable usersTable = rllu.getLeasedUsersTable();
				   LeasedLineUser llu = (LeasedLineUser) usersTable.get(userName);
			    if(macAddress != null){
					
			    	if((macAddress.trim().length())>1){
						script.append(" -q 1");
						script.append(" -Q " + macAddress);
					}
					
				}else{
				  /* String fileName = LogonServerProperties.getParameter("LeasedUsersListFileName","/usr/local/nascomponents/leasedline/leasedlineusers");
				   ReadLeasedLineUsers rllu = new ReadLeasedLineUsers(fileName);
				   Hashtable usersTable = rllu.getLeasedUsersTable();
				   LeasedLineUser llu = (LeasedLineUser) usersTable.get(userName);*/
					if(llu != null){
						if(llu.getBindToMac().equalsIgnoreCase("Y")){
							script.append(" -q 1");
							if(macAddress != null && (macAddress.trim().length())>1){
								script.append(" -Q " + macAddress);
							}
						}	
					}
				}		
					
			    /***
			     * 
			     * 10.104.1.7  -i 10.104.1.7 -I NONE
			     * 10.104.1.8-10.104.1.10   -i 10.104.1.8 -I 10.104.1.10  
			     * 10.104.1.8-10.104.2.10   -i 10.104.1.8 -I 10.104.2.10
			     */
			    	//Changes by Priyadarshini For leasedline user with ip range.
			    if(llu != null){
			    	ResourceManagerLogger.appLog.debug(MODULE + "From IP Address is " +llu.getIPAddress() + "To IP Address is "+llu.getToIpAddress());
					if(llu.getToIpAddress() != null && llu.getToIpAddress().trim().length() >0){
						toIPAddress=llu.getToIpAddress();
					}
			    } else {
			    	ResourceManagerLogger.appLog.debug(MODULE + "llu is null. Client Type : "+clientType);
			    }
					
			}
			script.append(" -I "+ toIPAddress);
		}
		//script.append(" -S "+ userBean.getUserName() );
		
		if(bwParamObj != null){
			ResourceManagerLogger.appLog.debug(MODULE+"bwParamObj="+bwParamObj.toString());
			if (bwParamObj.getRestrictionType() != 0){
				bwScript.append(" -t "+  bwParamObj.getRestrictionType());
			}
			if (bwParamObj.getTotalClassId() != null){
				bwScript.append(" -c "+  bwParamObj.getTotalClassId());
			}	
			if (bwParamObj.getTotalBandwidth() != 0){
				bwScript.append(" -v "+  bwParamObj.getTotalBandwidth());
			}
			
			/**
			 * adding the guaranteed values
			 */
			if(bwParamObj.getCommittedrate() != 0){
				bwScript.append(" -g "+bwParamObj.getCommittedrate());
			}
			
			if (bwParamObj.getRateValue() != 0){
				bwScript.append(" -A "+  bwParamObj.getRateValue());
			}
			
			if (bwParamObj.getdownClassId() != null){
				bwScript.append(" -d "+  bwParamObj.getdownClassId());
			}
			if (bwParamObj.getupClassId() != null){
				bwScript.append(" -u "+  bwParamObj.getupClassId());
			}
			
			if (bwParamObj.getDownBandwidth() != 0){
				bwScript.append(" -D "+  bwParamObj.getDownBandwidth() );
			}
			/**
			 * adding guaranteed download value
			 */
			if(bwParamObj.getCommittedDownload()!=0){
				bwScript.append(" -n "+bwParamObj.getCommittedDownload());
			}
			
			
			if (bwParamObj.getUpBandwidth() != 0){
				bwScript.append(" -U "+  bwParamObj.getUpBandwidth());
			}			
			/**
			 * adding guaranteed upload value
			 */
			if(bwParamObj.getCommittedUpload()!=0){
				bwScript.append(" -m "+bwParamObj.getCommittedUpload() );
			}
			
			
			
			if (bwParamObj.getTotalFilterId() != 0){
				bwScript.append(" -h "+  bwParamObj.getTotalFilterId());
			}
			if (bwParamObj.getUpFilterId() != 0){
				bwScript.append(" -f "+  bwParamObj.getUpFilterId());
			}
			if (bwParamObj.getDownFilterId() != 0){
				bwScript.append(" -F "+  bwParamObj.getDownFilterId());
			}
			if (bwParamObj.getParentClassId() != null){
				bwScript.append(" -p "+  bwParamObj.getParentClassId());
			}
			if (bwParamObj.getUpParentClassId() != null){
				bwScript.append(" -b "+  bwParamObj.getUpParentClassId());
			}
			if (bwParamObj.getDownParentClassId() != null){
				bwScript.append(" -e "+  bwParamObj.getDownParentClassId());
			}
			if (bwParamObj.getParentBandwidth() != 0){
				bwScript.append(" -l "+  bwParamObj.getParentBandwidth());
			}
			int p= bwParamObj.getPriority();
			
			script.append(" -W "+ bwParamObj.getPriority());
			ResourceManagerLogger.appLog.info(MODULE+"PRIORITY : "+p );

		
			ResourceManagerLogger.appLog.info(MODULE+"bwScript="+bwScript);
			script.append(bwScript.toString());
		}else{
			ResourceManagerLogger.appLog.info(MODULE + "Paramobject is null");
		}
		
		/*
		 * Adding Caching Params
		 */
		try {
			if(isCacheQOSVisible) {
				JSONArray cacheQos = null;
				if(qos != null) {
					Map qosMap = JSONObject.fromObject(qos);
					cacheQos = (JSONArray) qosMap.get(QosConstants.CACHE_QOS);
					ResourceManagerLogger.appLog.info(MODULE + "Cache-Qos: "+cacheQos);
				}	
				int gCacheDownload = 0;
				int bCacheDownload = 0;
				int gCacheUpload = 0;
				int bCacheUpload = 0;
				int isCacheQoSUser=0;
				int priority=0;
				// Set Individual or Total caching b/w
				if(cacheQos != null) {
					
						gCacheDownload = cacheQos.getInt(QosConstants.GUARANTEED_DOWNLOAD);
						bCacheDownload = cacheQos.getInt(QosConstants.BURSTABLE_DOWNLOAD);
						gCacheUpload = cacheQos.getInt(QosConstants.GUARANTEED_UPLOAD);
						bCacheUpload = cacheQos.getInt(QosConstants.BURSTABLE_UPLOAD);
						try{
							priority = cacheQos.getInt(QosConstants.PRIORITY);
						}catch(Exception e){
							priority = 0;
							ResourceManagerLogger.appLog.info(MODULE + "Cache-Qos not getting priority from JSON string");
						}
						isCacheQoSUser=1;
					
				} else {
					ResourceManagerLogger.appLog.info(MODULE + "Cache-Qos is null so setting normal bandwidth for caching");
					gCacheDownload = bwParamObj.getCommittedDownload();;
					bCacheDownload = bwParamObj.getDownBandwidth();;
					gCacheUpload = bwParamObj.getCommittedUpload();;
					bCacheUpload = bwParamObj.getUpBandwidth();;
					priority = bwParamObj.getPriority();;
					// In case of total all values are zero so setting total b/w
					if(gCacheDownload == 0)
						gCacheDownload = bwParamObj.getCommittedrate();
					if(bCacheDownload == 0)
						bCacheDownload = bwParamObj.getTotalBandwidth();
					if(gCacheUpload == 0)
						gCacheUpload = bwParamObj.getCommittedrate();
					if(bCacheUpload == 0)
						bCacheUpload = bwParamObj.getTotalBandwidth();
				}
				script.append(" -j "+  gCacheDownload);
				script.append(" -J "+  bCacheDownload);
				script.append(" -k "+  gCacheUpload);
				script.append(" -K "+  bCacheUpload);
				script.append(" -B "+  isCacheQoSUser);
				ResourceManagerLogger.appLog.debug(MODULE + "Adding priority "+priority);
				script.append(" -w "+  priority);
			}
		} catch (Exception e) {
			ResourceManagerLogger.errorLog.error(MODULE + "Exception while setting Cache-QOS params: "+e, e);
		}

		
		/**
		 * LOGINONCE Customization check to send userid for login/logout script
		 */
		
		ResourceManagerLogger.appLog.debug(MODULE + "Login Once:" + isLoginOnce);
		if(isLoginOnce ){
			String strTemp = " -M " + userId;
			script.append (strTemp);
			
			int vlanid = VlanUtilities.getVlanIdByIpAddress(ipAddress);
			if(vlanid != E24onlineConstants.NOVLAN){
				String strVlanId = " -V " + vlanid;
				script.append(strVlanId);
			}
		}
		
		try{
			if(isNewKernel){
				ResourceManagerLogger.appLog.info(MODULE + " X CONDITION APPLY" );
				script.append(" -X "+  userId);
				//script.append(" -X "+  sessionId);
			}
			if(resObj.getUrlFilterPolicy() != null){
				script.append(" -r "+  resObj.getUrlFilterPolicy());
			}
			ResourceManagerLogger.appLog.info(MODULE + "Login script is: " + script.toString());

			long start = System.currentTimeMillis();
			

			//Command cmd = new Command(script.toString(),true);
			Command cmd = new Command(script.toString(),false);
			ResourceManagerLogger.appLog.info(MODULE + "FirewallCommandQueueManager put called");
			FirewallCommandQueueManager.put(cmd);
			ResourceManagerLogger.appLog.debug("Total time in FirewallCommandQueueManager script :" + (System.currentTimeMillis()-start) );
			if (!insert){
				ResourceManagerLogger.appLog.debug(MODULE+"bwPolicyId="+resorceConf.getEffectiveBandwidthPolicyID());
				resorceConf.execDeleteCommand(sessionId);
			}

		}catch(Exception e){ 
			ResourceManagerLogger.errorLog.error(MODULE + "Exception in applyFirewallChains :"+e,e);
		}	
	}
	
	
	public static int getGatewayId(int gwpriority) {
		int gwId = -1;
		try{
			IGatewayPriorityRelDAO gatewayPriorityRelDAO = factory.getGatewayPriorityRelDAO();
			gwId = gatewayPriorityRelDAO.getGatewayIdByPriorityId(gwpriority);
			ResourceManagerLogger.appLog.info(LOGMODULE+"gwId based on Priority Id : "+gwId);
		}catch(Exception e){
			ResourceManagerLogger.errorLog.error(LOGMODULE+" Exception in getGatewayId "+e,e);
		}
		return gwId;
	}

	public static String getEffectiveSnatIPAddress(String ipaddress,Tblippool ippoolBean){ 
		long start = System.currentTimeMillis();
		String snatIpAddress = null ;
		try{
			IIpPool ipPoolDao=factory.getIpPoolDAO();
			if (ippoolBean.getType() == E24onlineConstants.NM){ 
				Tblippool nmIPPoolBean = (Tblippool)ipPoolDao.getRecordByPrimaryKey(ippoolBean.getLivepoolid());
				snatIpAddress = ipPoolDao.getNextLiveIpaddress(nmIPPoolBean);
			}else if (ippoolBean.getType() == E24onlineConstants.LIVE ){ 	
				ipPoolDao.removeLiveIpaddressFromLiveList(ipaddress,ippoolBean);
			}else{
				snatIpAddress = ippoolBean.getSnatip();
			}
			/**
			* Check to see if this gateway is not redirected to another gateway. If redirection is
			* found make 'effectivesnatip' null, so instead of 'SNAT' entry we make a 'MASQ' for
			* such user.
			*/
			int size = (redirectedGWList != null) ? redirectedGWList.size() : 0;
			String gwNetwork = null ;
			String gwNetworkid = null ;
			String calculatedNetworkid = null ;
			String netmask = null ;
			for(int i=0; i<size; i++){ 
				gwNetwork = (String)redirectedGWList.get(i);
				int index = gwNetwork.indexOf("/");
				netmask = gwNetwork.substring(index+1);
				gwNetworkid = gwNetwork.substring(0,index);
				ResourceManagerLogger.appLog.debug(LOGMODULE +"Networkid:netmask of redirected GW : "+gwNetworkid+":"+netmask);
				
				if (netmask.length() < 7){ 
					netmask = IPCalculator.convertNetbitsToNetmask(Integer.parseInt(netmask));
				}
				
				calculatedNetworkid = IPCalculator.getNetwork(ipaddress,netmask);
				ResourceManagerLogger.appLog.debug(LOGMODULE +"Calculated networkid : "+calculatedNetworkid);
				if (calculatedNetworkid.equals(gwNetworkid) ){ 
					ResourceManagerLogger.appLog.debug(LOGMODULE +"IP of redirected GW found : "+ipaddress);	
					snatIpAddress = null ;
				}
			}
			ResourceManagerLogger.appLog.debug(LOGMODULE + "Final SNAT IP: "+ snatIpAddress );
			ResourceManagerLogger.errorLog.debug(LOGMODULE +"Total time in getEffectiveSnatIPAddress() : "+ (System.currentTimeMillis()-start) ); 
		}catch(Exception e){ 
			ResourceManagerLogger.errorLog.error(LOGMODULE + "Exception in getEffectiveSnatIPAddress() : "+e,e);
		}	
		return snatIpAddress ;
	}
	
	public static String getEffectiveSnatIPAddress(String ipaddress,Tblippool ippoolBean,Object unqSessionId){
		
		ResourceManagerLogger.appLog.debug(LOGMODULE + "Enter Into getEffectiveSnatIPAddress with IPAddress :"+ipaddress+" ippoolBean : "+ippoolBean+" sessionid : "+unqSessionId);
		long start = System.currentTimeMillis();
		String snatIpAddress = "" ;		
		try{
			
			IIpPool ipPoolDao=factory.getIpPoolDAO();
			
			if (ippoolBean.getType() == E24onlineConstants.NM)	{ 
				ResourceManagerLogger.appLog.debug(LOGMODULE + "getEffectiveSnatIPAddress: GetType = NM  LIVEPOOLID : "+ippoolBean.getLivepoolid()); 
				Tblippool nmIPPoolBean = (Tblippool)ipPoolDao.getRecordByPrimaryKey(ippoolBean.getLivepoolid());
				ResourceManagerLogger.appLog.debug(LOGMODULE+ "getEffectiveSnatIPAddress: NMPOOLBEAN : " + nmIPPoolBean);
				snatIpAddress = ipPoolDao.getNextLiveIpaddress(unqSessionId,nmIPPoolBean);
			}else if (ippoolBean.getType() == E24onlineConstants.LIVE ){ 
				ResourceManagerLogger.appLog.debug(LOGMODULE + "getEffectiveSnatIPAddress: GetType = live "); 
				ipPoolDao.removeLiveIpaddressFromLiveList(ipaddress,unqSessionId,ippoolBean);
			}else if(ippoolBean.getType() ==  E24onlineConstants.N1){
				snatIpAddress = ippoolBean.getSnatip() ;
				ResourceManagerLogger.appLog.debug(LOGMODULE + "getEffectiveSnatIPAddress: Pool_N1 SNAT IP: "+snatIpAddress);
			}else if(ippoolBean.getType() == E24onlineConstants.ROUNDROBIN ){
				ResourceManagerLogger.appLog.debug(LOGMODULE + "getEffectiveSnatIPAddress: GetType = RRNM  LIVEPOOLID : "+ippoolBean.getLivepoolid()); 
				Tblippool nmIPPoolBean = (Tblippool)ipPoolDao.getRecordByPrimaryKey(ippoolBean.getLivepoolid());
				ResourceManagerLogger.appLog.debug(LOGMODULE+ "getEffectiveSnatIPAddress: NMPOOLBEAN : " + nmIPPoolBean);
				snatIpAddress = ipPoolDao.getNextRRLiveIpaddress(nmIPPoolBean);
			}else{
				ResourceManagerLogger.appLog.debug(LOGMODULE + "getEffectiveSnatIPAddress: Pool is SNAT ");
			}
			/**
			* Check to see if this gateway is not redirected to another gateway. If redirection is
			* found make 'effectivesnatip' null, so instead of 'SNAT' entry we make a 'MASQ' for
			* such user.
			*/
			int size = (redirectedGWList != null) ? redirectedGWList.size() : 0;
			String gwNetwork = null ;
			String gwNetworkid = null ;
			String calculatedNetworkid = null ;
			String netmask = null ;
			for(int i=0; i<size; i++){ 
				ResourceManagerLogger.appLog.debug(LOGMODULE + "getEffectiveSnatIPAddress: Inside For Loop : ");
				gwNetwork = (String)redirectedGWList.get(i);
				int index = gwNetwork.indexOf("/");
				netmask = gwNetwork.substring(index+1);
				gwNetworkid = gwNetwork.substring(0,index);
				ResourceManagerLogger.appLog.debug(LOGMODULE + "getEffectiveSnatIPAddress: Networkid:netmask of redirected GW : "+gwNetworkid+":"+netmask);
				
				if (netmask.length() < 7){ 
					netmask = IPCalculator.convertNetbitsToNetmask(Integer.parseInt(netmask));
				}
				
				calculatedNetworkid = IPCalculator.getNetwork(ipaddress,netmask);
				ResourceManagerLogger.appLog.debug(LOGMODULE + "getEffectiveSnatIPAddress: Calculated networkid : "+calculatedNetworkid);
				if (calculatedNetworkid.equals(gwNetworkid) ){ 
					ResourceManagerLogger.appLog.debug(LOGMODULE + "getEffectiveSnatIPAddress: IP of redirected GW found : "+ipaddress);	
					snatIpAddress = "" ;
				}
			}
			ResourceManagerLogger.appLog.debug(LOGMODULE + "getEffectiveSnatIPAddress: SNAT IP: "+ snatIpAddress );
			ResourceManagerLogger.appLog.debug(LOGMODULE + "Total time in getEffectiveSnatIPAddress : "+ (System.currentTimeMillis()-start) ); 
		}catch(Exception e){ 
			ResourceManagerLogger.errorLog.error(LOGMODULE + "Exception in getEffectiveSnatIPAddress() : "+e,e);
		}	
		return snatIpAddress ;
	}	
}