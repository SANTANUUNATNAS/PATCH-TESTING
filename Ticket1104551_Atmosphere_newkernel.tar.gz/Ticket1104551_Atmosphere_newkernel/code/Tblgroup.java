package e24online.corporate.policy.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;

import e24online.corporate.utilities.E24onlineConstants;
import e24online.log.E24onlineLogger;

/**
 * @author Bhavik Ambani
 */

@Entity
public class Tblgroup implements java.io.Serializable, Cloneable {

	private static final long serialVersionUID = 1L;

	@Column(name = "groupid")
	private int groupid;

	@Column(name = "groupname")
	private String groupname;

	@Column(name = "policyid")
	private int policyid;

	@Column(name = "securitypolicyid")
	private int securitypolicyid;

	@Column(name = "accesspolicyid")
	private int accesspolicyid;

	@Column(name = "price")
	private double price;

	@Column(name = "creditlimit")
	private double creditlimit;

	@Column(name = "netsecenabled")
	private String netsecenabled = "Y";

	@Column(name = "datatransferpolicyid")
	private int datatransferpolicyid;

	@Column(name = "bwpolicyid")
	private int bwpolicyid;

	@Column(name="urlfilterpolicyid")
	private int urlfilterpolicyid;
	
	//ankita start Ticket1104551 atmosphere
	@Column(name="gatewayname")
	private String gatewayname;  
	
	@Column(name="gatewayipaddress")
    private String gatewayipaddress;
	//end
	public int getUrlfilterpolicyid() {
		return urlfilterpolicyid;
	}

	public void setUrlfilterpolicyid(int urlfilterpolicyid) {
		this.urlfilterpolicyid = urlfilterpolicyid;
	}

	@Column(name = "packagetype")
	private int packagetype;

	@Column(name = "cycletype")
	private String cycletype;

	@Column(name = "cyclemultiplier")
	private int cyclemultiplier;

	@Column(name = "billingdate")
	private int billingdate;

	@Column(name = "connectiontype")
	private int connectiontype;

	@Column(name = "defination")
	private int defination = 0;

	@Column(name = "onlinepurchase")
	private String onlinepurchase = "N";

	@Column(name = "poolid")
	private int poolid = 0;

	@Column(name = "groupstatus")
	private String groupstatus = "Y";

	@Column(name = "idletimeout")
	private int idletimeout = -11;

	@Column(name = "countamtbasedon")
	private int countamtbasedon = -11;

	@Column(name = "proportiontype")
	private String proportiontype = "D";

	@Column(name = "billcycleamtbasedon")
	private int billcycleamtbasedon = 1;

	@Column(name = "description")
	private String description;

	@Column(name = "bodaccountablevalue")
	private int bodaccountablevalue = 3;

	@Column(name = "profitvalue")
	private double profitvalue = 0;

	@Column(name = "fapid")
	private int fapid = 0;

	@Column(name = "radiuspolicyid")
	private int radiuspolicyid;

	@Column(name = "cyberoamgroupid")
	private int cyberoamgroupid = 0;

	@Column(name = "idletimeouttype")
	private int idletimeouttype = 2;

	@Column(name = "loginlimit")
	private int loginlimit = -1;
	
	@Column(name = "profileid")
	private int profileid;
	
	@Column(name = "gracedays")
	private int gracedays = -1;
	
	@Column(name = "gracedaysrel")
	private String gracedaysrel = "S";
	
	@Column(name = "selectedgracedays")
	private int selectedgracedays = -1;
	
	@Column(name = "priorityid")
	private int priorityid = -1;

	@Column(name="bindtomac")
	private String bindToMac = "N";
	
	@Column(name="expireby")
	private int expireby = E24onlineConstants.USEREXPIREBYSYSTEM;
	
	@Column(name="expiretime")
	private String expiretime ="23:59:59";
	
	private boolean bindToMacBool = false;
 	 
	private boolean isRatebasedPrepaidGroup = false;

	private int iBillCycleAmtBasedOn;
	
	private Set<Integer> poolIdSet=new HashSet<Integer>();

	private Object datatransferID;

	@Column(name="quotaamountbasedon")
	private int quotaamountbasedon = E24onlineConstants.FULLAMTBASEDONBILLCYCLE;
	
	public Tblgroup() {
	}

	public Tblgroup(int groupid, int defination) {
		this.groupid = groupid;
		this.defination = defination;
	}

	public Tblgroup(int groupid, String groupname, int policyid,
			int securitypolicyid, int accesspolicyid, double price,
			String netsecenabled, int datatransferpolicyid, int bwpolicyid,
			int packagetype, String cycletype, int cyclemultiplier,
			int billingdate, int connectiontype, int defination,
			String onlinepurchase, int poolid, String groupstatus,
			int idletimeout, int countamtbasedon, String proportiontype,
			int billcycleamtbasedon, String description,
			int bodaccountablevalue, double profitvalue, int fapid,
			int radiuspolicyid, int cyberoamgroupid, int idletimeouttype,
			int profileid, boolean isRatebasedPrepaidGroup,double creditlimit,
			int iBillCycleAmtBasedOn, int loginlimit,int gracedays,String gracedaysrel,int selectedgracedays,String bindToMac,int priorityid,int expireby,String expiretime,int urlfilterpolicyid,String gatewayname,String gatewayipaddress) {
		super();
		this.groupid = groupid;
		this.groupname = groupname;
		this.policyid = policyid;
		this.securitypolicyid = securitypolicyid;
		this.accesspolicyid = accesspolicyid;
		this.price = price;
		this.netsecenabled = netsecenabled;
		this.datatransferpolicyid = datatransferpolicyid;
		this.bwpolicyid = bwpolicyid;
		this.packagetype = packagetype;
		this.cycletype = cycletype;
		this.cyclemultiplier = cyclemultiplier;
		this.billingdate = billingdate;
		this.connectiontype = connectiontype;
		this.defination = defination;
		this.onlinepurchase = onlinepurchase;
		this.poolid = poolid;
		this.groupstatus = groupstatus;
		this.idletimeout = idletimeout;
		this.countamtbasedon = countamtbasedon;
		this.proportiontype = proportiontype;
		this.billcycleamtbasedon = billcycleamtbasedon;
		this.description = description;
		this.bodaccountablevalue = bodaccountablevalue;
		this.profitvalue = profitvalue;
		this.fapid = fapid;
		this.radiuspolicyid = radiuspolicyid;
		this.cyberoamgroupid = cyberoamgroupid;
		this.idletimeouttype = idletimeouttype;
		this.profileid = profileid;
		this.isRatebasedPrepaidGroup = isRatebasedPrepaidGroup;
		this.iBillCycleAmtBasedOn = iBillCycleAmtBasedOn;
		this.creditlimit = creditlimit;
		this.loginlimit = loginlimit;
		this.gracedays = gracedays;
		this.gracedaysrel = gracedaysrel;
		this.selectedgracedays = selectedgracedays;
		this.bindToMac = bindToMac;
		this.priorityid = priorityid;
		this.expireby=expireby;
		this.expiretime=expiretime;	
		this.urlfilterpolicyid=urlfilterpolicyid;
		this.gatewayname=gatewayname;
		this.gatewayipaddress=gatewayipaddress;
	}
	
	public int getLoginlimit() {
		return loginlimit;
	}
	
	public void setLoginlimit(int loginlimit) {
		this.loginlimit = loginlimit;
	}

	public int getAccesspolicyid() {
		return accesspolicyid;
	}

	public int getBillcycleamtbasedon() {
		return billcycleamtbasedon;
	}

	public int getBillingdate() {
		return billingdate;
	}

	public int getBodaccountablevalue() {
		return bodaccountablevalue;
	}

	public int getBwpolicyid() {
		return bwpolicyid;
	}

	public int getConnectiontype() {
		return connectiontype;
	}

	public int getCountamtbasedon() {
		return countamtbasedon;
	}

	public int getCyberoamgroupid() {
		return cyberoamgroupid;
	}

	public int getCyclemultiplier() {
		return cyclemultiplier;
	}

	public String getCycletype() {
		return cycletype;
	}

	public int getDatatransferpolicyid() {
		return datatransferpolicyid;
	}

	public int getDefination() {
		return defination;
	}

	public String getDescription() {
		return description;
	}

	public int getFapid() {
		return fapid;
	}

	public int getGroupid() {
		return groupid;
	}

	public String getGroupname() {
		return groupname;
	}

	public String getGroupstatus() {
		return groupstatus;
	}

	public int getiBillCycleAmtBasedOn() {
		return iBillCycleAmtBasedOn;
	}

	public int getIdletimeout() {
		return idletimeout;
	}

	public int getIdletimeouttype() {
		return idletimeouttype;
	}

	public String getNetsecenabled() {
		return netsecenabled;
	}

	public String getOnlinepurchase() {
		return onlinepurchase;
	}

	public int getPackagetype() {
		return packagetype;
	}

	public int getPolicyid() {
		return policyid;
	}

	public int getPoolid() {
		return poolid;
	}

	public double getPrice() {
		return price;
	}

	public int getProfileid() {
		return profileid;
	}

	public double getProfitvalue() {
		return profitvalue;
	}

	public String getProportiontype() {
		return proportiontype;
	}

	public int getRadiuspolicyid() {
		return radiuspolicyid;
	}

	public int getSecuritypolicyid() {
		return securitypolicyid;
	}

	public boolean isRatebasedPrepaidGroup() {
		return isRatebasedPrepaidGroup;
	}

	public void setAccesspolicyid(int accesspolicyid) {
		this.accesspolicyid = accesspolicyid;
	}

	public void setBillcycleamtbasedon(int billcycleamtbasedon) {
		this.billcycleamtbasedon = billcycleamtbasedon;
	}

	public void setBillingdate(int billingdate) {
		this.billingdate = billingdate;
	}

	public void setBodaccountablevalue(int bodaccountablevalue) {
		this.bodaccountablevalue = bodaccountablevalue;
	}

	public void setBwpolicyid(int bwpolicyid) {
		this.bwpolicyid = bwpolicyid;
	}

	public void setConnectiontype(int connectiontype) {
		this.connectiontype = connectiontype;
	}

	public void setCountamtbasedon(int countamtbasedon) {
		this.countamtbasedon = countamtbasedon;
	}

	public void setCyberoamgroupid(int cyberoamgroupid) {
		this.cyberoamgroupid = cyberoamgroupid;
	}

	public void setCyclemultiplier(int cyclemultiplier) {
		this.cyclemultiplier = cyclemultiplier;
	}

	public void setCycletype(String cycletype) {
		this.cycletype = cycletype;
	}

	public void setDatatransferpolicyid(int datatransferpolicyid) {
		this.datatransferpolicyid = datatransferpolicyid;
	}

	public void setDefination(int defination) {
		this.defination = defination;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setFapid(int fapid) {
		this.fapid = fapid;
	}

	public void setGroupid(int groupid) {
		this.groupid = groupid;
	}

	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}

	public void setGroupstatus(String groupstatus) {
		this.groupstatus = groupstatus;
	}

	public void setiBillCycleAmtBasedOn(int iBillCycleAmtBasedOn) {
		this.iBillCycleAmtBasedOn = iBillCycleAmtBasedOn;
	}

	public void setIdletimeout(int idletimeout) {
		this.idletimeout = idletimeout;
	}

	public void setIdletimeouttype(int idletimeouttype) {
		this.idletimeouttype = idletimeouttype;
	}

	public void setNetsecenabled(String netsecenabled) {
		this.netsecenabled = netsecenabled;
	}

	public void setOnlinepurchase(String onlinepurchase) {
		this.onlinepurchase = onlinepurchase;
	}

	public void setPackagetype(int packagetype) {
		this.packagetype = packagetype;
	}

	public void setPolicyid(int policyid) {
		this.policyid = policyid;
	}

	public void setPoolid(int poolid) {
		this.poolid = poolid;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public void setProfileid(int profileid) {
		this.profileid = profileid;
	}

	public void setProfitvalue(double profitvalue) {
		this.profitvalue = profitvalue;
	}

	public void setProportiontype(String proportiontype) {
		this.proportiontype = proportiontype;
	}

	public void setRadiuspolicyid(int radiuspolicyid) {
		this.radiuspolicyid = radiuspolicyid;
	}

	public void setRatebasedPrepaidGroup(boolean isRatebasedPrepaidGroup) {
		this.isRatebasedPrepaidGroup = isRatebasedPrepaidGroup;
	}

	public void setSecuritypolicyid(int securitypolicyid) {
		this.securitypolicyid = securitypolicyid;
	}
	
	
	/**
	 * @return the gracedays
	 */
	public int getGracedays() {
		return gracedays;
	}

	/**
	 * @param gracedays the gracedays to set
	 */
	public void setGracedays(int gracedays) {
		this.gracedays = gracedays;
	}

	
	/**
	 * @return the gracedaysrel
	 */
	public String getGracedaysrel() {
		return gracedaysrel;
	}

	/**
	 * @param gracedaysrel the gracedaysrel to set
	 */
	public void setGracedaysrel(String gracedaysrel) {
		this.gracedaysrel = gracedaysrel;
	}

	/**
	 * @return the selectedgracedays
	 */
	public int getSelectedgracedays() {
		return selectedgracedays;
	}

	/**
	 * @param selectedgracedays the selectedgracedays to set
	 */
	public void setSelectedgracedays(int selectedgracedays) {
		this.selectedgracedays = selectedgracedays;
	}
	
	/**
	 * @return the priorityid
	 */
	public int getPriorityid() {
		return priorityid;
	}

	/**
	 * @param priorityid the priorityid to set
	 */
	public void setPriorityid(int priorityid) {
		this.priorityid = priorityid;
	}

	/**
	 * @return constant for expire by like either date (=0) or datetime (=1)
	 */
	public int getExpireby() {
		return expireby;
	}

	/**
	 * @param set constant for expire by like either date (=0) or datetime (=1)
	 */
	public void setExpireby(int expireby) {
		this.expireby = expireby;
	}
	
	/**
	 * @return time provided in hh:mm:ss if expireby is 0
	 */
	public String getExpiretime() {
		return expiretime;
	}

	/**
	 * @param expiretime set time in hh:mm:ss if expire by is 0
	 */
	public void setExpiretime(String expiretime) {
		this.expiretime = expiretime;
	}
    
	public String getGatewayname() {
		return gatewayname;
	}

	public void setGatewayname(String gatewayname) {
		this.gatewayname = gatewayname;
	}

	public String getGatewayipaddress() {
		return gatewayipaddress;
	}

	public void setGatewayipaddress(String gatewayipaddress) {
		this.gatewayipaddress = gatewayipaddress;
	}

	@Override
	public String toString() {
		return "Tblgroup [accesspolicyid=" + accesspolicyid
				+ ", billcycleamtbasedon=" + billcycleamtbasedon
				+ ", billingdate=" + billingdate + ", bodaccountablevalue="
				+ bodaccountablevalue + ", bwpolicyid=" + bwpolicyid
				+ ", connectiontype=" + connectiontype + ", countamtbasedon="
				+ countamtbasedon + ", cyberoamgroupid=" + cyberoamgroupid
				+ ", cyclemultiplier=" + cyclemultiplier + ", cycletype="
				+ cycletype + ", datatransferpolicyid=" + datatransferpolicyid
				+ ", defination=" + defination + ", description=" + description
				+ ", fapid=" + fapid + ", groupid=" + groupid + ", groupname="
				+ groupname + ", groupstatus=" + groupstatus + ", creditlimit= " + this.creditlimit
				+ ", iBillCycleAmtBasedOn=" + iBillCycleAmtBasedOn
				+ ", idletimeout=" + idletimeout + ", idletimeouttype="
				+ idletimeouttype + ", isRatebasedPrepaidGroup="
				+ isRatebasedPrepaidGroup + ", netsecenabled=" + netsecenabled
				+ ", onlinepurchase=" + onlinepurchase + ", packagetype="
				+ packagetype + ", policyid=" + policyid + ", poolid=" + poolid
				+ ", price=" + price + ", profileid=" + profileid
				+ ", profitvalue=" + profitvalue + ", proportiontype="
				+ proportiontype + ", radiuspolicyid=" + radiuspolicyid
				+ ", securitypolicyid=" + securitypolicyid +", loginlimit=" + loginlimit 
				+ ", Gracedays=" +gracedays
				+", GracedaysRel=" +gracedaysrel+", SelectedGracedays= " +selectedgracedays
				+", bindToMac=" + bindToMac + ", priorityid = " +priorityid + " ,bindToMacBool=" + bindToMacBool
				+", expireby =" + expireby + ",expiretime : " + expiretime +" ,quotaamountbasedon="+quotaamountbasedon + ",urlfilterpolicyid=" + urlfilterpolicyid 
				+", gatewayname =" + gatewayname + ",gatewayipaddress : " + gatewayipaddress
				+"]";
	}
	

	/*@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + groupid;
		return result;
	}*/

	/*@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Tblgroup other = (Tblgroup) obj;
		if (groupid != other.groupid)
			return false;
		return true;
	}*/
 
	public Object clone() throws CloneNotSupportedException {
		Tblgroup groupBean = (Tblgroup) super.clone();
		groupBean.groupid = groupid;
		groupBean.netsecenabled = netsecenabled;
		groupBean.groupname = groupname;
		groupBean.profileid = profileid;
		groupBean.policyid = policyid;
		groupBean.securitypolicyid = securitypolicyid;
		groupBean.accesspolicyid = accesspolicyid;
		groupBean.radiuspolicyid = radiuspolicyid;
		groupBean.price = price;
		groupBean.datatransferID = datatransferID;
		groupBean.packagetype = packagetype;
		groupBean.cycletype = cycletype;
		groupBean.cyclemultiplier = cyclemultiplier;
		groupBean.billingdate = billingdate;
		groupBean.bwpolicyid = bwpolicyid;
		groupBean.connectiontype = connectiontype;
		groupBean.defination = defination;
		groupBean.onlinepurchase = onlinepurchase;
		groupBean.poolid = poolid;
		groupBean.groupstatus = getGroupstatus();
		groupBean.idletimeout = idletimeout;
		groupBean.countamtbasedon = countamtbasedon;
		groupBean.isRatebasedPrepaidGroup = isRatebasedPrepaidGroup;
		groupBean.iBillCycleAmtBasedOn = iBillCycleAmtBasedOn;
		groupBean.proportiontype = proportiontype;
		groupBean.description = description;
		groupBean.bodaccountablevalue = bodaccountablevalue;
		groupBean.profitvalue = profitvalue;
		groupBean.fapid = fapid;
		groupBean.idletimeouttype = idletimeouttype;
		groupBean.creditlimit = creditlimit;
		groupBean.loginlimit = loginlimit;
		groupBean.gracedays = gracedays;
		groupBean.gracedaysrel = gracedaysrel;
		groupBean.selectedgracedays = selectedgracedays;
		groupBean.bindToMac = bindToMac;
		groupBean.priorityid = priorityid;
		groupBean.expireby = expireby;
		groupBean.expiretime = expiretime;
		groupBean.quotaamountbasedon = quotaamountbasedon;
		groupBean.urlfilterpolicyid=urlfilterpolicyid;
		groupBean.gatewayname=gatewayname;
		groupBean.gatewayipaddress=gatewayipaddress;
		return groupBean;
	}

	// More required getter methods

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accesspolicyid;
		result = prime * result + billcycleamtbasedon;
		result = prime * result + billingdate;
		result = prime * result
				+ ((bindToMac == null) ? 0 : bindToMac.hashCode());
		result = prime * result + (bindToMacBool ? 1231 : 1237);
		result = prime * result + bodaccountablevalue;
		result = prime * result + bwpolicyid;
		result = prime * result + connectiontype;
		result = prime * result + countamtbasedon;
		long temp;
		temp = Double.doubleToLongBits(creditlimit);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + cyberoamgroupid;
		result = prime * result + cyclemultiplier;
		result = prime * result
				+ ((cycletype == null) ? 0 : cycletype.hashCode());
		result = prime * result
				+ ((datatransferID == null) ? 0 : datatransferID.hashCode());
		result = prime * result + datatransferpolicyid;
		result = prime * result + defination;
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		result = prime * result + expireby;
		result = prime * result
				+ ((expiretime == null) ? 0 : expiretime.hashCode());
		result = prime * result + fapid;
		result = prime * result + gracedays;
		result = prime * result
				+ ((gracedaysrel == null) ? 0 : gracedaysrel.hashCode());
		result = prime * result + groupid;
		result = prime * result
				+ ((groupname == null) ? 0 : groupname.hashCode());
		result = prime * result
				+ ((groupstatus == null) ? 0 : groupstatus.hashCode());
		result = prime * result + iBillCycleAmtBasedOn;
		result = prime * result + idletimeout;
		result = prime * result + idletimeouttype;
		result = prime * result + (isRatebasedPrepaidGroup ? 1231 : 1237);
		result = prime * result + loginlimit;
		result = prime * result
				+ ((netsecenabled == null) ? 0 : netsecenabled.hashCode());
		result = prime * result
				+ ((onlinepurchase == null) ? 0 : onlinepurchase.hashCode());
		result = prime * result + packagetype;
		result = prime * result + policyid;
		result = prime * result
				+ ((poolIdSet == null) ? 0 : poolIdSet.hashCode());
		result = prime * result + poolid;
		temp = Double.doubleToLongBits(price);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + priorityid;
		result = prime * result + profileid;
		temp = Double.doubleToLongBits(profitvalue);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result
				+ ((proportiontype == null) ? 0 : proportiontype.hashCode());
		result = prime * result + quotaamountbasedon;
		result = prime * result + radiuspolicyid;
		result = prime * result + securitypolicyid;
		result = prime * result + selectedgracedays;
		result = prime * result + urlfilterpolicyid;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Tblgroup other = (Tblgroup) obj;
		if (accesspolicyid != other.accesspolicyid)
			return false;
		if (billcycleamtbasedon != other.billcycleamtbasedon)
			return false;
		if (billingdate != other.billingdate)
			return false;
		if (bindToMac == null) {
			if (other.bindToMac != null)
				return false;
		} else if (!bindToMac.equals(other.bindToMac))
			return false;
		if (bindToMacBool != other.bindToMacBool)
			return false;
		if (bodaccountablevalue != other.bodaccountablevalue)
			return false;
		if (bwpolicyid != other.bwpolicyid)
			return false;
		if (connectiontype != other.connectiontype)
			return false;
		if (countamtbasedon != other.countamtbasedon)
			return false;
		if (Double.doubleToLongBits(creditlimit) != Double
				.doubleToLongBits(other.creditlimit))
			return false;
		if (cyberoamgroupid != other.cyberoamgroupid)
			return false;
		if (cyclemultiplier != other.cyclemultiplier)
			return false;
		if (cycletype == null) {
			if (other.cycletype != null)
				return false;
		} else if (!cycletype.equals(other.cycletype))
			return false;
		if (datatransferID == null) {
			if (other.datatransferID != null)
				return false;
		} else if (!datatransferID.equals(other.datatransferID))
			return false;
		if (datatransferpolicyid != other.datatransferpolicyid)
			return false;
		if (defination != other.defination)
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (expireby != other.expireby)
			return false;
		if (expiretime == null) {
			if (other.expiretime != null)
				return false;
		} else if (!expiretime.equals(other.expiretime))
			return false;
		if (fapid != other.fapid)
			return false;
		if (gracedays != other.gracedays)
			return false;
		if (gracedaysrel == null) {
			if (other.gracedaysrel != null)
				return false;
		} else if (!gracedaysrel.equals(other.gracedaysrel))
			return false;
		if (groupid != other.groupid)
			return false;
		if (groupname == null) {
			if (other.groupname != null)
				return false;
		} else if (!groupname.equals(other.groupname))
			return false;
		if (groupstatus == null) {
			if (other.groupstatus != null)
				return false;
		} else if (!groupstatus.equals(other.groupstatus))
			return false;
		if (iBillCycleAmtBasedOn != other.iBillCycleAmtBasedOn)
			return false;
		if (idletimeout != other.idletimeout)
			return false;
		if (idletimeouttype != other.idletimeouttype)
			return false;
		if (isRatebasedPrepaidGroup != other.isRatebasedPrepaidGroup)
			return false;
		if (loginlimit != other.loginlimit)
			return false;
		if (netsecenabled == null) {
			if (other.netsecenabled != null)
				return false;
		} else if (!netsecenabled.equals(other.netsecenabled))
			return false;
		if (onlinepurchase == null) {
			if (other.onlinepurchase != null)
				return false;
		} else if (!onlinepurchase.equals(other.onlinepurchase))
			return false;
		if (packagetype != other.packagetype)
			return false;
		if (policyid != other.policyid)
			return false;
		if (poolIdSet == null) {
			if (other.poolIdSet != null)
				return false;
		} else if (!poolIdSet.equals(other.poolIdSet))
			return false;
		if (poolid != other.poolid)
			return false;
		if (Double.doubleToLongBits(price) != Double
				.doubleToLongBits(other.price))
			return false;
		if (priorityid != other.priorityid)
			return false;
		if (profileid != other.profileid)
			return false;
		if (Double.doubleToLongBits(profitvalue) != Double
				.doubleToLongBits(other.profitvalue))
			return false;
		if (proportiontype == null) {
			if (other.proportiontype != null)
				return false;
		} else if (!proportiontype.equals(other.proportiontype))
			return false;
		if (quotaamountbasedon != other.quotaamountbasedon)
			return false;
		if (radiuspolicyid != other.radiuspolicyid)
			return false;
		if (securitypolicyid != other.securitypolicyid)
			return false;
		if (selectedgracedays != other.selectedgracedays)
			return false;
		if (urlfilterpolicyid != other.urlfilterpolicyid)
			return false;
		return true;
	}

	public String getCountAmtBasedOnStr() {
		if (countamtbasedon == E24onlineConstants.AMT_BASE_DATATRANSFER) {
			return "DataTransfer";
		} else if (countamtbasedon == E24onlineConstants.AMT_BASE_DAYS) {
			return "Days";
		} else if (countamtbasedon == E24onlineConstants.AMT_BASE_HOURS) {
			return "Time";
		} else {
			return "Not Applicable";
		}
	}

	public String getBodAccountableValueStr() {
		String strVal = "";
		if (bodaccountablevalue == E24onlineConstants.AMT_BASE_DATATRANSFER) {
			strVal = "DataTransfer";
		} else if (bodaccountablevalue == E24onlineConstants.AMT_BASE_HOURS) {
			strVal = "Time";
		}
		return strVal;
	}

	public boolean isDataTransferAllowed() {
		if (isRatebasedPrepaidGroup())
			return false;
		if (this.getDatatransferpolicyid() != E24onlineConstants.UNLIMITEDDATATRANSFERPOLICY) {
			return true;
		}
		return false;
	}

	public boolean isBalanceAllowed() {
		return isRatebasedPrepaidGroup();
	}

	public int getPrimaryKey() {
		return getGroupid();
	}

	public double getCreditlimit() {
		return creditlimit;
	}

	public void setCreditlimit(double creditlimit) {
		this.creditlimit = creditlimit;
	}

	public Set<Integer> getPoolIdSet() {
		return poolIdSet;
	}

	public void setPoolIdSet(Set<Integer> poolIdSet) {
		this.poolIdSet = poolIdSet;
	}

    public boolean getBindtomacbool(){ 
		return bindToMacBool;
	}	
	
	//Get MAC methods
    public String getBindtomac() {
		if(bindToMacBool){
			return "Y";
		}else{
			return "N";
		}
    }
    
    public void setBindtomac(String value) {
    	bindToMac = value;
    	try{
			if(("Y").equalsIgnoreCase(value)){
				bindToMacBool = true;
			}else{
				bindToMacBool = false;
			}
		}catch(Exception e){
			E24onlineLogger.errorLog.error("Error in setting bindtomac value "+e,e);
		}
    }

	public int getQuotaamountbasedon() {
		return quotaamountbasedon;
	}

	public void setQuotaamountbasedon(int quotaamountbasedon) {
		this.quotaamountbasedon = quotaamountbasedon;
	}
	
}
