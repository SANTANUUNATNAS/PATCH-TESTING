package e24online.corporate.modes;

import java.io.IOException;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.elitecore.hibernate.base.DAOFactory;
import com.elitecore.hmsintegration.utilities.HMSUtilities;
import com.elitecore.hmsintegration.utilities.HotelEntityRelationHelper;
import com.elitecore.hmsintegration.utilities.HotelUtilities;

import cyberoam.nas.common.event.CyberoamEventObject;
import cyberoam.nas.common.event.EventAttributeConstants;
import cyberoam.nas.common.event.EventIdentifierConstants;
import e24online.corporate.cas.helper.GroupCASRelDetailHelper;
import e24online.corporate.cas.helper.GroupCASRelHelper;
import e24online.corporate.customization.CustomizationConstants;
import e24online.corporate.hms.bean.RoomTypeWiseGroupBean;
import e24online.corporate.paymenttracking.helper.GraceDaysHelper;
import e24online.corporate.policy.dao.base.IGroupCOARelDAO;
import e24online.corporate.policy.dao.base.IGroupDAO;
import e24online.corporate.policy.dao.base.IGroupGatewayServiceDAO;
import e24online.corporate.policy.dao.base.IRateBasedGroupRelationDAO;
import e24online.corporate.policy.dao.ibase.IDataTransferPolicy;
import e24online.corporate.policy.dao.ibase.IGroupPolicyRelDAO;
import e24online.corporate.policy.dao.ibase.IPolicy;
import e24online.corporate.policy.dao.ibase.IRadiusPolicyDAO;
import e24online.corporate.policy.entity.Tbldatatransferpolicy;
import e24online.corporate.policy.entity.Tblgroup;
import e24online.corporate.policy.entity.Tblgroupcoarel;
import e24online.corporate.policy.entity.Tblgroupgatewayservice;
import e24online.corporate.policy.entity.Tblgrouppolicyrel;
import e24online.corporate.policy.entity.Tblpolicy;
import e24online.corporate.policy.entity.Tblradiuspolicy;
import e24online.corporate.policy.entity.Tblratebasedgrouprel;
import e24online.corporate.systemmgt.dao.ibase.IClientServices;
import e24online.corporate.systemmgt.dao.ibase.IGatewayDAO;
import e24online.corporate.systemmgt.entity.Tblclientservices;
import e24online.corporate.systemmgt.entity.Tblgateway;
import e24online.corporate.user.UserBeanUtilities;
import e24online.corporate.user.dao.ibase.IEntityPopRelDAO;
import e24online.corporate.user.dao.ibase.IEntityZoneRelDAO;
import e24online.corporate.user.dao.ibase.IIpPool;
import e24online.corporate.user.dao.ibase.IUserDAO;
import e24online.corporate.user.dao.ibase.IUserIPRelationDAO;
import e24online.corporate.user.dao.ibase.IUserNetworkRelDAO;
import e24online.corporate.user.entity.Tblentitypoprel;
import e24online.corporate.user.entity.TblentitypoprelId;
import e24online.corporate.user.pojo.Tbluser;
import e24online.corporate.user.pojo.Tblusernetworkrel;
import e24online.corporate.utilities.BandwidthConstants;
import e24online.corporate.utilities.CASConstants;
import e24online.corporate.utilities.E24onlineConstants;
import e24online.corporate.utilities.IPRestrictionConstants;
import e24online.corporate.voip.entity.TblVoIPGroupRel;
import e24online.corporate.voip.entity.TblVoipUserRel;
import e24online.corporate.voip.helper.UserVoIPPolicyHelper;
import e24online.corporate.voip.helper.VoIPGroupHelper;
import e24online.corporate.voip.utility.VoIPConstants;
import e24online.general.CustomizationController;
import e24online.general.ModuleController;
import e24online.general.dao.ibase.IGatewayServiceDAO;
import e24online.general.dao.ibase.IIPAddressDAO;
import e24online.general.dao.ibase.INetworkDAO;
import e24online.general.entity.Tblgatewayservice;
import e24online.general.entity.Tblipaddress;
import e24online.integration.entity.Tblcyberoamgroup;
import e24online.log.E24onlineLogger;
import e24online.nasutil.dao.ibase.IE24onlineNASReaderDAO;
import e24online.nasutil.entity.Tble24onlinenasreader;
import e24online.utilities.AuditObject;
import e24online.utilities.E24onlineEventHandler;
import e24online.utilities.E24onlineUtilities;

public class UpdateGroup {

	private static boolean isPOPEnabled = ModuleController.isModuleVisible(E24onlineConstants.POPMANAGEMENT);
	private static boolean isZoneEnabled = ModuleController.isModuleVisible(E24onlineConstants.ZONEMANAGEMENT);
	//public static boolean isHMSIntegrationVisible = ModuleController.isModuleVisible(E24onlineConstants.HMSINTEGRATION);
	private static boolean isHotelFlowOn = HMSUtilities.isHotelFlowOn();
	private static final boolean isMultipleServicesInvoiceVisible = ModuleController.isModuleVisible(E24onlineConstants.MULTIPLESERVICESINVOICE);
	private static final boolean isCacheQosVisible=ModuleController.isModuleVisible(E24onlineConstants.CACHEQOS);
	private static final boolean isMultipleGatewayVisible = ModuleController.isModuleVisible(E24onlineConstants.MULTIPLEGATEWAYS);
	
	private static final String MODULE = "[UpdateGroup]: ";

	private static final boolean isDataMode = VoIPConstants.ISDATAMODE ;
	private static final boolean isVoIPMode = VoIPConstants.IS_VOIP_VISIBLE ;
	private static final boolean isVoIPOnly = (isVoIPMode && (!isDataMode));
	private static final boolean isCASMode = CASConstants.IS_CAS_VISIBLE;
	private static final boolean isCASOnly = (isCASMode && (!isDataMode));
	private static final boolean isGraceDaysVisible = GraceDaysHelper.isGraceDaysVisible();
	private static final boolean isGraceDaysEnable = GraceDaysHelper.isGraceDaysEnable();
	
	private static DAOFactory factory = null;

	static {
		factory = DAOFactory.instance(DAOFactory.HIBERNATE);
	}

	public static void process(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {

		int sessionstatus = E24onlineUtilities.checkSession(req);
		if (sessionstatus == E24onlineUtilities.NOTAUTHENTICATED) {
			res.sendRedirect(req.getContextPath()+"/webpages/sessionexpired.jsp");
			return;
		} else if (sessionstatus == E24onlineUtilities.NOTREGISTERED) {
			res.sendRedirect(req.getContextPath()+"/webpages/help/onlineregistration.jsp");
			return;
		}

		String strMode = req.getParameter("mode");
		int mode = 0;

		if (strMode != null) {
			try {
				mode = Integer.parseInt(strMode);
			} catch (Exception e) {
				E24onlineLogger.errorLog.error(MODULE + " Exception while parsing mode :"+e,e);
			}
		}

		if (mode == Modes.UPDATEGROUP) {
			updateGroup(req, res);
		} else if (mode == Modes.UPDATEGROUP_DASHBOARD) {
			updateGroupFromDashboard(req, res);
		} else {
			E24onlineLogger.appLog.debug(MODULE + " Invalid Mode value :"+mode);
		}
	}

	public static void updateGroup(HttpServletRequest req,
			HttpServletResponse res) throws ServletException, IOException {
		HttpSession httpSession = req.getSession(false);
		DecimalFormat dformat = new DecimalFormat("0.00");
		String loggedInUserName = (String) httpSession.getAttribute("user");
		String[] hotelIds = null;
		int securityLevel = ((Integer)httpSession.getAttribute("securitylevel")).intValue();
		boolean isBandwidthOnDemandVisible = CustomizationController.isCustomizationVisible(CustomizationConstants.BANDWIDTHONDEMAND);
		try {
			IGroupGatewayServiceDAO groupGatewayServiceDAO = factory.getGroupGatewayServiceDAO();
			IGroupDAO groupDAO = factory.getGroupDAO();
			String isNetEnabled = null;
			String onlinePurchase = null;
			String org_onlinePurchase = null;
			String groupId = req.getParameter("groupid");
			isNetEnabled = req.getParameter("netSecEnabled");// Anil
			if (isNetEnabled == null) {
				isNetEnabled = "Y";
			}
			onlinePurchase = req.getParameter("onlinePurchase");
			if (onlinePurchase == null) {
				onlinePurchase = "N";
			}
			String pkgDescription = req.getParameter("description");
			if (pkgDescription != null) {
				pkgDescription = pkgDescription.trim();
			}
			if(HotelUtilities.IS_MANY_HOTEL){
				hotelIds = req.getParameterValues("hotelId[]");
				boolean isValidHotelEntityRelation = HotelEntityRelationHelper.isValidHotelAndEntityRelation(E24onlineConstants.PACKAGE, Integer.valueOf(groupId),req, hotelIds);
				if(isValidHotelEntityRelation) {
					
					int retStatus = HotelEntityRelationHelper.PACKAGE_ASSIGNED_TO_USER;
					httpSession.setAttribute("assignedHotelsToPackage",req.getAttribute("assignedHotelNameList"));
					req.getRequestDispatcher("/webpages/grpmgt/addupdategroup.jsp?updatestatus="+retStatus+"&groupid="+groupId).forward(req,res);
					return;
				}
			}
			
			//For Package Discount - Bhavik Ambani
			String strDiscount ;
			
			// Credit Limit of the package
			double creditLimit = 0D;
			strDiscount = req.getParameter("packagediscount");
			E24onlineLogger.appLog.debug(MODULE + " Discount = " + strDiscount  );
			
			//percentage discount change
			String strPercentageCheck = req.getParameter("percentage");
			E24onlineLogger.appLog.debug(MODULE + " Percentage isChecked =" + strPercentageCheck);
			
			String strGrandTotalAmount =req.getParameter("dgrandtotalamount");
			double dGranTotalAmount = 0;
			if(strGrandTotalAmount != null){
				E24onlineLogger.appLog.debug(MODULE + " Grand Total Amount =" + strGrandTotalAmount);
				dGranTotalAmount = Double.parseDouble(strGrandTotalAmount);
			}else{
				dGranTotalAmount=0;
			}
			E24onlineLogger.appLog.debug("Package Description In UpdateGroup:"+ pkgDescription);

			int grpId = Integer.parseInt(groupId);
			Tblgroup oldGroupBean = groupDAO.getRecordByPrimaryKey(grpId);
			Tblgroup groupBean = (Tblgroup) oldGroupBean.clone();
			E24onlineLogger.appLog.debug("GROUP clone: " + groupBean);

			if(req.getParameter("applychanges") != null  && (req.getParameter("applychanges")).trim().length() > 0){
				E24onlineLogger.appLog.debug("APPLY CHANGES");
				String newPolicyIdStr = req.getParameter("newpolicyid");
				String groupName = req.getParameter("groupname");
				if (groupName != null) {
					groupName = groupName.trim();
					groupBean.setGroupname(groupName);
				}
				E24onlineLogger.appLog.debug("Details : NEWPOLICYIDSTR "+ newPolicyIdStr);
				E24onlineLogger.appLog.debug("Details : GROUPNAME " + groupName);
				groupBean.setDescription(pkgDescription);

				int newPolicyId = Integer.parseInt(newPolicyIdStr);
				int oldPolicyId = groupBean.getPolicyid();

				String accessPolicyIdStr = req.getParameter("accesspolicyid");

				E24onlineLogger.appLog.debug(newPolicyId+":"+ oldPolicyId +":"+accessPolicyIdStr);

				if (isDataMode){
					groupBean.setPolicyid(newPolicyId);
				}else{
					groupBean.setPolicyid(oldGroupBean.getPolicyid());
				}
				E24onlineLogger.appLog.debug(MODULE + "Policy ID = " + groupBean.getPolicyid());
				groupBean.setNetsecenabled(isNetEnabled);// Anil
				org_onlinePurchase = groupBean.getOnlinepurchase();
				groupBean.setOnlinepurchase(onlinePurchase);
				IPolicy policyDao=DAOFactory.instance(DAOFactory.HIBERNATE).getPolicyDao();
				Tblpolicy policyBean = (Tblpolicy)policyDao.getRecordByPrimaryKey(newPolicyId);
				E24onlineLogger.appLog.debug("Policy bean : " + policyBean);
				E24onlineLogger.appLog.debug("cleared ... ");
				E24onlineLogger.appLog.debug("AP = " + accessPolicyIdStr);
				groupBean
						.setAccesspolicyid(Integer.parseInt(accessPolicyIdStr));

				String price = req.getParameter("price");
				String formattedPrice = dformat.format((Double.valueOf(price)).doubleValue());
				E24onlineLogger.appLog.debug("Formatted Price in create group : "+formattedPrice);
				groupBean.setPrice( (Double.valueOf(formattedPrice)).doubleValue());

				String billCycleAmtBasedOn = req.getParameter("billcycleamtbasedon");
				int iBillCycleAmtBasedOn = E24onlineConstants.FULLAMTBASEDONBILLCYCLE;

				if(billCycleAmtBasedOn != null && !("").equalsIgnoreCase(billCycleAmtBasedOn)){
					iBillCycleAmtBasedOn = Integer.parseInt(billCycleAmtBasedOn);
				}
				
				groupBean.setBillcycleamtbasedon(iBillCycleAmtBasedOn);
				
				String quotaamountbasedon = req.getParameter("quotaamountbasedon");
				int iQuotaAmountBasedOn = E24onlineConstants.FULLAMTBASEDONBILLCYCLE;

				if(quotaamountbasedon != null && !("").equalsIgnoreCase(quotaamountbasedon)){
					iQuotaAmountBasedOn = Integer.parseInt(quotaamountbasedon);
				}
				groupBean.setQuotaamountbasedon(iQuotaAmountBasedOn);
				

				String proportionType = req.getParameter("proportiontype");
				E24onlineLogger.appLog.debug("UPDATE GROUP : proportionType:"+proportionType);
				groupBean.setProportiontype(proportionType);

				// SETTING PROFIT VALUE
				String profitValue = req.getParameter("profitvalue");
				double dProfitValue = 0;
				if (profitValue != null && !"".equals(profitValue)) {
					try {
						dProfitValue = (Double.parseDouble(profitValue));
					} catch (Exception e) {
						dProfitValue = 0;
						E24onlineLogger.errorLog.error("UPDATE GROUP : Exception while parsing Profit Value : "+e,e);
					}
				}
				groupBean.setProfitvalue(dProfitValue);

				// SETTING FAPID
				String fapId = req.getParameter("fapid");
				int iFapId = 0;
				if (fapId != null && !"".equals(fapId)) {
					try {
						iFapId = (Integer.parseInt(fapId));
					} catch (Exception e) {
						iFapId = E24onlineConstants.NOFAPID;
						E24onlineLogger.errorLog.error("UPDATE GROUP : Exception while parsing FAP Id : "+e,e);
					}
				}
				groupBean.setFapid(iFapId);
				
				//setting UrlFilteringId
				String urlfilterpolicyid = req.getParameter("urlfilterpolicyid");
				int iurlfilteringpolicyid = 0;
				if(urlfilterpolicyid != null && !"".equals(urlfilterpolicyid)){
					try{
						iurlfilteringpolicyid = (Integer.parseInt(urlfilterpolicyid));
					}catch(Exception e){
						iurlfilteringpolicyid = E24onlineConstants.NOURLFILTERINGID;
						E24onlineLogger.errorLog.error("update GROUP : Exception while parsing urlfiltering Id : "+e,e);
					}
				}
		
				groupBean.setUrlfilterpolicyid(iurlfilteringpolicyid);
			
				/**** Processing for cyberoam group starts ****/

				String cyberoamGroupId = req.getParameter("cyberoamgroupid");
				int iCyberoamGroupId = Tblcyberoamgroup.DEFAULT_GROUP_ID;

				if (cyberoamGroupId != null && !"".equals(cyberoamGroupId)) {
					try {
						iCyberoamGroupId = (Integer.parseInt(cyberoamGroupId));
					} catch (Exception e) {
						iCyberoamGroupId = Tblcyberoamgroup.DEFAULT_GROUP_ID;
						E24onlineLogger.errorLog.error(MODULE+"Exception while parsing Cyberoam Group Id : "+e,e);
					}
					E24onlineLogger.appLog.debug(MODULE+"Cyberoam Group Id : "+iCyberoamGroupId);
				}
				groupBean.setCyberoamgroupid(iCyberoamGroupId);
				
				// Processing credit limit
				String creditLimitStr = req.getParameter("creditlimit");
				E24onlineLogger.appLog.debug(MODULE + "Credit Limit from request parameter #" + creditLimitStr);
				if (!E24onlineUtilities.isEmptyString(creditLimitStr)) {
					try {
						creditLimit = Double.parseDouble(creditLimitStr);
						groupBean.setCreditlimit(creditLimit);
						E24onlineLogger.appLog.debug(MODULE + "Updating credit limit to #" + groupBean.getCreditlimit());
					} catch (Exception e) {
						E24onlineLogger.errorLog.error(MODULE + "Exception while parsing credit limit parameter");
					}
				}

				/**** Processing for cyberoam group ends ****/

				int updateStatus = -1;
				if(isHotelFlowOn && ("N").equals(onlinePurchase) && ("Y").equals(org_onlinePurchase) && RoomTypeWiseGroupBean.isPackageBoundToRoomType(grpId)){
					E24onlineLogger.appLog.debug("UPDATE GROUP : Online Purchase Status of packages bound to Room Type could not be updated");
					updateStatus = E24onlineUtilities.FOREIGNKEYPRESENT;
					req.getRequestDispatcher("/webpages/grpmgt/addupdategroup.jsp?updatestatus="+updateStatus+"&groupid="+groupBean.getGroupid()).forward(req,res);
					return;
				} else {
					updateStatus = groupDAO.update(groupBean);
				}
				if (updateStatus > 0) {
					//Upadating Group Discount Value
					try{
						if (strDiscount != null && !"".equals(strDiscount) && strDiscount.trim().length() > 0 ){
							double discountValue = Double.parseDouble(strDiscount) ;
							// percentage discount change
							int updateDiscStatus = updateDiscountValue(groupBean.getGroupid(), discountValue,strPercentageCheck,dGranTotalAmount);
							if (updateDiscStatus > 0 ){
								E24onlineLogger.appLog.debug(MODULE + "Updation for The Discount Value for the package - " + groupName + " was done successfully to " + discountValue);
							}
						}
					}catch(Exception e){
						E24onlineLogger.errorLog.error(MODULE + "Exception :-  Unable to update discount value for the package - " + groupName + ". " + e , e );
					}
					//End - Upadating Group Discount Value
					
					if (VoIPConstants.IS_VOIP_VISIBLE) {
						String voipPolicyId = req.getParameter("voippolicynames");
						int intVoIPPolicyId  = VoIPConstants.NOVOIPPOLICY ;
						try{
							intVoIPPolicyId = Integer.parseInt(voipPolicyId.trim());
						}catch(NullPointerException npe){
							E24onlineLogger.errorLog.error("Exception :- Not able to get VoIP Policy Value [ Package may be Only Data Package...");
						}
						E24onlineLogger.appLog.debug(MODULE + "Updating VoIP Policy -> id = " + intVoIPPolicyId);
						TblVoIPGroupRel voipGroupEntity = new TblVoIPGroupRel();
						voipGroupEntity.setGroupid(groupBean.getGroupid());
						voipGroupEntity.setVoippolicyid(intVoIPPolicyId);
						updateVoIPPolicyGroup(voipGroupEntity,loggedInUserName,(String) httpSession.getAttribute("ipaddress"));
						// End - For VoIP Policy Updation...
					}

					//Cas Mode changes
					if(isCASMode){
//						IUserDAO userDAO = factory.getUserDAO();
//						int userbindedcount = userDAO.count("where groupid="+grpId);
//						if(userbindedcount<=0){
							updateCaswiseFields(req,groupBean);
							
							/*
							String addonid = req.getParameter("addonid[]");
							String addontype = req.getParameter("addontype[]");
							String addonprice = req.getParameter("addonprice[]");
							String addonvalidity = req.getParameter("addonvalidity[]");
							int insertstatus = CASGroupAddonsHelper.insertAddons(groupBean.getGroupid(),casgroupid, addonid,addontype,addonprice,addonvalidity);
							E24onlineLogger.appLog.debug(MODULE + "insert CAS addons : " + insertstatus);
							if (insertstatus<0) {
								if(insertstatus==CASConstants.UNSUCCESSFUL)
									updateStatus = E24onlineUtilities.ERRORINCASGROUPADD;
								else if (insertstatus==CASConstants.CURRENTCONFIGUREDGROUPADD)
									updateStatus=E24onlineUtilities.CURRENTCONFIGUREDCASGROUPADD;
								else if(insertstatus==CASConstants.PARTIALSUCCESS)
									updateStatus = E24onlineUtilities.PARTIALSUCCESSFORGROUPADDONS;
								E24onlineLogger.appLog.info("Update Status for group addons: " + updateStatus);
								req.getRequestDispatcher("/webpages/grpmgt/addupdategroup.jsp?updatestatus="+updateStatus+"&groupid="+groupBean.getGroupid()).forward(req,res);
								return;
							}
							*/
//						}else{
//							//Users are binded with current package so cas details can't be updated..
//							E24onlineLogger.appLog.debug(MODULE + "Users are binded with current package, so cant change cas details:" + userbindedcount);
//							req.getRequestDispatcher("/webpages/grpmgt/addupdategroup.jsp?updatestatus="+E24onlineUtilities.USERBINDEDWITHPACKAGE+"&groupid="+groupBean.getGroupid()).forward(req,res);
//							return;
//						}
					}
					// Update in Entity Zone Relation only when POP Mgmt.
					// customization is enabled
//					boolean isZoneManager = false;
//					if (e24online.utilities.E24onlineUtilities
//							.isZoneOrPopUserType(securityLevel)) {
//						isZoneManager = true;
//					}
					//Removing the condition of for the 'zone or pop manager' that, they can not update the entityzone relation..
					
					if (isPOPEnabled ) {
						ArrayList zoneIdListForPop = null;
						int iPopId = E24onlineConstants.NOPOPSELECTED;
						String popId = req.getParameter("popid");
						String[] zoneIdarray = req.getParameterValues("zoneid");
						String zoneId = E24onlineUtilities.toString(zoneIdarray);
						E24onlineLogger.appLog.debug(MODULE+" zoneid str:"+zoneId);
						//IEntityPopRelDAO entityPopRelDao = factory.getEntityPopRelDAO();
						String izoneid = E24onlineConstants.ALLOWEDFROMALLZONE+"";
						if(zoneId!=null && !zoneId.equals("") && !zoneId.equalsIgnoreCase("null")){
							izoneid = zoneId;
						}
						if (popId != null && !("").equals(popId)) {
							try {
								iPopId = Integer.parseInt(popId);
							} catch (Exception e) {
								E24onlineLogger.errorLog.error("Update Package, Exception while parsing Pop Id :"+e,e);
							}
						}
						
						//Changes for pop zone by mohit
						IEntityZoneRelDAO entityZoneRelDAO=factory.getEntityZoneRelDAO();
						IEntityPopRelDAO entityPopRelDAO=factory.getEntityPopRelDAO();
						if(iPopId >= 0){
							
							//sssIZoneDao zoneDao = factory.getZoneDao();
							//zoneIdListForPop = zoneDao.getZoneIdListByPOPId(iPopId);
							Set<Integer> entityZoneIdList  = entityZoneRelDAO.getZoneIdListByEnityId(E24onlineConstants.PACKAGE,groupBean.getGroupid());
							
							TblentitypoprelId entityPopRelId=new TblentitypoprelId();
							entityPopRelId.setEntityid(groupBean.getGroupid());
							entityPopRelId.setEntitytype(E24onlineConstants.PACKAGE);
							Tblentitypoprel entityPopRelBean=entityPopRelDAO.getRecordByPrimaryKey(entityPopRelId);
						//	String zoneidlistforpopstr = E24onlineUtilities.toString(zoneIdListForPop.toArray());
							
							
							if(iPopId==0){
								if(entityZoneIdList!=null && !entityZoneIdList.isEmpty() && entityPopRelBean!=null &&  popId.equalsIgnoreCase(String.valueOf(entityPopRelBean.getPopid()))){
									//IF not -40 then do nothing, means some zone is assigned then do not delete... 	
								}else{
									Tblentitypoprel entityPopRel =  new Tblentitypoprel();
									entityPopRelId = new TblentitypoprelId(E24onlineConstants.PACKAGE,groupBean.getGroupid());
									entityPopRel.setId(entityPopRelId);
									int deleteValue = entityPopRelDAO.delete(entityPopRel);
									E24onlineLogger.appLog.info("EntityZoneRelation deleteValue as no pop is selected : " + deleteValue);
								}
							}else if(entityPopRelBean==null || !popId.equalsIgnoreCase(String.valueOf(entityPopRelBean.getPopid()))){
								//if((entityZoneIdList != null && entityZoneIdList.size() > 0) || entityPopRelBean!=null ){
									if(entityZoneIdList!=null && !entityZoneIdList.isEmpty()){
										izoneid = entityZoneIdList.toString();
									}
									//EntityZoneRelation.createEntityZoneRelation(E24onlineConstants.PACKAGE,groupBean.getGroupid(),zoneIdListForPop,izoneid,securityLevel);
									EntityZoneRelation.createEntityZoneRelation(E24onlineConstants.PACKAGE,groupBean.getGroupid(),iPopId,izoneid,securityLevel);
								//}
							}
							
							E24onlineLogger.appLog.info("EntityZoneRelation pass zone:"+(entityZoneIdList!=null && !entityZoneIdList.isEmpty()?entityZoneIdList.toString():"no zone")+" curnt popid:"+(entityPopRelBean!=null?entityPopRelBean.getPopid():"not found."));
							
						} else if (iPopId == E24onlineConstants.NOPOPSELECTED) {
							Tblentitypoprel entityPopRel =  new Tblentitypoprel();
							TblentitypoprelId entityPopRelId = new TblentitypoprelId(E24onlineConstants.PACKAGE,groupBean.getGroupid());
							entityPopRel.setId(entityPopRelId);
							int deleteValue = entityPopRelDAO.delete(entityPopRel);
							E24onlineLogger.appLog.info("EntityZoneRelation deleteValue as no pop is selected : " + deleteValue);
						}
						
						
						
						
					}

					E24onlineLogger.audit.info(new AuditObject(
							AuditObject.PACKAGE, groupBean.toString(),
							AuditObject.UPDATEPACKAGE, oldGroupBean.toString(),
							groupBean.toString(), loggedInUserName,
							(String) httpSession.getAttribute("ipaddress"),
							groupBean.getGroupid()));

					Tblgroupgatewayservice groupGatewayServiceBean = null;
					int serviceProportionStatus = -1;
					if(proportionType.equals(E24onlineConstants.DEFAULTSERVICEPROPORTION) && isMultipleServicesInvoiceVisible) {
						TreeMap groupGWServiceMap = groupGatewayServiceDAO.getGroupGatewayServiceBeanMapByGroupId(grpId); 
						if( groupGWServiceMap != null && !groupGWServiceMap.isEmpty() ){
							serviceProportionStatus = groupGatewayServiceDAO.deleteRecordByGroupId(grpId);
						}
					}else if(proportionType.equals(E24onlineConstants.MANUALSERVICEPROPORTION)){
						String gatewayServiceId[] = req.getParameterValues("gatewayserviceid");
						String gatewayPorportion[] = req.getParameterValues("gatewayserviceproportion");
						String gatewayDiscount[] = req.getParameterValues("gatewayservicediscount");

						int iGatewayServiceId = 0;
						double dGatewayProportion = 0;
						double dGatewayDiscount = 0;

						for (int i = 0; i < gatewayServiceId.length; i++) {

							iGatewayServiceId = 0;
							dGatewayProportion = 0;
							dGatewayDiscount = 0;

							if (gatewayServiceId[i] != null) {
								try {
									iGatewayServiceId = Integer.parseInt(gatewayServiceId[i]);
								} catch (Exception e) {
									E24onlineLogger.errorLog.error("UPDATE GROUP,Exception while parsing Gateway Service Id :"+e,e);
								}
							}
							if (gatewayPorportion[i] != null) {
								try {
									dGatewayProportion = Double.parseDouble(gatewayPorportion[i]);
								} catch (Exception e) {
									E24onlineLogger.errorLog.error("UPDATE GROUP,Exception while parsing Gateway Service Proportion :"+e,e);
								}
							}
							if(gatewayDiscount != null && gatewayDiscount[i] != null){
								try {
									dGatewayDiscount = Double.parseDouble(gatewayDiscount[i]);
								} catch (Exception e) {
									E24onlineLogger.errorLog.error("UPDATE GROUP,Exception while parsing Gateway Service Discount :"+e,e);
								}
							}
							groupGatewayServiceBean = new Tblgroupgatewayservice();

							groupGatewayServiceBean.setGroupid(grpId);
							groupGatewayServiceBean.setGatewayserviceid(iGatewayServiceId);
							groupGatewayServiceBean.setProportion(dGatewayProportion);
							groupGatewayServiceBean.setDiscount(dGatewayDiscount);
							Tblgroupgatewayservice groupGWServiceBean = groupGatewayServiceDAO.getGroupGatewayServiceBean(grpId,iGatewayServiceId);

							if (groupGWServiceBean != null) {
								serviceProportionStatus = groupGatewayServiceDAO.update(groupGatewayServiceBean);
							} else {
								serviceProportionStatus = groupGatewayServiceDAO.insert(groupGatewayServiceBean);
							}
						}
						E24onlineLogger.appLog.debug("UPDATE GROUP : serviceProportionStatus:" + serviceProportionStatus);
					}

					E24onlineLogger.appLog.debug("UPDATE GROUP : Ratebased prepaid group flag:" + groupBean.isRatebasedPrepaidGroup());

					if (groupBean.isRatebasedPrepaidGroup()) {
						IRateBasedGroupRelationDAO rateBasedGroupRelationDAO = factory.getRateBasedGroupRelationDAO();
						Tblratebasedgrouprel ratebasedGroupRelBean = rateBasedGroupRelationDAO.getRecordByPrimaryKey(groupBean.getGroupid());
						if (ratebasedGroupRelBean != null) {
							int cycleDays = ratebasedGroupRelBean.getCycledays();
							double cyclePrice = ratebasedGroupRelBean.getCycleprice();
							String bbca = ratebasedGroupRelBean.getBalancebelowcutoffallowed();
							try {
								cycleDays = Integer.parseInt(req.getParameter("cycledays").trim());
							} catch (Exception e) {
								E24onlineLogger.errorLog.error("UpdateGroup: Exception in Parsing CycleDays :" + e);
							}
							try {
								cyclePrice = Integer.parseInt(req.getParameter("cycleprice").trim());
							} catch (Exception e) {
								E24onlineLogger.errorLog.error("UpdateGroup: Exception in Parsing Cycle Price :" + e);
							}
							try {
								bbca = req.getParameter("underbalaceallowed").trim();
							} catch (Exception e) {
								E24onlineLogger.errorLog.error("UpdateGroup: Exception in Parsing UnderBalanceAllowed:" + e);
							}
							E24onlineLogger.appLog.debug("Update Group=> Cycle Price:" + cyclePrice + ", Cycle Days:" + cycleDays + ", UnderBalance:" + bbca);
							if (!ratebasedGroupRelBean.getBalancebelowcutoffallowed().equalsIgnoreCase(bbca) ||
								ratebasedGroupRelBean.getCycledays()!=cycleDays ||
								ratebasedGroupRelBean.getCycleprice()!=cyclePrice) {
								ratebasedGroupRelBean.setBalancebelowcutoffallowed(bbca);
								ratebasedGroupRelBean.setCycledays(cycleDays);
								ratebasedGroupRelBean.setCycleprice(cyclePrice);
								int rateGroupUpdateStatus = rateBasedGroupRelationDAO.update(ratebasedGroupRelBean);
								E24onlineLogger.appLog.debug("Update Group: rate group bean update status: " + rateGroupUpdateStatus + " for group id:" + ratebasedGroupRelBean.getGroupid());
							} else {
								E24onlineLogger.appLog.debug("Update Group: No need to update ratebased group:"+ ratebasedGroupRelBean.getGroupid());
							}
						} else {
							E24onlineLogger.appLog.debug("Update group: Ratebased rel bean not found for group id: " + groupBean.getGroupid());
						}
					}
				} else if (updateStatus == E24onlineUtilities.ALREADYEXISTS) {
					groupBean.setGroupname(oldGroupBean.getGroupname());
				}
				E24onlineLogger.appLog.info("Update Status: " + updateStatus);
				req.setAttribute("updatestatus",Integer.toString(updateStatus));
				req.setAttribute("groupname", groupBean.getGroupname());
			}else if (req.getParameter("save") != null  && (req.getParameter("save")).trim().length() > 0) {
				E24onlineLogger.appLog.debug("APPLY CHANGES in save");
				
				String newProfileIdStr = req.getParameter("profileid");
				E24onlineLogger.appLog.debug("new profile id: "+newProfileIdStr);
				int newProfileId = 0;
				if(newProfileIdStr != null){
					try{
						newProfileId = Integer.parseInt(newProfileIdStr);
					}catch(Exception e){
						E24onlineLogger.appLog.debug("Profile Id is NULL Exception"+e);
					}
				}
				groupBean.setProfileid(newProfileId);
				
				String newPolicyIdStr = req.getParameter("newpolicyid");
				E24onlineLogger.appLog.debug("new pol id" + newPolicyIdStr);
				int newPolicyId = 0;
				if(newPolicyIdStr != null){
				try {
					newPolicyId = Integer.parseInt(newPolicyIdStr);
				} catch (Exception e) {
					newPolicyId = oldGroupBean.getPolicyid();
					E24onlineLogger.appLog.debug(MODULE + "Policy Id is NULL Exception" + e);
				}
				}

				String dtPolicyIdStr = req.getParameter("dtpolicyid");
				int dtpolicyId = 0;
				try {
					dtpolicyId = Integer.parseInt(dtPolicyIdStr);
					if (dtpolicyId == 0) {
						groupBean.setDatatransferpolicyid(E24onlineConstants.UNLIMITEDDATATRANSFERPOLICY);
					} else {
						groupBean.setDatatransferpolicyid(dtpolicyId);
					}

				} catch (Exception e) {
					dtpolicyId = oldGroupBean.getDatatransferpolicyid();
					//groupBean.setDatatransferID(E24onlineConstants.UNLIMITEDDATATRANSFERPOLICY);
				}

				//Added by bhavesh for radius policy
				String radiusPolicyIdStr = req.getParameter("radiuspolicyid");
				E24onlineLogger.appLog.debug("radiusPolicyIdStr: "+ radiusPolicyIdStr);
				int radiuspolicyId = 0;
				try{
					radiuspolicyId = Integer.parseInt(radiusPolicyIdStr);
					groupBean.setRadiuspolicyid(radiuspolicyId);
					
					IRadiusPolicyDAO radiusPolicyDAO = factory.getRadiusPolicyDAO();
					// Update descriptors of users binded with this package
					Tblradiuspolicy radiusPolicyBean = (Tblradiuspolicy) radiusPolicyDAO.getRecordByPrimaryKey(radiuspolicyId);
					E24onlineLogger.appLog.debug("radiusPolicyBean :"+ radiusPolicyBean);
					if(radiusPolicyBean != null) {
						IUserDAO userDAO=factory.getUserDAO();
						Map userBeansMap = userDAO.getUserBeanMap();
						Iterator itr = userBeansMap.keySet().iterator();
						Integer key;
						while(itr.hasNext()) {
							key = (Integer) itr.next();
							Tbluser userBean = (Tbluser) userBeansMap.get(key);
							if(userBean.getGroupid() == groupBean.getGroupid()) {
								userBean.setDescriptors(radiusPolicyBean.getDescriptors());
								userDAO.update(userBean);
							}
						}	
					}
				}catch(Exception e){
					E24onlineLogger.errorLog.error(MODULE+"Error while assigning radiuspolicy Id");
				}
				
				// Check for if Surfing policy is Limited (Walking pkg) then Datatransfer can't Cyclic
				IPolicy policyDao=DAOFactory.instance(DAOFactory.HIBERNATE).getPolicyDao();
				IDataTransferPolicy dataTransferPolicyDao=factory.getDataTransferPolicyDao();
				Tbldatatransferpolicy dtPolicyBean = (Tbldatatransferpolicy)dataTransferPolicyDao.getRecordByPrimaryKey(dtpolicyId);			
				Tblpolicy policyBean = (Tblpolicy)policyDao.getRecordByPrimaryKey(newPolicyId);
				//E24onlineLogger.appLog.debug("dtPolicyBean is :" + dtPolicyBean);
			//	E24onlineLogger.appLog.debug("policyBean is :" + policyBean);
				if (dtPolicyBean != null && policyBean != null && (policyBean.getExpiredays() == E24onlineUtilities.LIMITEDTIMESURFING || policyBean.getAllottedunit() == E24onlineConstants.TIME_UNIT)&& dtPolicyBean.getDatatransfercycletype() != E24onlineConstants.NONCYCLIC){
					E24onlineLogger.appLog.info("Cyclic Datatransfer Policy Not Possible With Limited Surfing Time Policy: " + E24onlineUtilities.CYCLICDTLIMITEDSURFING);
					req.setAttribute("updatestatus",Integer.toString(E24onlineUtilities.CYCLICDTLIMITEDSURFING));
					req.setAttribute("groupname", groupBean.getGroupname());
					req.getRequestDispatcher("/webpages/grpmgt/managegroups.jsp").forward(req,res);
					return;
				}
				// End for check for Limited Surfing Time With cyclic policy

				String groupName = req.getParameter("groupname");

				if (groupName != null) {
					groupName = groupName.trim();
					groupBean.setGroupname(groupName);
				}
				groupBean.setDescription(pkgDescription);

				int oldPolicyId = groupBean.getPolicyid();

				String accessPolicyIdStr = req.getParameter("accesspolicyid");

				E24onlineLogger.appLog.debug(newPolicyId+":"+ oldPolicyId +":"+accessPolicyIdStr);
				if (groupBean.getConnectiontype() == E24onlineConstants.LEASEDLINE) {
					// groupBean.setPolicyID(1);
					groupBean.setAccesspolicyid(E24onlineUtilities.OPENPOLICY);
				} else {
					groupBean.setPolicyid(newPolicyId);
					try{
						groupBean.setAccesspolicyid(Integer.parseInt(accessPolicyIdStr));
					}catch(NullPointerException e){
						groupBean.setAccesspolicyid(oldGroupBean.getAccesspolicyid());
					}catch(NumberFormatException e){
						groupBean.setAccesspolicyid(oldGroupBean.getAccesspolicyid());
					}catch(Exception e){
						E24onlineLogger.errorLog.error("Exception :- Unable to parse AccessPolicy. " + e.getMessage() , e);
					}
				}

				// START CHECK FOR ADD VALUE BASED ON IS VALID SELECTION OR NOT
				String strAddvaluebasedon = req.getParameter("addvaluebasedon");
				int i_addvaluebasedon = E24onlineConstants.AMT_BASE_NOT_APPLICABLE;
				if (strAddvaluebasedon != null) {
					i_addvaluebasedon = Integer.parseInt(strAddvaluebasedon);
				}
				if(isCASMode){
					// do nothing
				}else{
					if (i_addvaluebasedon != E24onlineConstants.AMT_BASE_NOT_APPLICABLE) {
						if((i_addvaluebasedon == E24onlineConstants.AMT_BASE_DATATRANSFER && groupBean.isDataTransferAllowed()) || 
							(i_addvaluebasedon == E24onlineConstants.AMT_BASE_DAYS && groupDAO.isDurationAllowed(groupBean)) ||
							(i_addvaluebasedon == E24onlineConstants.AMT_BASE_HOURS && groupDAO.isHoursAllowed(groupBean))){
							E24onlineLogger.appLog.debug("Count remaining amount based on : i_addvaluebasedon :"+i_addvaluebasedon);
						} else {
							E24onlineLogger.appLog.info("Wrong Selection for Count Remaining Amt Based on: " + E24onlineUtilities.ERRORCOUNTREMAMTBASEDON);
							// req.setAttribute("updatestatus",Integer.toString(E24onlineUtilities.ERRORCOUNTREMAMTBASEDON));
							// req.setAttribute("groupname",groupBean.getGroupName());
							// req.setAttribute("groupid",groupBean.getGroupID());
							req.getRequestDispatcher("/webpages/grpmgt/addupdategroup.jsp?updatestatus="+Integer.toString(E24onlineUtilities.ERRORCOUNTREMAMTBASEDON)+"&groupid="+groupBean.getGroupid()).forward(req,res);
							return;
						}
					}
				}
				// END CHECK FOR ADD VALUE BASED ON IS VALID SELECTION OR NOT
				groupBean.setCountamtbasedon(i_addvaluebasedon);

				// START OF SETTING BOD ACCOUNTABLE VALUE
				String bodaccountablevalue = req.getParameter("bodaccountablevalue");
				int iBodAcctValue = E24onlineConstants.AMT_BASE_HOURS;
				if(bodaccountablevalue != null && !"".equals(bodaccountablevalue)){
					iBodAcctValue = (Integer.parseInt(bodaccountablevalue));
				}
				else{
					iBodAcctValue = oldGroupBean.getBodaccountablevalue();
				}
				groupBean.setBodaccountablevalue(iBodAcctValue);
				// END OF SETTING BOD ACCOUNTABLE VALUE

				groupBean.setNetsecenabled(isNetEnabled);// Anil
				E24onlineLogger.appLog.debug("Network Security:" + isNetEnabled);
				org_onlinePurchase = groupBean.getOnlinepurchase();
				groupBean.setOnlinepurchase(onlinePurchase);
				E24onlineLogger.appLog.debug("Online Purchase:"+onlinePurchase);
				String price = req.getParameter("price");
				if ( price != null && price.trim().length() != 0 ){
				String formattedPrice = dformat.format((Double.valueOf(price))
						.doubleValue());
				E24onlineLogger.appLog.debug("formattedPrice in create group : "
						+ formattedPrice);
				groupBean.setPrice((Double.valueOf(formattedPrice))
						.doubleValue());
				}
				else{
					groupBean.setPrice(oldGroupBean.getPrice());
				}

				String bwPolicyIdStr = req.getParameter("bwpolicyid");

				int poolId = oldGroupBean.getPoolid(); 
				//if(ModuleController.isModuleVisible(E24onlineConstants.LOCATIONBASEDPACKAGE)){
					String strPoolId = req.getParameter("poolid");
	
					try {
						if (strPoolId != null && strPoolId.length() > 0) {
							poolId = Integer.parseInt(strPoolId);
						}
					} catch (Exception e) {
						poolId = oldGroupBean.getPoolid();
						//poolId = 0;
					}
				//}
				groupBean.setPoolid(poolId);

				
				// Check for if LeaseLine user and if pool is changes then all users from that package has to change their ipaddress.
				if(groupBean.getConnectiontype() == E24onlineConstants.LEASEDLINE && poolId != 0 && !checkPoolofUsersInGroup(grpId,poolId)){
					res.sendRedirect(req.getContextPath()+"/webpages/grpmgt/updateloginrestriction.jsp?groupid="+groupId+"&poolid="+poolId);
					return;
				}
				/*** Added By Nishant Mishra to Updating Multiple Login Limit at Package Level*/
				int oldloginlimit = groupBean.getLoginlimit();
				String reqLoginLimit = null;
				int multipleLoginLimit = E24onlineConstants.DEFAULTMULTIPLELOGINLIMIT;
				if(req.getParameter("multilimit") != null){
					try{
					reqLoginLimit = req.getParameter("multilimit").trim();
					multipleLoginLimit = Integer.parseInt(reqLoginLimit);
					}catch(Exception e){
						E24onlineLogger.errorLog.error("MODULE"+" Exception in getting Multiple login limit, Setting to Default");
						multipleLoginLimit = E24onlineConstants.DEFAULTMULTIPLELOGINLIMIT;
					}
				}

				String listSQLForMultiLogin = null;
				IUserDAO userDAO = factory.getUserDAO();
				boolean needToUpdateCacheForMultiLimit = false;
				boolean isInherit = false;
				
				E24onlineLogger.appLog.debug(MODULE + "Old Multi Login Limit: "+oldloginlimit);
				E24onlineLogger.appLog.debug(MODULE + "New Multi Login Limit: "+multipleLoginLimit);
				try{
					
					if(multipleLoginLimit!=E24onlineConstants.DEFAULTMULTIPLELOGINLIMIT){
						groupBean.setLoginlimit(multipleLoginLimit);
					}else{
						groupBean.setLoginlimit(multipleLoginLimit); // its setting to inherit ie. System Level
						isInherit = true;
					}
					// Group details has been updated 
					E24onlineLogger.appLog.debug(MODULE + "Login Limit updated for the Group : "+groupName+" and Set to limit = "+multipleLoginLimit);
					String changeEffectiveUsers = "false";
					if(req.getParameter("hiddenchangechk") != null){
						changeEffectiveUsers = req.getParameter("hiddenchangechk").trim();
					}
					E24onlineLogger.appLog.debug(MODULE + "Updating login limit of effective users = "+ changeEffectiveUsers);
					if(changeEffectiveUsers.equals("true")){
						try{
							String sqlQuery = null;
							if(isInherit){ // Inherited from the system level
								IE24onlineNASReaderDAO e24onlinenasreaderDAO=factory.getE24onlineNASReaderDAO();
								Tble24onlinenasreader cyberoamNASReaderBean = e24onlinenasreaderDAO.getRecordByPrimaryKey(Tble24onlinenasreader.MULTI_LOGIN_LIMIT_FOR_SUDIDM);
								if(cyberoamNASReaderBean != null){
									multipleLoginLimit = Integer.parseInt(cyberoamNASReaderBean.getValue()); // getting System wide value
								}
								sqlQuery = "update Tbluser set loginlimit="+multipleLoginLimit+", loginlimitrel='"+E24onlineConstants.SYSTEM_LOGIN_LIMIT_REL+"' where loginlimitrel='"+E24onlineConstants.GROUP_LOGIN_LIMIT_REL+"' and groupid="+grpId;
								listSQLForMultiLogin = "where loginlimitrel='"+E24onlineConstants.SYSTEM_LOGIN_LIMIT_REL+"' and groupid="+grpId;
							}else{
								sqlQuery = "update Tbluser set loginlimit="+multipleLoginLimit+", loginlimitrel='"+E24onlineConstants.GROUP_LOGIN_LIMIT_REL+"' where groupid="+grpId;
								listSQLForMultiLogin = "where groupid="+grpId;
							}
							
							int updateValue = userDAO.getRecordBySQLQuery(sqlQuery);
							E24onlineLogger.appLog.debug(MODULE+" "+updateValue+" Records has been updated. Query: " + sqlQuery);
							
							/*
							 * HIA-6606 
							 * MAC address of users should be flushed if multi-login limit decreased on system level
							 * 
							 * If Pkg oldloginlimit is -1 i.e System Lvl 
							 * So take the decision based on System Level Login Limit for whether to flush MAC Address binded with users or not.
							 * @author anand
							 */
							int tmpOldloginlimit = oldloginlimit;
							if(oldloginlimit == E24onlineConstants.DEFAULTMULTIPLELOGINLIMIT){
								IE24onlineNASReaderDAO e24onlinenasreaderDAO=factory.getE24onlineNASReaderDAO();
								Tble24onlinenasreader cyberoamNASReaderBean = e24onlinenasreaderDAO.getRecordByPrimaryKey(Tble24onlinenasreader.MULTI_LOGIN_LIMIT_FOR_SUDIDM);
								if(cyberoamNASReaderBean != null){
									tmpOldloginlimit = Integer.parseInt(cyberoamNASReaderBean.getValue()); // getting System wide value
									E24onlineLogger.appLog.debug(MODULE + "Here Oldloginlimit was -1 so get pkg login limit from system: " + tmpOldloginlimit);
								}
							}
							/*
							 * End of HIA-6606
							 */
							E24onlineLogger.appLog.debug(MODULE + "[ConsiderInheritCheck] Old Multi Login Limit: "+tmpOldloginlimit);
							E24onlineLogger.appLog.debug(MODULE + "[ConsiderInheritCheck] New Multi Login Limit: "+multipleLoginLimit);
							
							if(tmpOldloginlimit > multipleLoginLimit){
								E24onlineLogger.appLog.debug(MODULE + "Here Multilogin Limit is decreased so clear all Binded MAC of users having BindToMAC Yes");
								sqlQuery = "update Tbluser set macaddress = NULL where groupid="+ grpId + " and bindtomac = 'Y' or bindtomac = 'y'";
								E24onlineLogger.appLog.debug(MODULE+"Execute Qry: " + sqlQuery);
								updateValue = userDAO.getRecordBySQLQuery(sqlQuery);
								E24onlineLogger.appLog.debug(MODULE+" "+updateValue+" Records has been updated for MAC address null");
							}
							
							// Flag For each UserBean matching with condition changing its cache
							needToUpdateCacheForMultiLimit = true;
							
						}catch(Exception e){
							E24onlineLogger.errorLog.debug(MODULE + "Exception while changing the multisession limit of users of the group id = "+grpId+""+e);
						}
						E24onlineLogger.audit.info(new AuditObject(AuditObject.CHANGEGROUP,groupName+" ALL EFFECTIVE USERS",AuditObject.INSERT,Integer.toString(oldloginlimit),Integer.toString(multipleLoginLimit),loggedInUserName,(String)httpSession.getAttribute("ipaddress")));
					}else{
						E24onlineLogger.appLog.debug(MODULE + "No Need to Update the login limit of effective users");
					}
					E24onlineLogger.audit.info(new AuditObject(AuditObject.CHANGEGROUP,groupName+ " NOT FOR ALL EFFECTIVE USERS",AuditObject.INSERT,Integer.toString(oldloginlimit),Integer.toString(multipleLoginLimit),loggedInUserName,(String)httpSession.getAttribute("ipaddress")));
				}catch(Exception e){
					E24onlineLogger.errorLog.debug(MODULE + "Exception while setting Login Limit"+e);
					groupBean.setLoginlimit(oldGroupBean.getLoginlimit());
				}
		 		
				
				/** 
				 * HIA-6506
				 * Auto MAC Binding at package level.
				 * @author anand
				 **/
				String listSQLForBindToMAC = null;
				boolean needToUpdateCacheForBindToMAC = false;
				String isBindToMAC = "N";
				try {
					String oldBindToMAC = groupBean.getBindtomac();
					isBindToMAC = req.getParameter("isBindToMAC")!=null?req.getParameter("isBindToMAC"):"N";
					String changeBindToMACofUsers = req.getParameter("hiddenchangeBindToMACofAll")!=null?req.getParameter("hiddenchangeBindToMACofAll"):"false";
					E24onlineLogger.appLog.debug(MODULE + "Bind to MAC flag: " + isBindToMAC);
					E24onlineLogger.appLog.debug(MODULE + "Change BindToMAC of Users check: " + changeBindToMACofUsers);
					
					try {
						groupBean.setBindtomac(isBindToMAC);
					} catch (Exception e) {
						E24onlineLogger.errorLog.error(MODULE + "Exception while processing bindToMAC: " + e,e);
					}
						
					if(changeBindToMACofUsers.equalsIgnoreCase("true")){
						E24onlineLogger.appLog.debug(MODULE + "Change BindToMAC flag of all use under Group: " + groupBean.getGroupid() + " to: " + isBindToMAC);
						
						String sqlQuery = null;
						sqlQuery = "update Tbluser set bindtomac='" + isBindToMAC + "' where groupid="+grpId;
						listSQLForBindToMAC = "where groupid="+grpId;

						int updateValue = userDAO.getRecordBySQLQuery(sqlQuery);
						E24onlineLogger.appLog.debug(MODULE+ updateValue+" Records has been updated for bindToMAC flag");
						
						needToUpdateCacheForBindToMAC = true;
						E24onlineLogger.audit.info(new AuditObject(AuditObject.CHANGEGROUP,groupName+" BIND TO MAC OF ALL EFFECTIVE USERS",AuditObject.INSERT,oldBindToMAC,isBindToMAC,loggedInUserName,(String)httpSession.getAttribute("ipaddress")));
					}
					E24onlineLogger.audit.info(new AuditObject(AuditObject.CHANGEGROUP,groupName+" BIND TO MAC OF NEW USERS",AuditObject.INSERT,oldBindToMAC,isBindToMAC,loggedInUserName,(String)httpSession.getAttribute("ipaddress")));
				} catch (Exception e) {
					E24onlineLogger.errorLog.error(MODULE + "Exception while fetching BindToMAC params: " + e,e);
				}
				
				/**
				 * Code to send Cache Update for both MultiLogin Limit Change and BindToMAC change.
				 * Purpose of following block is to avoid unnecessary user cache update and subsequent queries at NAS Components.
				 * @author anand
				 */		
				E24onlineLogger.appLog.info(MODULE + "needToUpdateCacheForMultiLimit: " + needToUpdateCacheForMultiLimit);
				E24onlineLogger.appLog.info(MODULE + "needToUpdateCacheForBindToMAC: " + needToUpdateCacheForBindToMAC);
				
				List<Tbluser> userList = null;
				if(needToUpdateCacheForBindToMAC || needToUpdateCacheForMultiLimit){
					E24onlineLogger.appLog.info(MODULE + "Going to Update Cache.");
					if(needToUpdateCacheForBindToMAC){
						userList = userDAO.getListByCondition(listSQLForBindToMAC);
					} else {
						userList = userDAO.getListByCondition(listSQLForMultiLogin);
					}
					if(userList!=null){
						for(Tbluser userBean : userList){
							if(needToUpdateCacheForBindToMAC){
								userBean.setBindtomac(isBindToMAC);
							}
							if(needToUpdateCacheForMultiLimit){
								if(isInherit){//updating cache value
									userBean.setLoginlimit(multipleLoginLimit); 
									userBean.setLoginlimitrel(E24onlineConstants.SYSTEM_LOGIN_LIMIT_REL);
								}else{
									userBean.setLoginlimit(multipleLoginLimit);
								}
							}
							userDAO.update(userBean);
						}
					} else {
						E24onlineLogger.appLog.debug(MODULE + "UserList is null");
					}
					E24onlineLogger.appLog.info(MODULE + "Cache Updated Successfully.");
				}
				
				if(isGraceDaysVisible && isGraceDaysEnable){
					String reqGracedays = null;
					IClientServices clientservicesDAO = factory.getClientServicesDao();
					int gracedays = Integer.parseInt(clientservicesDAO.getValueByKey("System_Gracedays"));
					String gracedaysrel = E24onlineConstants.SYSTEM_LOGIN_LIMIT_REL;
					if(req.getParameter("pkggracedays") != null){
						try{
							reqGracedays = req.getParameter("pkggracedays").trim();
							gracedays = Integer.parseInt(reqGracedays);
							gracedaysrel = E24onlineConstants.GROUP_LOGIN_LIMIT_REL;
						}catch(Exception e){
							E24onlineLogger.errorLog.error("MODULE"+" Exception in getting Package Grace Days, So Setting it to Default");
							gracedays = E24onlineConstants.DISABLEDSYSTEMGRACEDAYS;
							gracedaysrel = E24onlineConstants.SYSTEM_LOGIN_LIMIT_REL;
						}
					}
					E24onlineLogger.appLog.debug(MODULE + " Package Grace Days : "+gracedays+ " And Grace Days Relation is " +gracedaysrel);
					groupBean.setGracedays(gracedays);
					groupBean.setGracedaysrel(gracedaysrel);
					String usergracedaysoption = req.getParameter("userradio");
					if(usergracedaysoption != null && usergracedaysoption.equalsIgnoreCase("changeusergracedays")){
						GraceDaysHelper.changeUserGracedays(groupBean.getGroupid(), gracedays, gracedaysrel);
						groupBean.setSelectedgracedays(E24onlineConstants.CHANGEGRACEDAYS);
					}else if(usergracedaysoption != null && usergracedaysoption.equalsIgnoreCase("donotchangeusergracedays")){
						GraceDaysHelper.donotchangeUserGracedays(groupBean.getGroupid());
						groupBean.setSelectedgracedays(E24onlineConstants.DONOTCHANGEGRACEDAYS);
					}else if (usergracedaysoption != null && usergracedaysoption.equalsIgnoreCase("forceusergracedays")){
						GraceDaysHelper.changeAllUserGracedays(groupBean.getGroupid(), gracedays, gracedaysrel);
						groupBean.setSelectedgracedays(E24onlineConstants.FORCECHANGEGRACEDAYS);
					}else{
						E24onlineLogger.appLog.debug(MODULE + " None of the three options for changing Payment GraceDays for Package Is Selected ");
						groupBean.setSelectedgracedays(E24onlineConstants.DISABLEDSYSTEMGRACEDAYS);
					}
				}
				 
				// This code will update value for expire by and expire time
				// -1 -> Global , 0 -> Date ,1-> DateTime
				int expireBy=E24onlineConstants.USEREXPIREBYSYSTEM;
				String expireByStr=req.getParameter("expiretype");
				
				try{
					expireBy=Integer.parseInt(expireByStr);
				}catch(Exception e){
					expireBy=E24onlineConstants.USEREXPIREBYSYSTEM;
					E24onlineLogger.errorLog.error(MODULE + "Error while parsing expire by while creating group" +e);
				}
				
				if(expireBy == E24onlineConstants.USEREXPIREBYDATE){
					String expireTimeStr="23:59:59";
					
					int allotedHour = 0;
					int allotedMin = 0;
					int allotedSec = 0;
					
					try{
						allotedHour = Integer.parseInt(req.getParameter("allotedhour"));
					}catch(Exception e){
						allotedHour = 0;
						E24onlineLogger.appLog.debug("ClientServicesServlet, Exception while parsing hours for GlobalExpireTime:"+e);
					}

					try{
						allotedMin = Integer.parseInt(req.getParameter("allotedmin"));
					}catch(Exception e){
						allotedMin = 0;
						E24onlineLogger.appLog.debug("ClientServicesServlet, Exception while parsing minutes for GlobalExpireTime:"+e);
					}

					try{
						allotedSec = Integer.parseInt(req.getParameter("allotedsec"));
					}catch(Exception e){
						allotedSec = 0;
						E24onlineLogger.appLog.debug("ClientServicesServlet, Exception while parsing seconds for GlobalExpireTime:"+e);
					}
					
					expireTimeStr = (allotedHour > 9 ? String.valueOf(allotedHour): "0" + allotedHour) + ":" +
							  (allotedMin > 9 ? String.valueOf(allotedMin): "0" + allotedMin) + ":" +
							  (allotedSec > 9 ? String.valueOf(allotedSec): "0" + allotedSec);
					
					groupBean.setExpiretime(expireTimeStr);
				}
				
				groupBean.setExpireby(expireBy);
				/***
				 * Change By Tejas Shah for adding idle time out time and idle
				 * time out value
				 */

				/*** Change By Tejas Shah for adding idle time out time and idle time out value */
				
				String strIdleTimeoutType = req.getParameter("idletimeouttype");
				String strIdleTimeoutValue = req.getParameter("idletimeout");
				String strIsdefaultIdleTimeOut = req.getParameter("chk_default");

				E24onlineLogger.appLog.debug(MODULE + "[Testing] :value of idle time out type :"+strIdleTimeoutType);
				E24onlineLogger.appLog.debug(MODULE + "[Testing] :value of idle time out :"+strIdleTimeoutValue);
				E24onlineLogger.appLog.debug(MODULE + "[Testing] :value of check box :"+strIsdefaultIdleTimeOut);

				int idleTimeoutType = E24onlineConstants.LIVE_REQUEST_BASED;
				int idleTimeoutValue = E24onlineConstants.DEFAULTIDLETIMEOUT;

				if (groupBean.getConnectiontype() == E24onlineConstants.LEASEDLINE) {
					// for lease line user
					idleTimeoutType = E24onlineConstants.NO_IDLE_TIMEOUT;
					idleTimeoutValue = E24onlineConstants.NO_IDLE_TIMEOUT_VALUE;
				} else {
					// for normal user

					try {
						idleTimeoutType = Integer.parseInt(strIdleTimeoutType);
					} catch (Exception e) {
						//E24onlineLogger.errorLog.error(MODULE+ "Exception in parsing idleTimeoutType"+ e, e);
						idleTimeoutType = oldGroupBean.getIdletimeouttype();
						idleTimeoutValue = oldGroupBean.getIdletimeout();
						//idleTimeoutType = E24onlineConstants.LIVE_REQUEST_BASED;
						//idleTimeoutValue = E24onlineConstants.DEFAULTIDLETIMEOUT;
					}

					if (strIsdefaultIdleTimeOut != null) {
						// Check box is check i.e use default value for idle time out
						
						try {
							E24onlineLogger.appLog.debug(MODULE + "[Testing] :value of check box :"+strIsdefaultIdleTimeOut);

							if(strIsdefaultIdleTimeOut.equals("on") ){ // this is for default value
								if (idleTimeoutType == E24onlineConstants.NO_IDLE_TIMEOUT) {
									// in case of selecting No Idle Timeout
									idleTimeoutValue = E24onlineConstants.NO_IDLE_TIMEOUT_VALUE;
								} else {
									// in case of  Live Request Based  & Internet Data Transfer Based  idle time out 
									idleTimeoutValue = E24onlineConstants.DEFAULTIDLETIMEOUT;
								}

							}

						} catch (Exception e) {
								E24onlineLogger.errorLog.error(MODULE + "Exception while parsing Default Idle Timeout:"+e,e);
						}
					} else {

						// in case of  Live Request Based  & Internet Data Transfer Based  idle time out with user defined values 
						try {

							if (idleTimeoutType == E24onlineConstants.NO_IDLE_TIMEOUT) {
								// in case of selecting No Idle Timeout
								idleTimeoutValue = E24onlineConstants.NO_IDLE_TIMEOUT_VALUE;
							} else {
									// in case of  Live Request Based  & Internet Data Transfer Based  idle time out 
									idleTimeoutValue = Integer.parseInt(strIdleTimeoutValue);
							}

						} catch (Exception e) {
							//idleTimeoutValue = E24onlineConstants.DEFAULTIDLETIMEOUT;
							idleTimeoutValue = oldGroupBean.getIdletimeout();
							//E24onlineLogger.errorLog.error(MODULE+ "Exception while parsing idle timeout value :"+ e, e);
						}

					}
				}
				E24onlineLogger.appLog.debug(MODULE + "idle timeout value :"+idleTimeoutValue);
				E24onlineLogger.appLog.debug(MODULE + "idle timeout Type :"+idleTimeoutType);
				groupBean.setIdletimeout(idleTimeoutValue);
				groupBean.setIdletimeouttype(idleTimeoutType);

				/*********************************************************************/

				boolean bwUpdateFailed = false;
				try {
					int bwpolicyid = 0 ;
					IGroupCOARelDAO groupCOARelDAO = factory.getGroupCOARelDAO();
					try{
						bwpolicyid = Integer.parseInt(bwPolicyIdStr);
						E24onlineLogger.appLog.debug(MODULE + "Value of BWPolicy = " + bwPolicyIdStr);
					}catch(NullPointerException npe){
						bwpolicyid = oldGroupBean.getBwpolicyid();
						E24onlineLogger.errorLog.error(MODULE + "Null Pointer Exception :- " + npe.getMessage() , npe);
					}
					if (bwpolicyid == 0) {
						groupBean.setBwpolicyid(E24onlineConstants.NOBANDWIDTHRESTRICTION);
					} else {
						if (isBandwidthOnDemandVisible) {
							Tblgroupcoarel groupBwRelBean = groupCOARelDAO.getBeanByGroupAndBWPolicyId(groupBean.getGroupid(),bwpolicyid);
							if (groupBwRelBean != null
									&& groupBwRelBean.getCoatype() == BandwidthConstants.COATYPE_CHANGE_BWPOLICY) {
								// group-bw relation exists for BOD, so can't set this bw policy
								bwUpdateFailed = true;
							} else {
								groupBean.setBwpolicyid(bwpolicyid);
							}
						} else {
							groupBean.setBwpolicyid(bwpolicyid);
						}
					}
				} catch (Exception e) {
					groupBean
							.setBwpolicyid(oldGroupBean.getBwpolicyid());
				}

				String billSchemeStr = req.getParameter("billscheme");
				E24onlineLogger.appLog.debug("Value of billschemestr : "+billSchemeStr);
				int billscheme = Integer.parseInt(billSchemeStr);

				String cycleType = null;
				String cycleMultiplier = null;
				String billDate = null;
				if (billscheme == E24onlineConstants.POSTPAIDSCHEME) {
					cycleType = req.getParameter("cycletype");
					cycleMultiplier = req.getParameter("cyclemultiplier");
					E24onlineLogger.appLog.debug("CT:CM:BD : "+cycleType+":"+cycleMultiplier+":"+billDate);
					if ("W".equals(cycleType)) {
						billDate = req.getParameter("billdatew");
					} else {
						billDate = req.getParameter("billdatem");
					}
					E24onlineLogger.appLog.debug("CT:CM:BD : "+cycleType+":"+cycleMultiplier+":"+billDate);
					groupBean.setCycletype(cycleType);
					groupBean.setCyclemultiplier(Integer.parseInt(cycleMultiplier));
					groupBean.setBillingdate(Integer.parseInt(billDate));
				} else {
					groupBean.setCycletype(null);
					groupBean.setCyclemultiplier(0);
					groupBean.setBillingdate(0);
					E24onlineLogger.appLog.debug("Bill Date: "+groupBean.getBillingdate());
				}

				String billCycleAmtBasedOn = req.getParameter("billcycleamtbasedon");
				int iBillCycleAmtBasedOn = E24onlineConstants.FULLAMTBASEDONBILLCYCLE;

				if(billCycleAmtBasedOn != null && !("").equalsIgnoreCase(billCycleAmtBasedOn)){
					iBillCycleAmtBasedOn = Integer.parseInt(billCycleAmtBasedOn);
				}
				groupBean.setBillcycleamtbasedon(iBillCycleAmtBasedOn);

				String quotaamountbasedon = req.getParameter("quotaamountbasedon");
				int iQuotaAmountBasedOn = E24onlineConstants.FULLAMTBASEDONBILLCYCLE;

				if(quotaamountbasedon != null && !("").equalsIgnoreCase(quotaamountbasedon)){
					iQuotaAmountBasedOn = Integer.parseInt(quotaamountbasedon);
				}
				groupBean.setQuotaamountbasedon(iQuotaAmountBasedOn);
				
				String proportionType = req.getParameter("proportiontype");

				groupBean.setProportiontype(proportionType);

				// SETTING PROFIT VALUE
				String profitValue = req.getParameter("profitvalue");
				double dProfitValue = 0;
				if (profitValue != null && !"".equals(profitValue)) {
					try {
						dProfitValue = (Double.parseDouble(profitValue));
					} catch (Exception e) {
						//dProfitValue = 0;
						dProfitValue = oldGroupBean.getProfitvalue();
						E24onlineLogger.errorLog.error(
								"UPDATE GROUP : Exception while parsing Profit Value : "
										+ e, e);
					}
				}
				groupBean.setProfitvalue(dProfitValue);
				
				if (isMultipleGatewayVisible){
				// SETTING PRIORITY
					int oldPriorityId = groupBean.getPriorityid();
					String priorityValue = req.getParameter("priorityid");
					int iPriorityId = 0;
					if (priorityValue != null && !"".equals(priorityValue)) {
						try {
							iPriorityId = (Integer.parseInt(priorityValue));
						} catch (Exception e) {
							iPriorityId = oldGroupBean.getPriorityid();
							E24onlineLogger.errorLog.error("UPDATE GROUP : Exception while parsing Priority Value : "	+ e, e);
						}
					}
					E24onlineLogger.appLog.debug(MODULE + "PriorityId :"+iPriorityId+ " and oldPriorityId :: "+oldPriorityId);
					groupBean.setPriorityid(iPriorityId);
					String listSQLForPrioirity = null;
					boolean needToUpdateCacheForPriority = false;
					try {
						String changePriorityofUsers = req.getParameter("hiddenprioritychk")!=null?req.getParameter("hiddenprioritychk"):"false";
						E24onlineLogger.appLog.debug(MODULE + "Change Priority of Users :: " + changePriorityofUsers);
						
						if(changePriorityofUsers.equalsIgnoreCase("true")){
							String sqlQuery = null;
							sqlQuery = "update Tbluser set priorityid=" + iPriorityId +  " where groupid="+grpId+ " and priorityrel = '"+E24onlineConstants.GROUP_LOGIN_LIMIT_REL+"' ";
							listSQLForPrioirity = "where groupid="+grpId+ " and priorityrel = '"+E24onlineConstants.GROUP_LOGIN_LIMIT_REL+"' ";

							int updateValue = userDAO.getRecordBySQLQuery(sqlQuery);
							E24onlineLogger.appLog.debug(MODULE+ updateValue+" Records has been updated for Priority Value");
							needToUpdateCacheForPriority = true;
							E24onlineLogger.audit.info(new AuditObject(AuditObject.CHANGEGROUP,groupName+" PRIORITY OF ALL EXISTING USERS",AuditObject.INSERT,String.valueOf(oldGroupBean.getPriorityid()),String.valueOf(iPriorityId),loggedInUserName,(String)httpSession.getAttribute("ipaddress")));
						}else{
							if(oldPriorityId != iPriorityId){
								String strQuery = null;
								listSQLForPrioirity = "where groupid="+grpId+ " and priorityrel = '"+E24onlineConstants.GROUP_LOGIN_LIMIT_REL+"' ";
								List<Tbluser> userList2 = userDAO.getListByCondition(listSQLForPrioirity);
								strQuery = "update Tbluser set priorityrel='" + E24onlineConstants.USER_LOGIN_LIMIT_REL +  "' where groupid="+grpId+ " and priorityrel = '"+E24onlineConstants.GROUP_LOGIN_LIMIT_REL+"' ";
								int updateValue1 = userDAO.getRecordBySQLQuery(strQuery);
								E24onlineLogger.appLog.debug(MODULE+ updateValue1+" Records has been updated for Priority Relation");
								if(updateValue1 > 0 && userList2 != null && !userList2.isEmpty()){
									E24onlineLogger.appLog.info(MODULE + "Going to Update Cache for Priority Relation");
									for(Tbluser userBean : userList2){
										userBean.setPriorityrel(E24onlineConstants.USER_LOGIN_LIMIT_REL);
										userDAO.update(userBean);
									}
									E24onlineLogger.appLog.info(MODULE + " List is not null so cache updated successfully");
								}
								E24onlineLogger.audit.info(new AuditObject(AuditObject.CHANGEGROUP,groupName+" PRIORITYRELATION OF ALL EXISTING USERS",AuditObject.INSERT,String.valueOf(oldGroupBean.getPriorityid()),String.valueOf(iPriorityId),loggedInUserName,(String)httpSession.getAttribute("ipaddress")));
							}
						}
					} catch (Exception e) {
						E24onlineLogger.errorLog.error(MODULE + "Exception while changing priority of existing users : " + e,e);
					}
					
					E24onlineLogger.appLog.info(MODULE + "needToUpdateCacheForPriority: " + needToUpdateCacheForPriority);
					
					List<Tbluser> userList1 = null;
					if(needToUpdateCacheForPriority){
						E24onlineLogger.appLog.info(MODULE + "Going to Update Cache for Priority");
						userList1 = userDAO.getListByCondition(listSQLForPrioirity);
						if(userList1!=null && !userList1.isEmpty()){
							for(Tbluser userBean : userList1){
								userBean.setPriorityid(iPriorityId);
								userDAO.update(userBean);
							}
						} else {
							E24onlineLogger.appLog.debug(MODULE + "UserList is null");
						}
						E24onlineLogger.appLog.info(MODULE + "Cache Updated Successfully.");
					}
				}

				// SETTING FAPID
				String fapId = req.getParameter("fapid");
				int iFapId = 0;
				if (fapId != null && !"".equals(fapId)) {
					try {
						iFapId = (Integer.parseInt(fapId));
					} catch (Exception e) {
						iFapId = oldGroupBean.getFapid();
						//iFapId = E24onlineConstants.NOFAPID;
						E24onlineLogger.errorLog.error(
								"UPDATE GROUP : Exception while parsing FAP Id : "
										+ e, e);
					}
				}
				groupBean.setFapid(iFapId);
				
				//setting UrlFilteringId
				String urlfilterpolicyid = req.getParameter("urlfilterpolicyid");
				E24onlineLogger.appLog.debug(MODULE+"urlfilteringpolicyid :"+urlfilterpolicyid);
				int iurlfilteringpolicyid = 0;
				if(urlfilterpolicyid != null && !"".equals(urlfilterpolicyid)){
					try{
						iurlfilteringpolicyid = (Integer.parseInt(urlfilterpolicyid));
						if(iurlfilteringpolicyid == 0){
							groupBean.setUrlfilterpolicyid(E24onlineConstants.NOURLFILTERINGID);
						}
						else{
							groupBean.setUrlfilterpolicyid(iurlfilteringpolicyid);
						}
					}catch(Exception e){
						iurlfilteringpolicyid = E24onlineConstants.NOURLFILTERINGID;
						E24onlineLogger.errorLog.error("update GROUP : Exception while parsing urlfiltering Id : "+e,e);
					}
				}
				

				/**** Processing for cyberoam group starts ****/

				String cyberoamGroupId = req.getParameter("cyberoamgroupid");
				int iCyberoamGroupId = Tblcyberoamgroup.DEFAULT_GROUP_ID;

				if (cyberoamGroupId != null && !"".equals(cyberoamGroupId)) {
					try {
						iCyberoamGroupId = (Integer.parseInt(cyberoamGroupId));
					} catch (Exception e) {
						//iCyberoamGroupId = Tblcyberoamgroup.DEFAULT_GROUP_ID;
						iCyberoamGroupId = oldGroupBean.getCyberoamgroupid();
						E24onlineLogger.errorLog.error(
								"CREATE GROUP : Exception while parsing Cyberoam Group Id : "
										+ e, e);
					}
				}
				groupBean.setCyberoamgroupid(iCyberoamGroupId);

				// Processing credit limit
				String creditLimitStr = req.getParameter("creditlimit");
				E24onlineLogger.appLog.debug(MODULE + "Credit Limit from request parameter #" + creditLimitStr);
				if (!E24onlineUtilities.isEmptyString(creditLimitStr)) {
					try {
						creditLimit = Double.parseDouble(creditLimitStr);
						groupBean.setCreditlimit(creditLimit);
						E24onlineLogger.appLog.debug(MODULE + "Updating credit limit to #" + groupBean.getCreditlimit());
					} catch (Exception e) {
						E24onlineLogger.errorLog.error(MODULE + "Exception while parsing credit limit parameter");
					}
				}

				/**** Processing for cyberoam group ends ****/

				int updateStatus = -1;
				if(isHotelFlowOn && ("N").equals(onlinePurchase) && ("Y").equals(org_onlinePurchase) && RoomTypeWiseGroupBean.isPackageBoundToRoomType(grpId)){
					E24onlineLogger.appLog.debug("UPDATE GROUP : Online Purchase Status of packages bound to Room Type could not be updated");
					updateStatus = E24onlineUtilities.FOREIGNKEYPRESENT;
					req.getRequestDispatcher("/webpages/grpmgt/addupdategroup.jsp?updatestatus="+updateStatus+"&groupid="+groupBean.getGroupid()).forward(req,res);
					return;
				} else {
					//Policy IP For the Group
					if (isDataMode){
						groupBean.setPolicyid(newPolicyId);
					}else{
						groupBean.setPolicyid(oldGroupBean.getPolicyid());
					}
					//ankita start Ticket1104551 atmosphere
					String oldgatewayipaddress = "";
					String gatewayipaddress="";
					IClientServices clientServicesDAO = factory.getClientServicesDao();
					Tblclientservices csBean1 = clientServicesDAO.getRecordByPrimaryKey("gatewayipfrompackage");
				    String csValue1 = csBean1.getServicevalue();
				    if(csValue1.equalsIgnoreCase("true")){
				    try {
					gatewayipaddress = req.getParameter("gatewayipaddress");
					E24onlineLogger.appLog.debug("new gatewayipaddress" + gatewayipaddress);
					
					if(gatewayipaddress != null){
						groupBean.setGatewayipaddress(gatewayipaddress);
					} 
					}catch (Exception e) {
						//oldgatewayipaddress = oldGroupBean.getGatewayipaddress();
						groupBean.setGatewayipaddress(oldgatewayipaddress);
						E24onlineLogger.appLog.debug(MODULE + "oldgatewayipaddress :: blank" );
					}
					String oldgatewayname = "";
					IGatewayDAO gatewaydao = factory.getGatewayDao();
					Tblgateway gatewayBean = gatewaydao.getRecordByKeyandValue("ipaddress", gatewayipaddress);
					try {
					String newgatewayname = gatewayBean.getGatewayname();
					E24onlineLogger.appLog.debug(MODULE + "new  newgatewayname :: " + newgatewayname);
					if(newgatewayname != null){
						groupBean.setGatewayname(newgatewayname);
						} 
						}catch (Exception e) {
							oldgatewayname = oldGroupBean.getGatewayname();
							groupBean.setGatewayname("");
							E24onlineLogger.appLog.debug(MODULE + "oldgatewayname :: blank" );
						}
					}
					//end
					updateStatus = groupDAO.update(groupBean);
				}
				if (updateStatus > 0) {
					//if(!ModuleController.isModuleVisible(E24onlineConstants.LOCATIONBASEDPACKAGE)){
						
						/*HttpSession session = req.getSession(false); 
						
						IPackagePoolBindingDAO packagePoolBindingDAO = factory.getPackagePoolBindingDAO();
						int deleteStatus = packagePoolBindingDAO.deleteAllPackageBindingByPackageID(groupBean.getGroupid());
						E24onlineLogger.appLog.debug(MODULE + "updateGroup() Delete All PackagePoolBinding Status : "+deleteStatus+" for GroupId:"+groupBean.getGroupid());
						
						//String[] groupIdList = req.getParameterValues("locationbasedpackage[]");
						String[] poolIdList = (String[]) session.getAttribute("poolIdList");
						E24onlineLogger.appLog.debug(MODULE+"createGroup() getAttribute : "+poolIdList.length);
						if(poolIdList != null && poolIdList.length > 0) {
							List<Integer> locationPoolList = new ArrayList<Integer>();
							for (String locationPoolid : poolIdList) {
								try {
									locationPoolList.add(Integer.parseInt(locationPoolid));
								} catch (NumberFormatException e) {
									E24onlineLogger.appLog.debug(MODULE + "createPool() PackagePoolBinding Package cannot be parsed with packageid: "+locationPoolid);
								}
							}
							updateStatus = packagePoolBindingDAO.insertPoolBindingByGroupID(locationPoolList, groupBean.getGroupid());
							E24onlineLogger.audit.info(new AuditObject(AuditObject.PACKAGEPOOLBINDING,"PackagePoolBinding",AuditObject.UPDATE,null,"{groupId:"+groupBean.getGroupid()+",PoolIdList:"+locationPoolList.toString()+"}",loggedInUserName,(String)session.getAttribute("ipaddress")));
							E24onlineLogger.appLog.debug(MODULE + "createGroup() Update status: "+updateStatus+" for groupId:"+groupBean.getGroupid()+" PoolIdList:"+locationPoolList.toString());
						}
						else {
							E24onlineLogger.appLog.debug(MODULE + "createGroup() No Pool found for binding.");
						}*/
					//}
					//Upadating Group Discount Value
					if (!isMultipleServicesInvoiceVisible){
						try{
							if (strDiscount != null && !"".equals(strDiscount) && strDiscount.trim().length() > 0 ){
								double discountValue = Double.parseDouble(strDiscount) ;
								// percentage discount change
								int updateDiscStatus = updateDiscountValue(groupBean.getGroupid(), discountValue,strPercentageCheck,dGranTotalAmount);
								if (updateDiscStatus > 0 ){
									E24onlineLogger.appLog.debug(MODULE + "Updation for The Discount Value for the package - " + groupName + " was done successfully to " + discountValue);
								}
							}
						}catch(Exception e){
							E24onlineLogger.errorLog.error(MODULE + "Exception :-  Unable to update discount value for the package - " + groupName + ". " + e , e );
						}
					}
					//End - Upadating Group Discount Value

					// For VoIP Policy Updation...
					if (VoIPConstants.IS_VOIP_VISIBLE) {
						String voipPolicyId = req.getParameter("voippolicynames");
						int intVoIPPolicyId  = VoIPConstants.NOVOIPPOLICY ;
						try{
							intVoIPPolicyId = Integer.parseInt(voipPolicyId.trim());
						}catch(NullPointerException npe){
							E24onlineLogger.errorLog.error("Exception :- Not able to get VoIP Policy Value [ Package may be Only Data Package...");
						}
						E24onlineLogger.appLog.debug(MODULE + "Updating VoIP Policy -> id = " + intVoIPPolicyId);
						TblVoIPGroupRel voipGroupEntity = new TblVoIPGroupRel();
						voipGroupEntity.setGroupid(groupBean.getGroupid());
						voipGroupEntity.setVoippolicyid(intVoIPPolicyId);
						updateVoIPPolicyGroup(voipGroupEntity,loggedInUserName,(String) httpSession.getAttribute("ipaddress"));
					}
					// End - For VoIP Policy Updation...

					//Cas Mode changes
					if(isCASMode){
//						IUserDAO userDAO = factory.getUserDAO();
//						int userbindedcount = userDAO.count("where groupid="+grpId);
//						if(userbindedcount<=0){
							updateCaswiseFields(req,groupBean);
							/*String addonid = req.getParameter("addonid[]");
							String addontype = req.getParameter("addontype[]");
							String addonprice = req.getParameter("addonprice[]");
							String addonvalidity = req.getParameter("addonvalidity[]");
							int insertstatus = CASGroupAddonsHelper.insertAddons(groupBean.getGroupid(),casgroupid, addonid,addontype,addonprice,addonvalidity);
							E24onlineLogger.appLog.debug(MODULE + "insert CAS addons : " + insertstatus);
							if (insertstatus<0) {
								if(insertstatus==CASConstants.UNSUCCESSFUL)
									updateStatus = E24onlineUtilities.ERRORINCASGROUPADD;
								else if (insertstatus==CASConstants.CURRENTCONFIGUREDGROUPADD)
									updateStatus=E24onlineUtilities.CURRENTCONFIGUREDCASGROUPADD;
								else if(insertstatus==CASConstants.PARTIALSUCCESS)
									updateStatus = E24onlineUtilities.PARTIALSUCCESSFORGROUPADDONS;
								E24onlineLogger.appLog.info("Update Status for group addons: " + updateStatus);
								req.getRequestDispatcher("/webpages/grpmgt/addupdategroup.jsp?updatestatus="+updateStatus+"&groupid="+groupBean.getGroupid()).forward(req,res);
								return;
							}
							*/
//						}else{
//							//Users are binded with current package so cas details can't be updated..
//							E24onlineLogger.appLog.debug(MODULE + "Users are binded with current package, so cant change cas details:" + userbindedcount);
//							req.getRequestDispatcher("/webpages/grpmgt/addupdategroup.jsp?updatestatus="+E24onlineUtilities.USERBINDEDWITHPACKAGE+"&groupid="+groupBean.getGroupid()).forward(req,res);
//							return;
//						}
					}
					//For Cache Policy Updation
					
					if(isCacheQosVisible){
						int iCacheId=E24onlineConstants.NO_QOS_POLICY;
						String strCacheId=req.getParameter("cachepolicyid");
						if(strCacheId!=null && !"null".equals(strCacheId) && !"".equals(strCacheId)){
							try{
								iCacheId=Integer.parseInt(strCacheId);
							}catch(Exception e){
								E24onlineLogger.errorLog.error(MODULE+"Exception While parsing cache id"+e,e);
							}
						}
						E24onlineLogger.appLog.debug(MODULE + "Updating cache policy for Id: " + iCacheId + "Group Id:" +groupBean.getGroupid());
						IGroupPolicyRelDAO iGroupPolicyRelDAO = factory.getGroupPolicyRelDAO();
						Tblgrouppolicyrel tblGroupPolicyRel = iGroupPolicyRelDAO.getRecordByPrimaryKey(groupBean.getGroupid());
						if(tblGroupPolicyRel!=null && !"null".equals(tblGroupPolicyRel) && !"".equals(tblGroupPolicyRel)){
							E24onlineLogger.appLog.debug(MODULE + "Group Policy Rel:"+tblGroupPolicyRel);
							tblGroupPolicyRel.setPolicyid(iCacheId);
							int updateCachePolicyId= iGroupPolicyRelDAO.update(tblGroupPolicyRel);
							E24onlineLogger.appLog.debug(MODULE+ "Update cache Policy: ID:"+updateCachePolicyId);
							//AuditLog
							E24onlineLogger.audit.info(new AuditObject(AuditObject.APP_QOS,groupBean.getGroupname(),AuditObject.UPDATEPACKAGE,null,tblGroupPolicyRel.toString(),loggedInUserName,(String)httpSession.getAttribute("ipaddress"),groupBean.getGroupid()));
							
						}else{
							
							if (iCacheId!=E24onlineConstants.NO_QOS_POLICY){
								tblGroupPolicyRel= new Tblgrouppolicyrel();
								tblGroupPolicyRel.setGroupid(groupBean.getGroupid());
								tblGroupPolicyRel.setPolicytype(E24onlineConstants.CACHE_QOS);
								tblGroupPolicyRel.setPolicyid(iCacheId);
								int insertCachePolicyId= iGroupPolicyRelDAO.insert(tblGroupPolicyRel);
								E24onlineLogger.appLog.debug(MODULE+ "Update cache Policy: ID:"+insertCachePolicyId);
								//AuditLog
								E24onlineLogger.audit.info(new AuditObject(AuditObject.APP_QOS,groupBean.getGroupname(),AuditObject.UPDATEPACKAGE,null,tblGroupPolicyRel.toString(),loggedInUserName,(String)httpSession.getAttribute("ipaddress"),groupBean.getGroupid()));
								
							}else{
								E24onlineLogger.appLog.debug(MODULE+ "NO cache policy Found, No insert and update in tblgrouppolicyrel");
							}
						}
						
						
						
					}
					Tblgroupgatewayservice groupGatewayServiceBean = null;
					int serviceProportionStatus = -1;
					if(proportionType.equals(E24onlineConstants.DEFAULTSERVICEPROPORTION) && isMultipleServicesInvoiceVisible) {
						TreeMap<Integer, Tblgroupgatewayservice> groupGWServiceMap = groupGatewayServiceDAO.getGroupGatewayServiceBeanMapByGroupId(grpId); 
						if( groupGWServiceMap != null && !groupGWServiceMap.isEmpty() ){
							serviceProportionStatus = groupGatewayServiceDAO.deleteRecordByGroupId(grpId);
						}
					}else if(proportionType.equals(E24onlineConstants.MANUALSERVICEPROPORTION) && isMultipleServicesInvoiceVisible) {
						String gatewayServiceId[] = req.getParameterValues("gatewayserviceid");
						String gatewayPorportion[] = req.getParameterValues("gatewayserviceproportion");
						String gatewayDiscount[] = req.getParameterValues("gatewayservicediscount");

						int iGatewayServiceId = 0;
						double dGatewayProportion = 0;
						double dGatewayDiscount = 0;

						for (int i = 0; i < gatewayServiceId.length; i++) {

							iGatewayServiceId = 0;
							dGatewayProportion = 0;
							dGatewayDiscount = 0;

							if (gatewayServiceId[i] != null) {
								try {
									iGatewayServiceId = Integer.parseInt(gatewayServiceId[i]);
								} catch (Exception e) {
									E24onlineLogger.errorLog.error("UPDATE GROUP,Exception while parsing Gateway Service Id :"+e,e);
								}
							}
							if (gatewayPorportion[i] != null) {
								try {
									dGatewayProportion = Double.parseDouble(gatewayPorportion[i]);
								} catch (Exception e) {
									E24onlineLogger.errorLog.error("UPDATE GROUP,Exception while parsing Gateway Service Proportion :"+e,e);
								}
							}
							if(gatewayDiscount != null && gatewayDiscount[i] != null){
								try {
									dGatewayDiscount = Double.parseDouble(gatewayDiscount[i]);
								} catch (Exception e) {
									E24onlineLogger.errorLog.error("UPDATE GROUP,Exception while parsing Gateway Service Discount :"+e,e);
								}
							}
							groupGatewayServiceBean = new Tblgroupgatewayservice();

							groupGatewayServiceBean.setGroupid(grpId);
							groupGatewayServiceBean.setGatewayserviceid(iGatewayServiceId);
							groupGatewayServiceBean.setProportion(dGatewayProportion);
							groupGatewayServiceBean.setDiscount(dGatewayDiscount);
							Tblgroupgatewayservice groupGWServiceBean = groupGatewayServiceDAO.getGroupGatewayServiceBean(grpId,iGatewayServiceId);

							if (groupGWServiceBean != null) {
								groupGWServiceBean.setGroupid(grpId);
								groupGWServiceBean.setGatewayserviceid(iGatewayServiceId);
								groupGWServiceBean.setProportion(dGatewayProportion);
								groupGWServiceBean.setDiscount(dGatewayDiscount);

								serviceProportionStatus = groupGatewayServiceDAO.update(groupGWServiceBean);
							} else {
								serviceProportionStatus = groupGatewayServiceDAO.insert(groupGatewayServiceBean);
							}
						}
						E24onlineLogger.appLog.debug("UPDATE GROUP : serviceProportionStatus:" + serviceProportionStatus);
					}

					E24onlineLogger.appLog.debug("UPDATE GROUP : Ratebased prepaid group flag:" + groupBean.isRatebasedPrepaidGroup());
					if (groupBean.isRatebasedPrepaidGroup()) {
						IRateBasedGroupRelationDAO rateBasedGroupRelationDAO = factory.getRateBasedGroupRelationDAO();
						Tblratebasedgrouprel ratebasedGroupRelBean = rateBasedGroupRelationDAO.getRecordByPrimaryKey(groupBean.getGroupid());
						if (ratebasedGroupRelBean != null) {
							int cycleDays = ratebasedGroupRelBean.getCycledays();
							double cyclePrice = ratebasedGroupRelBean.getCycleprice();
							String bbca = ratebasedGroupRelBean.getBalancebelowcutoffallowed();
							try {
								cycleDays = Integer.parseInt(req.getParameter("cycledays").trim());
							} catch (Exception e) {
								E24onlineLogger.errorLog.error("UpdateGroup: Exception in Parsing CycleDays :" + e);
							}
							try {
								cyclePrice = Double.parseDouble(req.getParameter("cycleprice").trim());
							} catch (Exception e) {
								E24onlineLogger.errorLog.error("UpdateGroup: Exception in Parsing Cycle Price :" + e);
							}
							try {
								bbca = req.getParameter("underbalaceallowed").trim();
							} catch (Exception e) {
								E24onlineLogger.errorLog.error("UpdateGroup: Exception in Parsing UnderBalanceAllowed:" + e);
							}
							E24onlineLogger.appLog.debug("Update Group=> Cycle Price:" + cyclePrice + ", Cycle Days:" + cycleDays + ", UnderBalance:" + bbca);
							if (!ratebasedGroupRelBean.getBalancebelowcutoffallowed().equalsIgnoreCase(bbca) ||
								ratebasedGroupRelBean.getCycledays()!=cycleDays ||
								ratebasedGroupRelBean.getCycleprice()!=cyclePrice) {
								ratebasedGroupRelBean.setBalancebelowcutoffallowed(bbca);
								ratebasedGroupRelBean.setCycledays(cycleDays);
								ratebasedGroupRelBean.setCycleprice(cyclePrice);
								int rateGroupUpdateStatus = rateBasedGroupRelationDAO.update(ratebasedGroupRelBean);
								E24onlineLogger.appLog.debug("Update Group: rate group bean update status: " + rateGroupUpdateStatus + " for group id:" + ratebasedGroupRelBean.getGroupid());
							} else {
								E24onlineLogger.appLog.debug("Update Group: No need to update ratebased group:"+ ratebasedGroupRelBean.getGroupid());
							}
						}
					}
					if(groupBean.getConnectiontype() != E24onlineConstants.LEASEDLINE && groupBean.getPoolid() > 0){
						//TreeMap userBeanMap = UserBean.getUserBeanMap();
						Iterator iterator = UserBeanUtilities.getGroupMembersList(groupBean.getGroupid()).iterator();
						Integer key = null;
						Tbluser userBean = null;
						IIpPool ipPoolDao=factory.getIpPoolDAO();
						while (iterator.hasNext()){
							key = (Integer) iterator.next();
							userBean = userDAO.getRecordByPrimaryKey(key);
								
							int ret = UserBeanUtilities.changeLoginRestriction(userBean,groupBean.getPoolid());
							if (ret > 0) {
								String oldrestriction = null;
								String newrestriction = "Allow from Selected Pool: " + ipPoolDao.getNameById(groupBean.getPoolid());
								if (userBean.getIpallocation() == IPRestrictionConstants.OPEN) {
									oldrestriction = "Allow From All IPAddress";
								} else if (userBean.getIpallocation() == IPRestrictionConstants.RESTRICTIONONGROUP) {
									oldrestriction = "Allow from group of IPAddresses";
								} else if (userBean.getIpallocation() == IPRestrictionConstants.RESTRICTIONONINDIVIDUAL) {
									oldrestriction = "Allow from Selected IPAddress";
								} else if (userBean.getIpallocation() == IPRestrictionConstants.RESTRICTIONONPOOL) {
									oldrestriction = "Allow from Selected Pool";
								} else if (userBean.getIpallocation() == IPRestrictionConstants.RESTRICTIONONZONE) {
									oldrestriction = "Allow from Selected Zone";
								}
								E24onlineLogger.audit.info(new AuditObject(AuditObject.SYSTEM,userBean.getUsername(),AuditObject.USERPOOLCHANGED,oldrestriction,newrestriction,loggedInUserName,(String)httpSession.getAttribute("ipaddress")));
							}
						}
						E24onlineLogger.appLog.debug("Successfully Updated userbean");
					}

					// updated successfully....so do event update.......by Pankaj
					CyberoamEventObject eo = new CyberoamEventObject(EventIdentifierConstants.PACKAGEUPDATED);
					boolean pkgPolicyChanged = false;
					eo.setAttribute(EventAttributeConstants.PackageId, groupBean.getGroupid());
					if (oldGroupBean.getAccesspolicyid() != groupBean.getAccesspolicyid()) {
						eo.setAttribute(EventAttributeConstants.AccessPolicyId,groupBean.getAccesspolicyid());
						pkgPolicyChanged = true;
					}
					if (oldGroupBean.getBwpolicyid() != groupBean.getBwpolicyid()) {
						eo.setAttribute(EventAttributeConstants.BandwidthPolicyId,groupBean.getBwpolicyid());
						pkgPolicyChanged = true;
					}
					if (oldGroupBean.getDatatransferpolicyid() != groupBean.getDatatransferpolicyid()) {
						eo.setAttribute(EventAttributeConstants.DataTransferPolicyId,groupBean.getDatatransferpolicyid());
						pkgPolicyChanged = true;
					}
					if (oldGroupBean.getPoolid() != groupBean.getPoolid()) {
						eo.setAttribute(EventAttributeConstants.PoolId,groupBean.getPoolid());
						pkgPolicyChanged = true;
					}
					if (pkgPolicyChanged) {
						E24onlineEventHandler.addEventObject(eo);
						E24onlineLogger.appLog.debug("[EventHandler] Package policy changed: " + eo);
					} else {
						E24onlineLogger.appLog.debug("[EventHandler] No policies changed in UpdateGroup, so not sending EventObject.");
					}
					// end of event updating

					// Update in Entity Zone Relation only when POP Mgmt. customization is enabled
//					boolean isZoneManager = false;
//					if(e24online.utilities.E24onlineUtilities.isZoneOrPopUserType(securityLevel)){
//						isZoneManager = true ;
//					}
//					if(isPOPEnabled && !isZoneManager){

					//Removing the condition for the 'zone or pop manager' that, they  can not update the entityzone relation..
					if(isPOPEnabled){
						IEntityZoneRelDAO entityZoneRelDAO=factory.getEntityZoneRelDAO();
						IEntityPopRelDAO entityPopRelDAO=factory.getEntityPopRelDAO();
						//ArrayList zoneIdListForPop = null;
						int iPopId = E24onlineConstants.NOPOPSELECTED;
						String popId = req.getParameter("popid");
						String[] zoneIdarray = req.getParameterValues("zoneid");
						String zoneId = E24onlineUtilities.toString(zoneIdarray);
						E24onlineLogger.appLog.debug(MODULE+" zoneid str:"+zoneId);
					//	IEntityPopRelDAO entityPopRelDao = factory.getEntityPopRelDAO();
						String izoneid = E24onlineConstants.ALLOWEDFROMALLZONE+"";
						if(zoneId!=null && !zoneId.equals("") && !zoneId.equalsIgnoreCase("null")){
							izoneid = zoneId;
						}
						if (popId != null && !("").equals(popId)) {
							try {
								iPopId = Integer.parseInt(popId);
							} catch (Exception e) {
								E24onlineLogger.errorLog.error("Update Package, Exception while parsing Pop Id :"+e,e);
							}
						}
						E24onlineLogger.appLog.debug(MODULE+" iPopid:"+iPopId);
						// Changes for pop Zone by mohit
						//EntityZoneRelation.createEntityZoneRelation(E24onlineConstants.PACKAGE,groupBean.getGroupid(),iPopId,izoneid,securityLevel);
						
						if(iPopId >= 0){
							
							//sssIZoneDao zoneDao = factory.getZoneDao();
							//zoneIdListForPop = zoneDao.getZoneIdListByPOPId(iPopId);
							Set<Integer> entityZoneIdList  = entityZoneRelDAO.getZoneIdListByEnityId(E24onlineConstants.PACKAGE,groupBean.getGroupid());
							
							TblentitypoprelId entityPopRelId=new TblentitypoprelId();
							entityPopRelId.setEntityid(groupBean.getGroupid());
							entityPopRelId.setEntitytype(E24onlineConstants.PACKAGE);
							Tblentitypoprel entityPopRelBean=entityPopRelDAO.getRecordByPrimaryKey(entityPopRelId);
						//	String zoneidlistforpopstr = E24onlineUtilities.toString(zoneIdListForPop.toArray());
							
							
							if(iPopId==0){
								if(entityZoneIdList!=null && !entityZoneIdList.isEmpty() && entityPopRelBean!=null &&  popId.equalsIgnoreCase(String.valueOf(entityPopRelBean.getPopid()))){
									//IF not -40 then do nothing, means some zone is assigned then do not delete... 	
								}else{
									Tblentitypoprel entityPopRel =  new Tblentitypoprel();
									entityPopRelId = new TblentitypoprelId(E24onlineConstants.PACKAGE,groupBean.getGroupid());
									entityPopRel.setId(entityPopRelId);
									int deleteValue = entityPopRelDAO.delete(entityPopRel);
									E24onlineLogger.appLog.info("EntityZoneRelation deleteValue as no pop is selected : " + deleteValue);
								}
							}else if(entityPopRelBean==null || !popId.equalsIgnoreCase(String.valueOf(entityPopRelBean.getPopid()))){
								//if((entityZoneIdList != null && entityZoneIdList.size() > 0) || entityPopRelBean!=null ){
									if(entityZoneIdList!=null && !entityZoneIdList.isEmpty()){
										izoneid = entityZoneIdList.toString();
									}
									//EntityZoneRelation.createEntityZoneRelation(E24onlineConstants.PACKAGE,groupBean.getGroupid(),zoneIdListForPop,izoneid,securityLevel);
									EntityZoneRelation.createEntityZoneRelation(E24onlineConstants.PACKAGE,groupBean.getGroupid(),iPopId,izoneid,securityLevel);
								//}
							}
							
							E24onlineLogger.appLog.info("EntityZoneRelation pass zone:"+(entityZoneIdList!=null && !entityZoneIdList.isEmpty()?entityZoneIdList.toString():"no zone")+" curnt popid:"+(entityPopRelBean!=null?entityPopRelBean.getPopid():"not found."));
							
						} else if (iPopId == E24onlineConstants.NOPOPSELECTED) {
							Tblentitypoprel entityPopRel =  new Tblentitypoprel();
							TblentitypoprelId entityPopRelId = new TblentitypoprelId(E24onlineConstants.PACKAGE,groupBean.getGroupid());
							entityPopRel.setId(entityPopRelId);
							int deleteValue = entityPopRelDAO.delete(entityPopRel);
							E24onlineLogger.appLog.info("EntityZoneRelation deleteValue as no pop is selected : " + deleteValue);
						}
					}
//					else if(isZoneEnabled){
//						//If pop is off, then all zone will be inserted for that package..
//						ArrayList zoneIdListForPop = null;
//						int iPopId = E24onlineConstants.NOPOPSELECTED;
//						String[] zoneIdarray = req.getParameterValues("zoneid");
//						String zoneId = E24onlineUtilities.toString(zoneIdarray);
//						E24onlineLogger.appLog.debug(MODULE+" zoneid str:"+zoneId);
//						
//						String izoneid = E24onlineConstants.ALLOWEDFROMALLZONE+"";
//						if(zoneId!=null && !zoneId.equals("")){
//							izoneid = zoneId;
//						}
//						zoneIdListForPop = ZoneBean.getZoneIdList();
//						if(zoneIdListForPop != null && zoneIdListForPop.size() > 0){
//							EntityZoneRelation.createEntityZoneRelation(E24onlineConstants.PACKAGE,groupBean.getGroupID(),zoneIdListForPop,izoneid,securityLevel);
//						}
//						
//					}

					E24onlineLogger.audit.info(new AuditObject(AuditObject.PACKAGE,groupBean.getGroupname(),AuditObject.UPDATEPACKAGE,oldGroupBean.toString(),groupBean.toString(),loggedInUserName,(String)httpSession.getAttribute("ipaddress"),groupBean.getGroupid()));
					if (bwUpdateFailed) {
						updateStatus = E24onlineUtilities.BW_ALREADYSETAS_BODSLAB;
						E24onlineLogger.appLog.info("BW Policy Update Failed ,Update Status: " + updateStatus);
						req.getRequestDispatcher("/webpages/grpmgt/addupdategroup.jsp?updatestatus="+updateStatus+"&groupid="+groupBean.getGroupid()).forward(req,res);
						return;
					}
					
					// update Relation between hotel and package policy
					if(HotelUtilities.IS_MANY_HOTEL){
						HotelEntityRelationHelper.updateHotelEntityRelation(E24onlineConstants.PACKAGE, groupBean.getGroupid(), hotelIds, securityLevel);
					}
				} else if (updateStatus == E24onlineUtilities.ALREADYEXISTS) {
					groupBean.setGroupname(oldGroupBean.getGroupname());
				}
				E24onlineLogger.appLog.info("Update Status: " + updateStatus);
				req.setAttribute("updatestatus",Integer.toString(updateStatus));
				req.setAttribute("groupname", groupBean.getGroupname());
			}
			req.getRequestDispatcher("/webpages/grpmgt/managegroups.jsp").forward(req,res);
		} catch (Exception e) {
			res.sendRedirect("/corporate/webpages/error.jsp?errormessage=" + URLEncoder.encode("Error in updating group.") + "&exception="+ URLEncoder.encode(e.toString()));
			E24onlineLogger.errorLog.error("Exception in updateGroup : " + e, e);
		}
	}

	private static void updateCaswiseFields(HttpServletRequest req,Tblgroup groupBean) {
		//String strCasgroupid = req.getParameter("contentgroup");
		//String strContentgroupid = req.getParameter("contentgroup[]");
		String[] strContentgroupidarr = req.getParameterValues("contentgroupid[]");
		String strCasvalidty = req.getParameter("validity");
		String strCasdaystype = req.getParameter("daystype");
		String strCasproductid = req.getParameter("productid");
		String strPrice = req.getParameter("casprice");
		String strCasMultipleTV = req.getParameter("multipletvprice");
		String strCasid = req.getParameter("casid");
		List<String> casgroupidlist=null;
		
		int casvalidity=0;
		int daystype=E24onlineConstants.DAILY;
		double casprice = 0.0;
		double casmultipletvprice=0.0;
		int casid=0;
		if(strContentgroupidarr!=null && strContentgroupidarr.length>0){
			String strcontentgroup = E24onlineUtilities.toString(strContentgroupidarr);
			E24onlineLogger.appLog.debug(MODULE+" content groupid:"+strcontentgroup);
			casgroupidlist = E24onlineUtilities.toArrayListFromString(strcontentgroup);
		}else{
			E24onlineLogger.appLog.debug(MODULE+" content groupid not found:"+strContentgroupidarr);
		}
		if(strCasdaystype!=null){
			try{
				daystype=Integer.parseInt(strCasdaystype);
			}catch (Exception e) {
				E24onlineLogger.appLog.debug(MODULE+" updateCaswiseFields err in parsing daystype:"+e);
			}
		}
		
		if(strCasvalidty!=null){
			casvalidity = Integer.parseInt(strCasvalidty);
		}
		if(daystype==E24onlineConstants.MONTHLY){
			E24onlineLogger.appLog.debug(MODULE+" updateCaswiseFields casvalidity:"+casvalidity+" daystype:"+daystype);
			casvalidity= casvalidity*30; 
		}else if(daystype==E24onlineConstants.YEARLY){
			E24onlineLogger.appLog.debug(MODULE+" updateCaswiseFields casvalidity:"+casvalidity+" daystype:"+daystype);
			casvalidity= casvalidity*365; 
		}
		E24onlineLogger.appLog.debug(MODULE+" updateCaswiseFields casvalidity:"+casvalidity);
		if(isCASOnly){
			casprice = groupBean.getPrice();
		}else{
			if(strPrice!=null){
				casprice=Double.parseDouble(strPrice);
			}
		}
		if(strCasMultipleTV!=null){
			casmultipletvprice=Double.parseDouble(strCasMultipleTV);
		}
		if(strCasMultipleTV==null){
			strCasMultipleTV="";
		}
		if(strCasid!=null){
			casid=Integer.parseInt(strCasid);
		}
		if(strCasid==null){
			casid=0;
		}
		E24onlineLogger.appLog.debug(MODULE+" arr:"+strContentgroupidarr
				+ " Cas Group id:"+casgroupidlist+" validity:"+casvalidity+" MultiTvPrice:"+casmultipletvprice+" Prod Id:"+strCasproductid + "CAS Id:"+casid);
		
		int casrelstatus = GroupCASRelHelper.updateCasGroups(groupBean,casprice,casvalidity,casmultipletvprice,strCasproductid,casid);
		E24onlineLogger.appLog.debug(MODULE + "CAS group rel status: " + casrelstatus);
		if(casrelstatus>=CASConstants.SUCCESSFUL){
			GroupCASRelDetailHelper detailHelper = new GroupCASRelDetailHelper();
			int casdetailstatus =  detailHelper.updateConentGroupDetail(groupBean.getGroupid() ,casgroupidlist);
			E24onlineLogger.appLog.debug(MODULE + "CAS group rel detail status: " + casdetailstatus);
		}
		
	}

	// Added by bhavesh to update package from webservices
	public static int updateGroup(Tblgroup groupBean, String popId, String[] gatewayServiceId, String[] gatewayPorportion, String[] gatewayDiscount, String updatedBy, String sourceIPAddress, int securityLevel) {
		int updateStatus = -1;
		boolean isBandwidthOnDemandVisible = CustomizationController.isCustomizationVisible(CustomizationConstants.BANDWIDTHONDEMAND);
		try {
			IGroupDAO groupDAO = factory.getGroupDAO();
			Tblgroup oldGroupBean = groupDAO.getRecordByPrimaryKey(groupBean.getGroupid());
			E24onlineLogger.appLog.debug("GROUP Object: " + groupBean);
			String org_onlinePurchase = oldGroupBean.getOnlinepurchase();

			if (groupBean.getConnectiontype() == E24onlineConstants.LEASEDLINE) {
				groupBean.setAccesspolicyid(E24onlineUtilities.OPENPOLICY);
			}

			boolean bwUpdateFailed = false;
			try {
				int bwpolicyid = groupBean.getBwpolicyid();
				if (bwpolicyid == 0) {
					groupBean.setBwpolicyid(E24onlineConstants.NOBANDWIDTHRESTRICTION);
				} else {
					if (isBandwidthOnDemandVisible) {
						IGroupCOARelDAO groupCOARelDAO = factory.getGroupCOARelDAO();
						Tblgroupcoarel groupBwRelBean = groupCOARelDAO.getBeanByGroupAndBWPolicyId(groupBean.getGroupid(),bwpolicyid);
						if (groupBwRelBean != null
								&& groupBwRelBean.getCoatype() == BandwidthConstants.COATYPE_CHANGE_BWPOLICY) {
							// group-bw relation exists for BOD, so can't set this bw policy
							bwUpdateFailed = true;
						} else {
							groupBean.setBwpolicyid(bwpolicyid);
						}
					} else {
						groupBean.setBwpolicyid(bwpolicyid);
					}
				}
			} catch (Exception e) {
				groupBean.setBwpolicyid(E24onlineConstants.NOBANDWIDTHRESTRICTION);
			}
			if (groupBean.getPackagetype() == E24onlineConstants.PREPAIDSCHEME) {
				groupBean.setCycletype(null);
				groupBean.setCyclemultiplier(0);
				groupBean.setBillingdate(0);
			}
			if(isHotelFlowOn && ("N").equals(groupBean.getOnlinepurchase()) && ("Y").equals(org_onlinePurchase) && RoomTypeWiseGroupBean.isPackageBoundToRoomType(groupBean.getGroupid())){
				E24onlineLogger.appLog.debug("UPDATE GROUP : Online Purchase Status of packages bound to Room Type could not be updated");
				updateStatus = E24onlineUtilities.FOREIGNKEYPRESENT;
				return updateStatus;
			} else {
				updateStatus = groupDAO.update(groupBean);
				E24onlineLogger.appLog.debug(MODULE + Thread.currentThread().getStackTrace()[2].getLineNumber() + "################# Updating Group of with ID = " + groupBean.getGroupid());
			}
			if (updateStatus > 0) {

				Tblgroupgatewayservice groupGatewayServiceBean = null;
				IGroupGatewayServiceDAO groupGatewayServiceDAO = factory.getGroupGatewayServiceDAO();
				int serviceProportionStatus = -1;
				if(groupBean.getProportiontype().equals(E24onlineConstants.DEFAULTSERVICEPROPORTION) && isMultipleServicesInvoiceVisible) {
					TreeMap groupGWServiceMap = groupGatewayServiceDAO.getGroupGatewayServiceBeanMapByGroupId(groupBean.getGroupid()); 
					if( groupGWServiceMap != null && !groupGWServiceMap.isEmpty() ){
						serviceProportionStatus = groupGatewayServiceDAO.deleteRecordByGroupId(groupBean.getGroupid());
					}
				}else if(groupBean.getProportiontype().equals(E24onlineConstants.MANUALSERVICEPROPORTION)){
					int iGatewayServiceId = 0;
					double dGatewayProportion = 0;
					double dGatewayDiscount = 0;

					for (int i = 0; i < gatewayServiceId.length; i++) {

						iGatewayServiceId = 0;
						dGatewayProportion = 0;
						dGatewayDiscount = 0;

						if (gatewayServiceId[i] != null) {
							try {
								iGatewayServiceId = Integer.parseInt(gatewayServiceId[i]);
							} catch (Exception e) {
								E24onlineLogger.errorLog.error("UPDATE GROUP,Exception while parsing Gateway Service Id :"+e,e);
							}
						}
						if (gatewayPorportion[i] != null) {
							try {
								dGatewayProportion = Double.parseDouble(gatewayPorportion[i]);
							} catch (Exception e) {
								E24onlineLogger.errorLog.error("UPDATE GROUP,Exception while parsing Gateway Service Proportion :"+e,e);
							}
						}
						if(gatewayDiscount != null && gatewayDiscount[i] != null){
							try {
								dGatewayDiscount = Double.parseDouble(gatewayDiscount[i]);
							} catch (Exception e) {
								E24onlineLogger.errorLog.error("UPDATE GROUP,Exception while parsing Gateway Service Discount :"+e,e);
							}
						}
						groupGatewayServiceBean = new Tblgroupgatewayservice();

						groupGatewayServiceBean.setGroupid(groupBean.getGroupid());
						groupGatewayServiceBean.setGatewayserviceid(iGatewayServiceId);
						groupGatewayServiceBean.setProportion(dGatewayProportion);
						groupGatewayServiceBean.setDiscount(dGatewayDiscount);
						Tblgroupgatewayservice groupGWServiceBean = groupGatewayServiceDAO.getGroupGatewayServiceBean(groupBean.getGroupid(),iGatewayServiceId);

						if (groupGWServiceBean != null) {
							serviceProportionStatus = groupGatewayServiceDAO.update(groupGatewayServiceBean);
						} else {
							serviceProportionStatus = groupGatewayServiceDAO.insert(groupGatewayServiceBean);
						}
					}
					E24onlineLogger.appLog.debug("UPDATE GROUP : serviceProportionStatus:" + serviceProportionStatus);
				}

				E24onlineLogger.appLog.debug("UPDATE GROUP : Ratebased prepaid group flag:" + groupBean.isRatebasedPrepaidGroup());
				if (groupBean.isRatebasedPrepaidGroup()) {
					IRateBasedGroupRelationDAO rateBasedGroupRelationDAO = factory.getRateBasedGroupRelationDAO();
					Tblratebasedgrouprel ratebasedGroupRelBean = rateBasedGroupRelationDAO.getRecordByPrimaryKey(groupBean.getGroupid());
					if (ratebasedGroupRelBean != null) {
						int cycleDays = ratebasedGroupRelBean.getCycledays();
						double cyclePrice = ratebasedGroupRelBean.getCycleprice();
						String bbca = ratebasedGroupRelBean.getBalancebelowcutoffallowed();
						/*try {
							cycleDays = Integer.parseInt(req.getParameter("cycledays").trim());
						}catch(Exception e){
							E24onlineLogger.errorLog.error("UpdateGroup: Exception in Parsing CycleDays :" + e);
						}
						try {
							cyclePrice = Double.parseDouble(req.getParameter("cycleprice").trim());
						}catch(Exception e){
							E24onlineLogger.errorLog.error("UpdateGroup: Exception in Parsing Cycle Price :" + e);
						}
						try {
							bbca = req.getParameter("underbalaceallowed").trim();
						}catch(Exception e){
							E24onlineLogger.errorLog.error("UpdateGroup: Exception in Parsing UnderBalanceAllowed:" + e);
						}*/
						E24onlineLogger.appLog.debug("Update Group=> Cycle Price:" + cyclePrice + ", Cycle Days:" + cycleDays + ", UnderBalance:" + bbca);
						if (!ratebasedGroupRelBean.getBalancebelowcutoffallowed().equalsIgnoreCase(bbca) ||
							ratebasedGroupRelBean.getCycledays()!=cycleDays ||
							ratebasedGroupRelBean.getCycleprice()!=cyclePrice) {
							ratebasedGroupRelBean.setBalancebelowcutoffallowed(bbca);
							ratebasedGroupRelBean.setCycledays(cycleDays);
							ratebasedGroupRelBean.setCycleprice(cyclePrice);
							int rateGroupUpdateStatus = rateBasedGroupRelationDAO.update(ratebasedGroupRelBean);
							E24onlineLogger.appLog.debug("Update Group: rate group bean update status: " + rateGroupUpdateStatus + " for group id:" + ratebasedGroupRelBean.getGroupid());
						} else {
							E24onlineLogger.appLog.debug("Update Group: No need to update ratebased group:"+ ratebasedGroupRelBean.getGroupid());
						}
					}
				}
				if(groupBean.getConnectiontype() != E24onlineConstants.LEASEDLINE && groupBean.getPoolid() > 0){
					//TreeMap userBeanMap = UserBean.getUserBeanMap();
					Iterator iterator = UserBeanUtilities.getGroupMembersList(groupBean.getGroupid()).iterator();
					Integer key = null;
					Tbluser userBean = null;
					IUserDAO userDAO=factory.getUserDAO();
					IIpPool ipPoolDao=factory.getIpPoolDAO();
					while (iterator.hasNext()) {
						key = (Integer) iterator.next();
						userBean = userDAO.getRecordByPrimaryKey(key);
						int ret = UserBeanUtilities.changeLoginRestriction(userBean,groupBean.getPoolid());
						if (ret > 0) {
							String oldrestriction = null;
							String newrestriction = "Allow from Selected Pool: " + ipPoolDao.getNameById(groupBean.getPoolid());
							if (userBean.getIpallocation() == IPRestrictionConstants.OPEN) {
								oldrestriction = "Allow From All IPAddress";
							} else if (userBean.getIpallocation() == IPRestrictionConstants.RESTRICTIONONGROUP) {
								oldrestriction = "Allow from group of IPAddresses";
							} else if (userBean.getIpallocation() == IPRestrictionConstants.RESTRICTIONONINDIVIDUAL) {
								oldrestriction = "Allow from Selected IPAddress";
							} else if (userBean.getIpallocation() == IPRestrictionConstants.RESTRICTIONONPOOL) {
								oldrestriction = "Allow from Selected Pool";
							} else if (userBean.getIpallocation() == IPRestrictionConstants.RESTRICTIONONZONE) {
								oldrestriction = "Allow from Selected Zone";
							}
							E24onlineLogger.audit.info(new AuditObject(AuditObject.SYSTEM,userBean.getUsername(),AuditObject.USERPOOLCHANGED,oldrestriction,newrestriction,updatedBy,sourceIPAddress));
						}
					}
					E24onlineLogger.appLog.debug("Successfully Updated userbean");
				}

				// updated successfully....so do event update.......
				CyberoamEventObject eo = new CyberoamEventObject(EventIdentifierConstants.PACKAGEUPDATED);
				boolean pkgPolicyChanged = false;
				eo.setAttribute(EventAttributeConstants.PackageId, groupBean.getGroupid());
				if (oldGroupBean.getAccesspolicyid() != groupBean.getAccesspolicyid()) {
					eo.setAttribute(EventAttributeConstants.AccessPolicyId,groupBean.getAccesspolicyid());
					pkgPolicyChanged = true;
				}
				if (oldGroupBean.getBwpolicyid() != groupBean.getBwpolicyid()) {
					eo.setAttribute(EventAttributeConstants.BandwidthPolicyId,groupBean.getBwpolicyid());
					pkgPolicyChanged = true;
				}
				if (oldGroupBean.getDatatransferpolicyid() != groupBean.getDatatransferpolicyid()) {
					eo.setAttribute(EventAttributeConstants.DataTransferPolicyId,groupBean.getDatatransferpolicyid());
					pkgPolicyChanged = true;
				}
				if (oldGroupBean.getPoolid() != groupBean.getPoolid()) {
					eo.setAttribute(EventAttributeConstants.PoolId,groupBean.getPoolid());
					pkgPolicyChanged = true;
				}
				if (pkgPolicyChanged) {
					E24onlineEventHandler.addEventObject(eo);
					E24onlineLogger.appLog.debug("[EventHandler] Package policy changed: " + eo);
				} else {
					E24onlineLogger.appLog.debug("[EventHandler] No policies changed in UpdateGroup, so not sending EventObject.");
				}
				// end of event updating

				// Update in Entity Zone Relation only when POP Mgmt. customization is enabled
				boolean isZoneManager = false;
				if(e24online.utilities.E24onlineUtilities.isZoneOrPopUserType(securityLevel)){
					isZoneManager = true;
				}
				if(isPOPEnabled ){
				//	ArrayList zoneIdListForPop = null;
					int iPopId = E24onlineConstants.NOPOPSELECTED;
					String izoneid = E24onlineConstants.ALLOWEDFROMALLZONE+"";
					if(popId != null && !("").equals(popId)){
						try{
							iPopId = Integer.parseInt(popId);
						}catch(Exception e){
							E24onlineLogger.errorLog.error("Update Package, Exception while parsing Pop Id :"+e,e);
						}
					}
				//	IEntityPopRelDAO entityPopRelDao = factory.getEntityPopRelDAO();
					//Changes for pop zone by mohit
					IEntityZoneRelDAO entityZoneRelDAO=factory.getEntityZoneRelDAO();
					IEntityPopRelDAO entityPopRelDAO=factory.getEntityPopRelDAO();
					if(iPopId >= 0){
						
						//sssIZoneDao zoneDao = factory.getZoneDao();
						//zoneIdListForPop = zoneDao.getZoneIdListByPOPId(iPopId);
						Set<Integer> entityZoneIdList  = entityZoneRelDAO.getZoneIdListByEnityId(E24onlineConstants.PACKAGE,groupBean.getGroupid());
						
						TblentitypoprelId entityPopRelId=new TblentitypoprelId();
						entityPopRelId.setEntityid(groupBean.getGroupid());
						entityPopRelId.setEntitytype(E24onlineConstants.PACKAGE);
						Tblentitypoprel entityPopRelBean=entityPopRelDAO.getRecordByPrimaryKey(entityPopRelId);
					//	String zoneidlistforpopstr = E24onlineUtilities.toString(zoneIdListForPop.toArray());
						
						
						if(iPopId==0){
							if(entityZoneIdList!=null && !entityZoneIdList.isEmpty() && entityPopRelBean!=null &&  popId.equalsIgnoreCase(String.valueOf(entityPopRelBean.getPopid()))){
								//IF not -40 then do nothing, means some zone is assigned then do not delete... 	
							}else{
								Tblentitypoprel entityPopRel =  new Tblentitypoprel();
								entityPopRelId = new TblentitypoprelId(E24onlineConstants.PACKAGE,groupBean.getGroupid());
								entityPopRel.setId(entityPopRelId);
								int deleteValue = entityPopRelDAO.delete(entityPopRel);
								E24onlineLogger.appLog.info("EntityZoneRelation deleteValue as no pop is selected : " + deleteValue);
							}
						}else if(entityPopRelBean==null || !popId.equalsIgnoreCase(String.valueOf(entityPopRelBean.getPopid()))){
							//if((entityZoneIdList != null && entityZoneIdList.size() > 0) || entityPopRelBean!=null ){
								if(entityZoneIdList!=null && !entityZoneIdList.isEmpty()){
									izoneid = entityZoneIdList.toString();
								}
								//EntityZoneRelation.createEntityZoneRelation(E24onlineConstants.PACKAGE,groupBean.getGroupid(),zoneIdListForPop,izoneid,securityLevel);
								EntityZoneRelation.createEntityZoneRelation(E24onlineConstants.PACKAGE,groupBean.getGroupid(),iPopId,izoneid,securityLevel);
						//	}
						}
						
						E24onlineLogger.appLog.info("EntityZoneRelation pass zone:"+(entityZoneIdList!=null && !entityZoneIdList.isEmpty()?entityZoneIdList.toString():"no zone")+" curnt popid:"+(entityPopRelBean!=null?entityPopRelBean.getPopid():"not found."));
						
					} else if (iPopId == E24onlineConstants.NOPOPSELECTED) {
						Tblentitypoprel entityPopRel =  new Tblentitypoprel();
						TblentitypoprelId entityPopRelId = new TblentitypoprelId(E24onlineConstants.PACKAGE,groupBean.getGroupid());
						entityPopRel.setId(entityPopRelId);
						int deleteValue = entityPopRelDAO.delete(entityPopRel);
						E24onlineLogger.appLog.info("EntityZoneRelation deleteValue as no pop is selected : " + deleteValue);
					}
				}

				E24onlineLogger.audit.info(new AuditObject(AuditObject.PACKAGE,groupBean.getGroupname(),AuditObject.UPDATEPACKAGE,oldGroupBean.toString(),groupBean.toString(),updatedBy,sourceIPAddress,groupBean.getGroupid()));
				if (bwUpdateFailed) {
					updateStatus = E24onlineUtilities.BW_ALREADYSETAS_BODSLAB;
					E24onlineLogger.appLog.info("BW Policy Update Failed ,Update Status: " + updateStatus);
					// req.getRequestDispatcher("/webpages/grpmgt/addupdategroup.jsp?updatestatus="+updateStatus+"&groupid="+groupBean.getGroupID()).forward(req,res);
					return updateStatus;
				}
			}
		} catch (Exception e) {
			E24onlineLogger.errorLog.error("Error while updating group from webservice: "+e,e);
			return updateStatus;
		}
		return updateStatus;

	}
	public static void updateGroupFromDashboard(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
		E24onlineLogger.appLog.debug( MODULE+" updateGroupFromDashboard() called");

		String groupName = null;
		String bwPolicyId = null;
		String allottedMinutes = null;
		String allottedDays = null;
		String price = null;
		String onlinePurchase = null;
		String org_onlinePurchase = null;
		String groupId = null;

		int iBWPolicyId = E24onlineConstants.NOBANDWIDTHRESTRICTION;
		int iSurfingPolicyId = E24onlineConstants.VALUENOTPROVIDED;
		int iAllottedMinutes = E24onlineConstants.VALUENOTPROVIDED;
		int iAllottedDays = E24onlineConstants.VALUENOTPROVIDED;
		double dPrice = 0;

		HttpSession session = req.getSession(false);
		String loggedInUserName = (String) session.getAttribute("user");

		Tblgroup groupBean = null;
		Tblgroup oldGroupBean = null;
		int updateValue = -1;
		int iGroupId = -1;

		try {
			IGroupDAO groupDAO = factory.getGroupDAO();
			groupName = req.getParameter("groupname_org");
			bwPolicyId = req.getParameter("bwpolicyid_org");
			allottedMinutes = req.getParameter("allottedminutes_org");
			allottedDays = req.getParameter("allotteddays_org");
			price = req.getParameter("price_org");
			onlinePurchase = req.getParameter("onlinepurchase_org");
			groupId = req.getParameter("groupid_org");

			if(bwPolicyId != null && !("").equals(bwPolicyId) && !("null").equalsIgnoreCase(bwPolicyId)){
				try {
					iBWPolicyId = Integer.parseInt(bwPolicyId);
					if (iBWPolicyId == 0) {
						iBWPolicyId = E24onlineConstants.NOBANDWIDTHRESTRICTION;
					}
				} catch (Exception e) {
					iBWPolicyId = E24onlineConstants.NOBANDWIDTHRESTRICTION;
					E24onlineLogger.errorLog.error(MODULE + "updateGroupFromDashboard(), Exception while parsing BW Policy Id : "+e,e);
				}
			}

			if(allottedMinutes != null && !("").equals(allottedMinutes) && !("null").equalsIgnoreCase(allottedMinutes)){
				try {
					iAllottedMinutes = Integer.parseInt(allottedMinutes);
				} catch (Exception e) {
					iAllottedMinutes = E24onlineConstants.VALUENOTPROVIDED;
					E24onlineLogger.errorLog.error(MODULE + "updateGroupFromDashboard(), Exception while parsing Allotted Minutes : "+e,e);
				}
			}

			if(allottedDays != null && !("").equals(allottedDays) && !("null").equalsIgnoreCase(allottedDays)){
				try {
					iAllottedDays = Integer.parseInt(allottedDays);
				} catch (Exception e) {
					iAllottedDays = E24onlineConstants.VALUENOTPROVIDED;
					E24onlineLogger.errorLog.error(MODULE + "updateGroupFromDashboard(), Exception while parsing Allotted Days : "+e,e);
				}
			}

			if(price != null && !("").equals(price) && !("null").equalsIgnoreCase(price)){
				try {
					dPrice = Double.parseDouble(price);
				} catch (Exception e) {
					E24onlineLogger.errorLog.error(MODULE + "updateGroupFromDashboard(), Exception while parsing Price : "+e,e);
				}
			}

			if(groupId != null && !("").equals(groupId) && !("null").equalsIgnoreCase(groupId)){
				try {
					iGroupId = Integer.parseInt(groupId);
				} catch (Exception e) {
					iGroupId = E24onlineConstants.VALUENOTPROVIDED;
					E24onlineLogger.errorLog.error(MODULE + "updateGroupFromDashboard(), Exception while parsing Group Id : "+e,e);
				}
			}

			IPolicy policyDao=DAOFactory.instance(DAOFactory.HIBERNATE).getPolicyDao();
			iSurfingPolicyId = policyDao.getPolicyIdByAllottedMin_AllottedDays(iAllottedMinutes,iAllottedDays);

			if(onlinePurchase == null || ("").equals(onlinePurchase) || ("null").equalsIgnoreCase(onlinePurchase)){
				onlinePurchase = "N";
			}
			groupBean = groupDAO.getRecordByPrimaryKey(iGroupId);
			if (groupBean != null) {
				oldGroupBean = (Tblgroup) groupBean.clone();
				groupBean.setGroupname(groupName);
				org_onlinePurchase = groupBean.getOnlinepurchase();
				groupBean.setOnlinepurchase(onlinePurchase);
				groupBean.setPolicyid(iSurfingPolicyId);
				groupBean.setBwpolicyid(iBWPolicyId);
				groupBean.setPrice(dPrice);
				if(isHotelFlowOn && ("N").equals(onlinePurchase) && ("Y").equals(org_onlinePurchase) && RoomTypeWiseGroupBean.isPackageBoundToRoomType(iGroupId)){
					E24onlineLogger.appLog.debug( MODULE+" updateGroupFromDashboard() : Online Purchase Status of packages bound to Room Type could not be updated");
					updateValue = E24onlineUtilities.FOREIGNKEYPRESENT;
					groupBean = (Tblgroup) oldGroupBean.clone();
				} else {
					updateValue = groupDAO.update(groupBean);
					E24onlineLogger.appLog.debug(MODULE + Thread.currentThread().getStackTrace()[2].getLineNumber() + "################# Updating Group of with ID = " + groupBean.getGroupid());
				}
				E24onlineLogger.appLog.debug(MODULE + " updateGroupFromDashboard(), updateValue : "+updateValue);
			}

			if (updateValue > 0) {
				// For VoIP Policy Updation...
				if (VoIPConstants.IS_VOIP_VISIBLE) {
					String voipPolicyId = req.getParameter("voippolicynames");
					int intVoIPPolicyId  = VoIPConstants.NOVOIPPOLICY ;
					try{
						intVoIPPolicyId = Integer.parseInt(voipPolicyId.trim());
					}catch(NullPointerException npe){
						E24onlineLogger.errorLog.error("Exception :- Not able to get VoIP Policy Value [ Package may be Only Data Package...");
					}
					E24onlineLogger.appLog.debug(MODULE + "Updating VoIP Policy -> id = " + intVoIPPolicyId);
					TblVoIPGroupRel voipGroupEntity = new TblVoIPGroupRel();
					voipGroupEntity.setGroupid(groupBean.getGroupid());
					voipGroupEntity.setVoippolicyid(intVoIPPolicyId);

					updateVoIPPolicyGroup(voipGroupEntity,loggedInUserName,(String) session.getAttribute("ipaddress"));
				}
				// End - For VoIP Policy Updation...

				//Cas Mode changes
				if(isCASMode){
//					IUserDAO userDAO = factory.getUserDAO();
//					int userbindedcount = userDAO.count("where groupid="+iGroupId);
//					if(userbindedcount<=0){
						updateCaswiseFields(req,groupBean);
						/*String addonid = req.getParameter("addonid[]");
						String addontype = req.getParameter("addontype[]");
						String addonprice = req.getParameter("addonprice[]");
						String addonvalidity = req.getParameter("addonvalidity[]");
						
						int insertstatus = CASGroupAddonsHelper.insertAddons(groupBean.getGroupid(),casgroupid, addonid,addontype,addonprice,addonvalidity);
						E24onlineLogger.appLog.debug(MODULE + "insert CAS addons : " + insertstatus);
						int updateStatus=0;
						if (insertstatus<0) {
							if(insertstatus==CASConstants.UNSUCCESSFUL)
								updateStatus = E24onlineUtilities.ERRORINCASGROUPADD;
							else if (insertstatus==CASConstants.CURRENTCONFIGUREDGROUPADD)
								updateStatus=E24onlineUtilities.CURRENTCONFIGUREDCASGROUPADD;
							else if(insertstatus==CASConstants.PARTIALSUCCESS)
								updateStatus = E24onlineUtilities.PARTIALSUCCESSFORGROUPADDONS;
							E24onlineLogger.appLog.info("Update Status for group addons: " + updateStatus);
							req.getRequestDispatcher("/webpages/grpmgt/addupdategroup.jsp?updatestatus="+updateStatus+"&groupid="+groupBean.getGroupid()).forward(req,res);
							return;
						}
						*/
//					}else{
//						//Users are binded with current package so cas details can't be updated..
//						E24onlineLogger.appLog.debug(MODULE + "Users are binded with current package, so cant change cas details:" + userbindedcount);
//						req.getRequestDispatcher("/webpages/grpmgt/addupdategroup.jsp?updatestatus="+E24onlineUtilities.USERBINDEDWITHPACKAGE+"&groupid="+groupBean.getGroupid()).forward(req,res);
//						return;
//					}
				}
				
				E24onlineLogger.audit.info(new AuditObject(AuditObject.PACKAGE,
						groupBean.getGroupname(), AuditObject.UPDATEPACKAGE,
						oldGroupBean.toString(), groupBean.toString(),
						loggedInUserName, (String) session
								.getAttribute("ipaddress"), groupBean
								.getGroupid()));
			} else if (updateValue == E24onlineUtilities.ALREADYEXISTS) {
				groupBean = (Tblgroup) oldGroupBean.clone();
			}
		} catch (Exception e) {
			updateValue = E24onlineUtilities.ERROR;
			E24onlineLogger.errorLog.error( MODULE+" updateGroupFromDashboard(), Exception occured : " +e,e);
		}
		res.sendRedirect(req.getContextPath()+"/webpages/dashboard/manageplans.jsp?updatestatus="+updateValue+"&groupname="+groupName);		
	}

	public static boolean checkPoolofUsersInGroup(int groupid, int poolid) {
		E24onlineLogger.appLog.debug("checkPoolofUsersInGroup called... for groupid:"+groupid+" poolid:"+poolid);
		boolean retType = true;
		Iterator userList = null;
		Iterator ipList = null;
		Tblipaddress ipaddressBean = null;
		Integer userid = null;
		String networkIP = null;
		try {
			userList = UserBeanUtilities.getGroupMembersList(groupid).iterator();
			INetworkDAO networkDao=factory.getNetworkDao();
			Collection givenNetIdColl = networkDao.getListByCondition("where poolid ="+poolid +" order by netid");
			while (userList.hasNext()) {
				userid = (Integer) userList.next();
				IUserIPRelationDAO userippoolDAO=factory.getUserIPRelationDAO();
				ipList = userippoolDAO.getIPByuserId(userid).iterator();
				IUserNetworkRelDAO usernetworkDAO=factory.getUserNetworkRelDAO();
				Tblusernetworkrel usernetworkrelbean=usernetworkDAO.getRecordByPrimaryKey(userid);
				networkIP = usernetworkrelbean.getNetid();
				IIPAddressDAO ipAddressDAO=factory.getIpAddressDAO();
				if (ipList.hasNext()) { ipaddressBean = ipAddressDAO.getRecordByPrimaryKey((String) ipList.next());
					if (ipaddressBean == null || ipaddressBean.getPoolid() != poolid) {
						retType = false;
						break;
					}
				} else if (givenNetIdColl != null && networkIP != null && !givenNetIdColl.contains(networkIP)) {
					retType = false;
					break;
				}
			}
		} catch (Exception e) {
			E24onlineLogger.errorLog.error("Exception in UpdateGroup while checkLeaseLineUser :" + e, e);
		}
		E24onlineLogger.appLog.debug("RetType is :" + retType);
		return retType;
	}

	@SuppressWarnings("unchecked")
	public static int updateVoIPPolicyGroup(TblVoIPGroupRel voipGroupEntity, String username, String IPAddress) {
		int updateStatus = E24onlineUtilities.ERROR;
		int voipPolicy = voipGroupEntity.getVoippolicyid();
		IUserDAO userDAO=factory.getUserDAO();
		Collection<Integer> usersOfThePackage = userDAO.getPrimaryKeyCollection(" where groupid = " + voipGroupEntity.getGroupid());
		ArrayList<Integer> users = new ArrayList<Integer>(usersOfThePackage);
		for (Integer user : users) {
			TblVoipUserRel userVoIP = new TblVoipUserRel();
			userVoIP.setUserId(user);
			userVoIP.setVoipPolicyId(voipPolicy);
			try {
				boolean relExist = UserVoIPPolicyHelper.isUserRelationExist(user);
				if (relExist){
					UserVoIPPolicyHelper.updateUserVoIPRelation(userVoIP,username,IPAddress);	
				}else{
					UserVoIPPolicyHelper.createUserVoIPPolicyRelation(userVoIP,username,IPAddress);
				}
			} catch (Exception e) {
				E24onlineLogger.appLog.debug(MODULE + "updateVoIPPolicyGroup" + "Unable to Update User-VoIP Policy Relation " + e, e);
			}
		}
		try {
			E24onlineLogger.appLog.debug(MODULE + "Updating VoIP POlicy Mapping to - > " + voipGroupEntity);
			boolean relationExist = VoIPGroupHelper.isVoIPPolicyPackageRelationExist(voipGroupEntity.getGroupid());
			if (relationExist){
				VoIPGroupHelper.updateVoIPGroup(voipGroupEntity, username, IPAddress);
			}else{
				VoIPGroupHelper.createVoIPGroup(voipGroupEntity, username, IPAddress);
			}
		} catch (Exception e) {
			E24onlineLogger.errorLog.error( MODULE + "Exception : Unable to update Group with the VoIP Policy. " + e, e);
		}
		return updateStatus;
	}
	/**
	 * Updates the discount value for the package.
	 * @param groupID Package of which discount amount is to be updated.
	 * @param discountValue Discount Amount by with it will be replaced.
	 * @return whether discount process was done successfully then greater then 1 else -1 will be returned.
	 */
	public static int updateDiscountValue(int groupID, double discountValue, String strPercentageCheck,double dGrandTotalAmount ){
		//Upadating Group Discount Value
		int updateDiscountStatus = -1 ;
		IGatewayServiceDAO gatewayServiceDAO = factory.getGatewayServiceDAO();
		Tblgatewayservice groupGatewayBean  = gatewayServiceDAO.getRecordByPrimaryKey(E24onlineConstants.DEFAULTGATEWAYSERVICETYPEFORDISCOUNT);
		if (groupGatewayBean != null ){
			try{
				IGroupGatewayServiceDAO groupGatewayServiceDAO = factory.getGroupGatewayServiceDAO();
				Tblgroupgatewayservice groupGateway = groupGatewayServiceDAO.getGroupGatewayServiceBean(groupID,E24onlineConstants.DEFAULTGATEWAYSERVICETYPEFORDISCOUNT);
				if (groupGateway != null ){
					// percentage discount change starts					
					double originalDiscount;
					if(strPercentageCheck.equalsIgnoreCase("Y")){
						originalDiscount = groupGateway.getPercentagediscount();
					}
					else{
						originalDiscount = groupGateway.getDiscount();
					}
					E24onlineLogger.appLog.debug(MODULE + "originalDiscount--------------------------->" + originalDiscount);
					String originalPerDisCheck = groupGateway.getPercentagecheck();
					if (originalDiscount != discountValue || !originalPerDisCheck.equalsIgnoreCase(strPercentageCheck)){ // If original value for the discount is not changed then not required to update the query in database.
						if(strPercentageCheck.equalsIgnoreCase("Y")){
							double calDiscount = (dGrandTotalAmount * discountValue)/100;
							groupGateway.setPercentagediscount(discountValue);
							groupGateway.setDiscount(calDiscount);
							groupGateway.setPercentagecheck(strPercentageCheck);
							updateDiscountStatus = groupGatewayServiceDAO.update(groupGateway);
							E24onlineLogger.appLog.debug(MODULE + "calDiscount--------------------------->" + calDiscount);
						}
						else{
							groupGateway.setDiscount(discountValue);
							groupGateway.setPercentagecheck(strPercentageCheck);
							updateDiscountStatus = groupGatewayServiceDAO.update(groupGateway);
						} // percentage discount change ends
					}else{
						E24onlineLogger.appLog.debug(MODULE + "Updation for The Package for Discount was not required because value is not changed.");
					}
				}else{
					if (discountValue > 0 ){ // If the discount amount is greater then then only the discount value will be inserted in the table.
						Tblgroupgatewayservice ggBean = new Tblgroupgatewayservice();

						ggBean.setGroupid(groupID);
						ggBean.setGatewayserviceid(E24onlineConstants.DEFAULTGATEWAYSERVICETYPEFORDISCOUNT);
						ggBean.setProportion(E24onlineConstants.DEFAULTSERVICEPROPORTIONFORDISCOUNT);
						ggBean.setDiscount(discountValue);
						ggBean.setPercentagecheck(strPercentageCheck);
						updateDiscountStatus = groupGatewayServiceDAO.insert(ggBean);
					}
				}
			}catch(Exception e){
				E24onlineLogger.errorLog.error(MODULE + "Exception :-  Unable to update discount value for the package - " + groupID + ". " + e , e );
			}
		}
		//End - Upadating Group Discount Value
		return updateDiscountStatus ;
	}
}
