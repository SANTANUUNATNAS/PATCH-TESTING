#!/bin/sh
currentver=`cat /etc/version  | tr '\.' '\0'`
currentver=`echo $currentver | tail -c 5`
version=`grep -i "version" readme | cut -d " " -f2 | tail -c 5`
version=`echo $version | tail -c 5`

if [[ "$currentver" != "$version" ]];
then
	echo "Wrong version. Expected version : $version"
else 

	for file in `find ./source -type f -name "*"`
	do
		path=`echo $file | sed s#^\./source##`
		cp $path ./backup
	done
	echo "all file backup done."
	
	cp -pur ./source/usr/local /usr/
	
	for file in `find ./source -type f -name "*"`
	do
		path=`echo $file | sed s#^\./source##`
		cp $file $path
	done
	echo "all files are replaced."
fi

