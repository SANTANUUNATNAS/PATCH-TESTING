#!/bin/sh
for file in `find ./source -type f -name "*"`
do
        path=`echo $file | sed s#^\./source##`
        filename=`basename $file`
        cp ./backup/$filename $path
        echo $path "revert."
done

echo "Please verify readme file."
